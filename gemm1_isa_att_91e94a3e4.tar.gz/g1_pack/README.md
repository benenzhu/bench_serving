# gemm1 bm128 — ISA + ATT @ 91e94a3e4

Kernel `gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep`, Kimi-K2.5-MXFP4 MoE,
MI355X gfx950. token=8192, single-CU ATT (target_cu 1, simd_select 0xF),
FLYDSL_DEBUG_ENABLE_DEBUG_INFO=1, idle card2 (HIP_VISIBLE_DEVICES=2, PCI 0x65).
Repo RadeonFlow/up-aiter @ 91e94a3e4, clean tree.

## Files

| file | what |
|---|---|
| `gemm1_bm128.s` | final ISA, 4407 lines |
| `att_ui/` | parsed ATT: `code.json` + `se0_sm0_sl0_wv*.json` (55 waves) |
| `stats_*.csv` | rocprofv3 per-instruction stats |
| `*_shader_engine_0_4997.att` | raw trace |

ISA and ATT agree: 1792 mfma, 58 x `s_waitcnt vmcnt(20)`, 2 x `vmcnt(0)`.

Row schema in the wave json: `[cycle, issue_dur, stall, total_dur, code_id]`,
`code.json["code"][code_id][0]` is the asm text.

## Resources

vgpr 336, agpr 80, no spill. LDS 131072 (128 KB).

## Steady iteration

64 mfma, 20 ds_read, 4 albd (`buffer_load ... offen lds`), 8 B
`buffer_load_dwordx4`. Barriers at lines 504 / 633 / 747 / 862 / 987 / 1100 /
1227. The 4 albd are issued ahead of all 8 B loads on purpose -- vmcnt retires
oldest-first, so the fence value is the count of VMEM issued after the last
albd.

Memory ops mapped onto the 64 mfma of one iteration (`A`=albd, `B`=B load,
`d`=ds_read, `*`=several):

```
.*****A...d.*AAd...B......d.B...B...BB.........B.B..d.dd..d
```

VMEM issue gaps: 2,1,1,1,7,1,5,9,4,4,1,10,2 -- clustered, not the nominal
stride of 2. The emission order in `mfma_iouter` is only a hint; the machine
scheduler re-clusters it.

## mfma-coverage, slice [172364,188792), exec=16

```
MFMA-covered 11068 (67%)   EXPOSED 5360 (32%)   cyc/mfma 23.74  (floor 16)

    2132  39%exp 13.0%all  buffer_load_dwordx4
    1500  27%     9.1%     s_barrier
     692  12%     4.2%     s_waitcnt(vmcnt)
     304   5%     1.9%     ds_read_b128
     212   3%     1.3%     s_mov_b32
     184   3%     1.1%     v_or_b32_e32
```

## Why I stopped tuning the schedule

1. buffer_load exposure is NOT evenly spread: 125 exposed instances, median 8
   cyc, but top10 = 52% of the total. The spikes (220, 192, 132, 108 cyc) land
   at 16% / 24% / 55% / 70% into their iteration -- no fixed position. A
   mis-scheduled load would recur at the same offset every iteration.

2. Iteration length swings 1248..2100 (68%) at a near-constant instruction
   count (112..127) and mfma count (58..71). buffer_load stall and s_barrier
   stall trade off against each other iteration to iteration -- one wave's slow
   load becomes another wave's barrier wait next iteration.

   | iter | len | insts | mfma | bload stall | barrier stall |
   |------|-----|-------|------|-------------|---------------|
   | 1    | 2100| 127   | 71   | 152         | 528           |
   | 2    | 1248| 112   | 63   | 40          | 48            |
   | 3    | 1400| 113   | 58   | 264         | 24            |
   | 7    | 1612| 121   | 65   | 360         | 16            |

3. All 36 waves with a full trace run an identical instruction stream (1792
   mfma, 31 barrier) yet span 46260..65712 cycles -- 42% spread.

4. Max wave concurrency on the CU is 1: the 55 waves are strictly serial
   (wv0 ends 221648, wv1 starts 222060). At 1 wave/SIMD there is no other
   wavegroup to absorb a latency bubble, so jitter goes straight to wall clock.

Together: the loss is in when each load's data comes back, not in where the
instruction sits. Confirmed by experiment -- pinning the interleave with
`rocdl.sched_group_barrier` produced textbook-uniform spacing (VMEM gaps all
5, albd still ahead of the B loads) and measured 3885.6 vs 3895.8 TFLOP/s
unpinned. Four different pinned plans spanned 3693..3887, none beating the
compiler's own order. Reverted.
