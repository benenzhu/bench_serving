	.amdgcn_target "amdgcn-amd-amdhsa--gfx950"
	.amdhsa_code_object_version 6
	.text
	.globl	gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep
	.p2align	8
	.type	gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep,@function
gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep:
	s_load_dwordx4 s[8:11], s[0:1], 0x20
	s_waitcnt lgkmcnt(0)
	s_load_dword s3, s[10:11], 0x0
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s4, s3, 31
	s_lshr_b32 s4, s4, 25
	s_add_i32 s4, s3, s4
	s_ashr_i32 s10, s4, 7
	s_and_b32 s4, s4, 0xffffff80
	s_cmp_lg_u32 s3, s4
	s_cselect_b64 s[4:5], -1, 0
	s_cmp_lt_i32 s3, 0
	s_cselect_b64 s[6:7], -1, 0
	s_and_b64 s[4:5], s[6:7], s[4:5]
	s_subb_u32 s16, s10, 0
	s_lshl_b32 s3, s16, 4
	s_cmp_ge_i32 s2, s3
	v_readfirstlane_b32 s3, v0
	s_cbranch_scc1 .LBB0_3
	s_load_dwordx4 s[4:7], s[0:1], 0x30
	s_load_dword s12, s[0:1], 0x38
	s_waitcnt lgkmcnt(0)
	s_ashr_i32 s6, s2, 31
	s_lshr_b32 s6, s6, 28
	s_add_i32 s6, s2, s6
	s_ashr_i32 s13, s6, 4
	s_and_b32 s6, s6, -16
	s_lshr_b32 s41, s3, 6
	s_sub_i32 s22, s2, s6
	s_cmp_lg_u32 s2, s6
	s_cselect_b64 s[6:7], -1, 0
	s_cmp_lt_i32 s2, 0
	s_cselect_b64 s[10:11], -1, 0
	s_and_b64 s[6:7], s[10:11], s[6:7]
	s_subb_u32 s23, s13, 0
	s_lshl_b32 s2, s23, 2
	s_ashr_i32 s6, s2, 31
	s_add_u32 s20, s8, s2
	s_addc_u32 s21, s9, s6
	s_lshl_b32 s24, s23, 7
	s_lshl_b32 s25, s41, 5
	v_bfe_u32 v1, v0, 3, 3
	s_add_i32 s2, s25, s24
	v_or_b32_e32 v1, s2, v1
	v_lshlrev_b32_e32 v2, 2, v1
	v_ashrrev_i32_e32 v3, 31, v2
	v_lshl_add_u64 v[2:3], s[4:5], 0, v[2:3]
	global_load_dword v1, v[2:3], off
	global_load_dword v4, v[2:3], off offset:32
	global_load_dword v6, v[2:3], off offset:64
	s_load_dwordx8 s[4:11], s[0:1], 0x0
	global_load_dword v2, v[2:3], off offset:96
	s_mul_i32 s14, s12, 0xe00
	v_mov_b32_e32 v3, s3
	s_mov_b32 s15, 0x27000
	s_waitcnt lgkmcnt(0)
	s_mov_b32 s12, s4
	s_movk_i32 s4, 0xffc0
	v_bfi_b32 v3, s4, v3, v0
	s_lshr_b32 s3, s24, 5
	s_lshl_b32 s4, s41, 10
	s_mul_i32 s18, s16, 0x7000
	s_and_b32 s17, s7, 0xffff
	s_mov_b32 s16, s6
	s_mov_b32 s19, s15
	v_lshlrev_b32_e32 v7, 4, v3
	s_mulk_i32 s3, 0x1c00
	s_add_i32 m0, s4, 0xc000
	s_lshl_b32 s6, s41, 8
	s_and_b32 s13, s5, 0xffff
	v_lshlrev_b32_e32 v3, 2, v3
	buffer_load_dwordx4 v7, s[16:19], s3 offen lds
	s_add_i32 s5, s3, 0x1000
	s_add_i32 m0, s6, 0xd000
	s_movk_i32 s2, 0xe00
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x1400
	s_add_i32 m0, s6, 0xd400
	v_and_b32_e32 v5, 48, v0
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x1800
	s_add_i32 m0, s6, 0xd800
	s_lshl_b32 s28, s41, 12
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x1c00
	s_add_i32 m0, s4, 0xdc00
	v_or_b32_e32 v152, 64, v5
	buffer_load_dwordx4 v7, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x2c00
	s_add_i32 m0, s6, 0xec00
	s_or_b32 s29, s28, 0x400
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x3000
	s_add_i32 m0, s6, 0xf000
	s_or_b32 s30, s28, 0x800
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x3400
	s_add_i32 m0, s6, 0xf400
	s_or_b32 s31, s28, 0xc00
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x3800
	s_add_i32 m0, s4, 0xf800
	s_add_i32 s39, s28, 0x4000
	buffer_load_dwordx4 v7, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x4800
	s_add_i32 m0, s6, 0x10800
	s_add_i32 s40, s28, 0x4400
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x4c00
	s_add_i32 m0, s6, 0x10c00
	s_add_i32 s38, s28, 0x4800
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x5000
	s_add_i32 m0, s6, 0x11000
	s_add_i32 s37, s28, 0x4c00
	buffer_load_dword v3, s[16:19], s5 offen lds
	s_add_i32 s5, s3, 0x5400
	s_add_i32 m0, s4, 0x11400
	s_add_i32 s4, s3, 0x6400
	buffer_load_dwordx4 v7, s[16:19], s5 offen lds
	s_add_i32 m0, s6, 0x12400
	s_add_i32 s35, s28, 0x8000
	buffer_load_dword v3, s[16:19], s4 offen lds
	s_add_i32 s4, s3, 0x6800
	s_add_i32 m0, s6, 0x12800
	s_addk_i32 s3, 0x6c00
	buffer_load_dword v3, s[16:19], s4 offen lds
	s_add_i32 m0, s6, 0x12c00
	s_waitcnt vmcnt(18)
	v_mul_lo_u32 v1, v1, s2
	buffer_load_dword v3, s[16:19], s3 offen lds
	v_lshlrev_b32_e32 v3, 4, v0
	v_and_b32_e32 v3, 0x70, v3
	v_bitop3_b32 v140, v1, v3, v5 bitop3:0xf6
	s_mov_b32 m0, s28
	s_waitcnt vmcnt(18)
	v_mul_lo_u32 v1, v4, s2
	buffer_load_dwordx4 v140, s[12:15], 0 offen lds
	v_bitop3_b32 v141, v1, v3, v152 bitop3:0xf6
	s_mov_b32 m0, s29
	s_waitcnt vmcnt(18)
	v_mul_lo_u32 v1, v6, s2
	buffer_load_dwordx4 v141, s[12:15], 0 offen lds
	v_bitop3_b32 v142, v1, v3, v5 bitop3:0xf6
	s_mov_b32 m0, s30
	s_waitcnt vmcnt(18)
	v_mul_lo_u32 v1, v2, s2
	buffer_load_dwordx4 v142, s[12:15], 0 offen lds
	v_bitop3_b32 v143, v1, v3, v152 bitop3:0xf6
	s_mov_b32 m0, s31
	s_movk_i32 s2, 0x80
	buffer_load_dwordx4 v143, s[12:15], 0 offen lds
	s_mov_b32 m0, s39
	s_add_i32 s36, s28, 0x8400
	buffer_load_dwordx4 v140, s[12:15], s2 offen lds
	s_mov_b32 m0, s40
	s_add_i32 s34, s28, 0x8800
	buffer_load_dwordx4 v141, s[12:15], s2 offen lds
	s_mov_b32 m0, s38
	s_add_i32 s33, s28, 0x8c00
	buffer_load_dwordx4 v142, s[12:15], s2 offen lds
	s_mov_b32 m0, s37
	s_load_dword s42, s[20:21], 0x0
	buffer_load_dwordx4 v143, s[12:15], s2 offen lds
	s_movk_i32 s2, 0x100
	s_mov_b32 m0, s35
	s_mov_b32 s4, s8
	buffer_load_dwordx4 v140, s[12:15], s2 offen lds
	s_mov_b32 m0, s36
	s_lshl_b32 s8, s22, 7
	buffer_load_dwordx4 v141, s[12:15], s2 offen lds
	s_mov_b32 m0, s34
	s_and_b32 s5, s9, 0xffff
	buffer_load_dwordx4 v142, s[12:15], s2 offen lds
	s_mov_b32 m0, s33
	s_add_i32 s8, s25, s8
	buffer_load_dwordx4 v143, s[12:15], s2 offen lds
	s_load_dwordx4 s[0:3], s[0:1], 0x40
	s_waitcnt lgkmcnt(0)
	s_lshl_b32 s9, s42, 12
	s_add_i32 s27, s9, s8
	s_lshl2_add_u32 s8, s22, s41
	v_and_b32_e32 v2, 63, v0
	s_mulk_i32 s27, 0xe00
	s_mul_i32 s9, s42, 0x38000
	s_mulk_i32 s8, 0x700
	v_bfe_u32 v1, v0, 4, 2
	v_and_b32_e32 v134, 15, v0
	s_brev_b32 s6, 42
	s_mov_b32 s7, s15
	s_and_b32 s17, s11, 0xffff
	s_mov_b32 s18, 0x5400000
	s_mov_b32 s16, s10
	s_add_i32 s26, s27, 0x700000
	s_add_i32 s21, s27, 0xe000
	s_add_i32 s20, s27, 0x70e000
	s_movk_i32 s48, 0x700
	s_add_i32 s42, s9, s8
	s_lshl_b32 s45, s41, 11
	v_lshlrev_b32_e32 v145, 4, v2
	s_mov_b32 s8, 0xc000
	s_movk_i32 s11, 0x400
	s_movk_i32 s47, 0x800
	s_movk_i32 s41, 0xc00
	s_movk_i32 s10, 0x4000
	s_mov_b32 s9, 0x8000
	v_lshlrev_b32_e32 v3, 4, v134
	v_lshl_or_b32 v144, v1, 8, v3
	buffer_load_dwordx4 v[116:119], v144, s[4:7], s27 offen
	buffer_load_dwordx4 v[158:161], v144, s[4:7], s27 offen offset:1024
	buffer_load_dwordx4 v[120:123], v144, s[4:7], s26 offen
	buffer_load_dwordx4 v[162:165], v144, s[4:7], s26 offen offset:1024
	buffer_load_dwordx4 v[124:127], v144, s[4:7], s21 offen
	buffer_load_dwordx4 v[166:169], v144, s[4:7], s21 offen offset:1024
	buffer_load_dwordx4 v[128:131], v144, s[4:7], s20 offen
	buffer_load_dwordx4 v[170:173], v144, s[4:7], s20 offen offset:1024
	buffer_load_dwordx4 v[174:177], v144, s[4:7], s27 offen offset:2048
	buffer_load_dwordx4 v[178:181], v144, s[4:7], s27 offen offset:3072
	buffer_load_dwordx4 v[182:185], v144, s[4:7], s26 offen offset:2048
	buffer_load_dwordx4 v[186:189], v144, s[4:7], s26 offen offset:3072
	buffer_load_dwordx4 v[190:193], v144, s[4:7], s21 offen offset:2048
	buffer_load_dwordx4 v[194:197], v144, s[4:7], s21 offen offset:3072
	buffer_load_dwordx4 v[198:201], v144, s[4:7], s20 offen offset:2048
	buffer_load_dwordx4 v[202:205], v144, s[4:7], s20 offen offset:3072
	s_add_i32 s44, s45, 0x13000
	v_lshlrev_b32_e32 v135, 2, v0
	s_lshl_b32 s43, s42, 2
	s_mov_b32 m0, s44
	s_add_i32 s42, s45, 0x13400
	v_and_b32_e32 v139, 0xfc, v135
	buffer_load_dwordx4 v145, s[16:19], s43 offen lds
	s_add_i32 s46, s43, 0x70000
	s_mov_b32 m0, s42
	v_or_b32_e32 v3, 0x11400, v139
	buffer_load_dwordx4 v145, s[16:19], s46 offen lds
	;;#ASMSTART
	s_waitcnt vmcnt(16) lgkmcnt(0)
	;;#ASMEND
	s_barrier
	s_waitcnt vmcnt(30)
	ds_read_b32 v154, v3
	v_lshlrev_b32_e32 v3, 3, v0
	v_lshl_or_b32 v138, v2, 2, s44
	ds_read2st64_b32 v[132:133], v139 offset0:192 offset1:220
	ds_read_b32 v153, v139 offset:63488
	v_and_b32_e32 v3, 0x70, v3
	v_lshlrev_b32_e32 v4, 7, v134
	s_waitcnt vmcnt(0)
	ds_read2st64_b32 v[150:151], v138 offset1:4
	v_bitop3_b32 v136, v4, v3, v5 bitop3:0xf6
	ds_read_b128 v[16:19], v136
	ds_read_b128 v[32:35], v136 offset:2048
	ds_read_b128 v[48:51], v136 offset:4096
	ds_read_b128 v[64:67], v136 offset:6144
	ds_read_b128 v[80:83], v136 offset:8192
	ds_read_b128 v[96:99], v136 offset:10240
	ds_read_b128 v[112:115], v136 offset:12288
	ds_read_b128 v[146:149], v136 offset:14336
	v_bitop3_b32 v137, v4, v152, v3 bitop3:0xf6
	v_or_b32_e32 v72, 0x11500, v139
	ds_read_b128 v[206:209], v137
	ds_read_b128 v[210:213], v137 offset:2048
	ds_read_b128 v[214:217], v137 offset:4096
	ds_read_b128 v[218:221], v137 offset:6144
	ds_read_b128 v[222:225], v137 offset:8192
	ds_read_b128 v[226:229], v137 offset:10240
	ds_read_b128 v[230:233], v137 offset:12288
	ds_read_b128 v[234:237], v137 offset:14336
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	ds_read_b128 v[238:241], v136 offset:18432
	ds_read_b32 v155, v72
	v_or_b32_e32 v156, 0x1000, v144
	buffer_load_dwordx4 a[40:43], v156, s[4:7], s27 offen offset:1024
	ds_read_b128 v[242:245], v136 offset:20480
	ds_read_b128 v[246:249], v136 offset:22528
	ds_read_b128 v[250:253], v136 offset:24576
	ds_read_b128 a[0:3], v136 offset:26624
	ds_read2st64_b32 v[2:3], v139 offset0:221 offset1:249
	ds_read_b128 a[4:7], v136 offset:28672
	ds_read_b128 a[8:11], v136 offset:30720
	ds_read_b128 a[12:15], v137 offset:18432
	ds_read_b128 a[16:19], v137 offset:20480
	s_movk_i32 s46, 0x180
	s_mov_b32 m0, s28
	ds_read_b128 a[20:23], v137 offset:22528
	ds_read_b128 a[24:27], v137 offset:24576
	buffer_load_dwordx4 v140, s[12:15], s46 offen lds
	s_mov_b32 m0, s29
	ds_read_b128 a[28:31], v137 offset:26624
	ds_read_b128 a[32:35], v137 offset:28672
	ds_read_b128 a[36:39], v137 offset:30720
	buffer_load_dwordx4 v141, s[12:15], s46 offen lds
	s_mov_b32 m0, s30
	s_add_i32 s49, s43, 0x400
	buffer_load_dwordx4 v142, s[12:15], s46 offen lds
	s_mov_b32 m0, s31
	v_lshlrev_b32_e32 v1, 10, v1
	buffer_load_dwordx4 v143, s[12:15], s46 offen lds
	s_add_i32 s46, s45, 0x15000
	s_mov_b32 m0, s46
	s_add_i32 s45, s45, 0x15400
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], v[16:19], v[116:119], 0, v132, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[16:19], v[120:123], 0, v132, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[16:19], v[124:127], 0, v132, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], v[16:19], v[128:131], 0, v132, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[32:35], v[116:119], 0, v132, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[32:35], v[120:123], 0, v132, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[32:35], v[124:127], 0, v132, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[32:35], v[128:131], 0, v132, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[48:51], v[116:119], 0, v133, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[48:51], v[120:123], 0, v133, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[48:51], v[124:127], 0, v133, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[48:51], v[128:131], 0, v133, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[64:67], v[116:119], 0, v133, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[64:67], v[120:123], 0, v133, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], v[64:67], v[124:127], 0, v133, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], v[64:67], v[128:131], 0, v133, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], v[80:83], v[116:119], 0, v153, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], v[80:83], v[120:123], 0, v153, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], v[80:83], v[124:127], 0, v153, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[80:83], v[128:131], 0, v153, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[96:99], v[116:119], 0, v153, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[96:99], v[120:123], 0, v153, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[96:99], v[124:127], 0, v153, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[96:99], v[128:131], 0, v153, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], v[112:115], v[116:119], 0, v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], v[112:115], v[120:123], 0, v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[112:115], v[124:127], 0, v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[112:115], v[128:131], 0, v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[146:149], v[116:119], 0, v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[146:149], v[120:123], 0, v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[146:149], v[124:127], 0, v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[146:149], v[128:131], 0, v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[206:209], v[158:161], v[4:7], v132, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[206:209], v[162:165], v[8:11], v132, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 1
	v_or_b32_e32 v4, v152, v134
	v_lshlrev_b32_e32 v4, 2, v4
	ds_read_b32 v152, v4 offset:49152
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[206:209], v[166:169], v[12:15], v132, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[4:5], v138 offset0:1 offset1:5
	buffer_load_dwordx4 v145, s[16:19], s49 offen lds
	s_add_i32 s49, s43, 0x70400
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[206:209], v[170:173], v[16:19], v132, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:16384
	s_mov_b32 m0, s45
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[210:213], v[158:161], v[20:23], v132, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s49 offen lds
	s_movk_i32 s49, 0x200
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[210:213], v[162:165], v[24:27], v132, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[210:213], v[166:169], v[28:31], v132, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[210:213], v[170:173], v[32:35], v132, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v137 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[214:217], v[158:161], v[36:39], v133, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[214:217], v[162:165], v[40:43], v133, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[214:217], v[166:169], v[44:47], v133, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[214:217], v[170:173], v[48:51], v133, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[214:217], v156, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[218:221], v[158:161], v[52:55], v133, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[218:221], v[162:165], v[56:59], v133, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[218:221], v[166:169], v[60:63], v133, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[218:221], v[170:173], v[64:67], v133, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[218:221], v156, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[222:225], v[158:161], v[68:71], v153, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[222:225], v[162:165], v[72:75], v153, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[222:225], v[166:169], v[76:79], v153, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[222:225], v[170:173], v[80:83], v153, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[222:225], v156, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[226:229], v[158:161], v[84:87], v153, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[226:229], v[162:165], v[88:91], v153, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[226:229], v[166:169], v[92:95], v153, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[226:229], v[170:173], v[96:99], v153, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[226:229], v156, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[230:233], v[158:161], v[100:103], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[230:233], v[162:165], v[104:107], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[230:233], v[166:169], v[108:111], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[230:233], v[170:173], v[112:115], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[234:237], v[158:161], v[116:119], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[158:161], v156, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[234:237], v[162:165], v[120:123], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[162:165], v156, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[234:237], v[166:169], v[124:127], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[234:237], v[170:173], v[128:131], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[170:173], v156, s[4:7], s20 offen offset:1024
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	s_waitcnt lgkmcnt(1)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[206:209], v[174:177], v[146:149], v152, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v136 offset:34816
	ds_read_b128 v[234:237], v136 offset:36864
	ds_read_b128 a[44:47], v136 offset:45056
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[206:209], v[182:185], v[6:9], v152, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(7)
	ds_read2st64_b32 v[166:167], v138 offset0:2 offset1:6
	ds_read_b32 v150, v139 offset:64000
	ds_read_b128 a[48:51], v137 offset:36864
	ds_read_b128 a[52:55], v137 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[206:209], v[190:193], v[10:13], v152, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[6:7], v139 offset0:194 offset1:222
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	s_mov_b32 m0, s40
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[206:209], v[198:201], v[14:17], v152, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:38912
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	s_mov_b32 m0, s38
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], v[238:241], v[174:177], v[18:21], v152, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	s_mov_b32 m0, s37
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[238:241], v[182:185], v[22:25], v152, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_movk_i32 s49, 0x280
	s_mov_b32 m0, s35
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[238:241], v[190:193], v[26:29], v152, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[238:241], v[198:201], v[30:33], v152, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v136 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[242:245], v[174:177], v[34:37], v2, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[242:245], v[182:185], v[38:41], v2, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[242:245], v[190:193], v[42:45], v2, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[242:245], v[198:201], v[46:49], v2, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[242:245], v136 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[246:249], v[174:177], v[50:53], v2, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[246:249], v[182:185], v[54:57], v2, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[246:249], v[190:193], v[58:61], v2, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], v[246:249], v[198:201], v[62:65], v2, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[246:249], v136 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], v[250:253], v[174:177], v[66:69], v3, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v68, 0x11600, v139
	ds_read_b32 v168, v68
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], v[250:253], v[182:185], v[70:73], v3, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], v[250:253], v[190:193], v[74:77], v3, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], v[250:253], v[198:201], v[78:81], v3, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[250:253], v137 offset:34816
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], a[0:3], v[174:177], v[82:85], v3, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], a[0:3], v[182:185], v[86:89], v3, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], a[0:3], v[190:193], v[90:93], v3, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], a[0:3], v[198:201], v[94:97], v3, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[0:3], v137 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], a[4:7], v[174:177], v[98:101], v155, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], a[4:7], v[182:185], v[102:105], v155, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], a[4:7], v[190:193], v[106:109], v155, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], a[4:7], v[198:201], v[110:113], v155, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v156, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], a[8:11], v[174:177], v[114:117], v155, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[174:177], v137 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], a[8:11], v[182:185], v[118:121], v155, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[182:185], v136 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], a[8:11], v[190:193], v[122:125], v155, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[190:193], v137 offset:45056
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], a[8:11], v[198:201], v[126:129], v155, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[8:11], v156, s[4:7], s26 offen offset:2048
	ds_read_b128 v[198:201], v137 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], a[12:15], v[178:181], v[16:19], v152, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], a[12:15], v[186:189], v[20:23], v152, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], a[12:15], v[194:197], v[24:27], v152, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], a[12:15], v[202:205], v[28:31], v152, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v156, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], a[16:19], v[178:181], v[32:35], v2, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], a[16:19], v[186:189], v[36:39], v2, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], a[16:19], v[194:197], v[40:43], v2, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], a[16:19], v[202:205], v[44:47], v2, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v156, s[4:7], s20 offen offset:2048
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[210:213], v[186:189], v[146:149], v152, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[210:213], v[194:197], v[8:11], v152, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], a[20:23], v[178:181], v[48:51], v2, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], a[20:23], v[186:189], v[52:55], v2, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], a[20:23], v[194:197], v[56:59], v2, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], a[20:23], v[202:205], v[60:63], v2, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[20:23], v156, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[24:27], v[178:181], v[64:67], v3, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[24:27], v[186:189], v[68:71], v3, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[24:27], v[194:197], v[72:75], v3, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], a[24:27], v[202:205], v[76:79], v3, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[24:27], v156, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], a[28:31], v[186:189], v[84:87], v3, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], a[28:31], v[194:197], v[88:91], v3, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], a[32:35], v[186:189], v[100:103], v155, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], a[32:35], v[194:197], v[104:107], v155, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], a[36:39], v[186:189], v[116:119], v155, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[186:189], v156, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], a[36:39], v[194:197], v[120:123], v155, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[194:197], v156, s[4:7], s20 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[210:213], v[178:181], v[130:133], v152, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[210:213], v[202:205], v[12:15], v152, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v137 offset:32768
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], a[28:31], v[178:181], v[80:83], v3, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v132, 0xdf00, v135
	ds_read_b128 a[56:59], v137 offset:4096
	ds_read_b128 a[60:63], v137 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], a[28:31], v[202:205], v[92:95], v3, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[28:31], v136 offset:4096
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	s_mov_b32 m0, s36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], a[32:35], v[178:181], v[96:99], v155, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	s_mov_b32 m0, s34
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], a[32:35], v[202:205], v[108:111], v155, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[32:35], v136 offset:6144
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	s_mov_b32 m0, s33
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], a[36:39], v[178:181], v[112:115], v155, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v178, v132
	v_or_b32_e32 v132, 0xfb00, v135
	ds_read_b32 v179, v132
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], a[36:39], v[202:205], v[124:127], v155, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v136 offset:2048
	v_or_b32_e32 v132, 0x5700, v135
	ds_read_b128 a[36:39], v136 offset:12288
	s_waitcnt vmcnt(21) lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], v[230:233], v[214:217], v[16:19], v6, v166 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b32 v180, v132 offset:49152
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_movk_i32 s49, 0x300
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[230:233], v[218:221], v[20:23], v6, v167 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s28
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[230:233], v[222:225], v[24:27], v6, v166 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[230:233], v[226:229], v[28:31], v6, v167 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v136 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[206:209], v[214:217], v[48:51], v7, v166 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[206:209], v[218:221], v[52:55], v7, v167 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[206:209], v[222:225], v[56:59], v7, v166 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], v[206:209], v[226:229], v[60:63], v7, v167 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:14336
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[182:185], v[214:217], v[128:131], v6, v166 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[182:185], v[218:221], v[146:149], v6, v167 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[182:185], v[222:225], v[8:11], v6, v166 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[182:185], v[226:229], v[12:15], v6, v167 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_or_b32_e32 v182, 0x2000, v144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], a[44:47], v[214:217], v[96:99], v168, v166 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], a[44:47], v[218:221], v[100:103], v168, v167 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], a[44:47], v[222:225], v[104:107], v168, v166 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], a[44:47], v[226:229], v[108:111], v168, v167 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[44:47], v182, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[246:249], v[214:217], v[112:115], v168, v166 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[246:249], v[218:221], v[116:119], v168, v167 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[246:249], v[222:225], v[120:123], v168, v166 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[246:249], v[226:229], v[2:5], v168, v167 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[246:249], v182, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], v[250:253], a[40:43], v[16:19], v6, v166 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[250:253], v[158:161], v[20:23], v6, v167 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[250:253], v[162:165], v[24:27], v6, v166 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[250:253], v[170:173], v[28:31], v6, v167 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[250:253], v182, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], a[0:3], a[40:43], v[48:51], v7, v166 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], a[0:3], v[158:161], v[52:55], v7, v167 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], a[0:3], v[162:165], v[56:59], v7, v166 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], a[0:3], v[170:173], v[60:63], v7, v167 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[0:3], v182, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[234:237], v[214:217], v[32:35], v7, v166 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[234:237], v[218:221], v[36:39], v7, v167 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[234:237], v[222:225], v[40:43], v7, v166 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[234:237], v[226:229], v[44:47], v7, v167 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[234:237], v136 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], v[238:241], v[214:217], v[64:67], v150, v166 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], v[238:241], v[218:221], v[68:71], v150, v167 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], v[238:241], v[222:225], v[72:75], v150, v166 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], v[238:241], v[226:229], v[76:79], v150, v167 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v137 offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[242:245], v[214:217], v[80:83], v150, v166 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[214:217], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[242:245], v[218:221], v[84:87], v150, v167 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[218:221], v137 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[242:245], v[222:225], v[88:91], v150, v166 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[222:225], v137 offset:14336
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[242:245], v[226:229], v[92:95], v150, v167 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[226:229], v137
	ds_read_b128 v[242:245], v137 offset:6144
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[210:213], a[40:43], v[124:127], v6, v166 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[210:213], v[158:161], v[128:131], v6, v167 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[210:213], v[162:165], v[8:11], v6, v166 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], a[48:51], a[40:43], v[32:35], v7, v166 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], a[48:51], v[158:161], v[36:39], v7, v167 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], a[48:51], v[162:165], v[40:43], v7, v166 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], a[48:51], v[170:173], v[44:47], v7, v167 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[48:51], v182, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[52:55], a[40:43], v[64:67], v150, v166 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[52:55], v[158:161], v[68:71], v150, v167 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[52:55], v[162:165], v[72:75], v150, v166 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], a[52:55], v[170:173], v[76:79], v150, v167 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[174:177], a[40:43], v[80:83], v150, v166 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[174:177], v[158:161], v[84:87], v150, v167 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[174:177], v[162:165], v[88:91], v150, v166 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[174:177], v[170:173], v[92:95], v150, v167 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[190:193], a[40:43], v[96:99], v168, v166 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], v[190:193], v[158:161], v[100:103], v168, v167 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[190:193], v[162:165], v[104:107], v168, v166 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[150:153], v[190:193], v[170:173], v[108:111], v168, v167 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[190:193], v182, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[154:157], v[198:201], a[40:43], v[112:115], v168, v166 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[40:43], v182, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[158:161], v[198:201], v[158:161], v[116:119], v168, v167 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[162:165], v[198:201], v[162:165], v[120:123], v168, v166 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[198:201], v[170:173], v[2:5], v168, v167 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[198:201], v182, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[210:213], v[170:173], v[12:15], v6, v167 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v136
	v_or_b32_e32 v6, 0xc300, v135
	ds_read_b32 v181, v6
	ds_read2st64_b32 v[132:133], v138 offset0:3 offset1:7
	s_waitcnt vmcnt(19) lgkmcnt(0)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[166:169], v[210:213], a[4:7], v[124:127], v181, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_or_b32_e32 v6, 0x11800, v139
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[170:173], v[210:213], a[8:11], v[128:131], v181, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[52:55], v136 offset:18432
	ds_read_b32 v184, v6
	ds_read_b128 a[64:67], v136 offset:20480
	ds_read_b128 a[68:71], v136 offset:28672
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[174:177], v[210:213], a[12:15], v[8:11], v181, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[130:131], v139 offset0:196 offset1:224
	ds_read_b32 v183, v139 offset:64512
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[210:213], a[16:19], v[12:15], v181, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v136 offset:22528
	s_mov_b32 m0, s29
	ds_read_b128 a[72:75], v137 offset:20480
	ds_read_b128 a[76:79], v137 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[202:205], a[4:7], v[16:19], v181, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	s_mov_b32 m0, s30
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[202:205], a[8:11], v[20:23], v181, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	s_mov_b32 m0, s31
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[202:205], a[12:15], v[24:27], v181, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_movk_i32 s49, 0x380
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[202:205], a[16:19], v[28:31], v181, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v136 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], a[28:31], a[4:7], v[32:35], v178, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[28:31], a[8:11], v[36:39], v178, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[28:31], a[12:15], v[40:43], v178, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[28:31], a[16:19], v[44:47], v178, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[28:31], v136 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[32:35], a[4:7], v[48:51], v178, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[32:35], a[8:11], v[52:55], v178, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[32:35], a[12:15], v[56:59], v178, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[32:35], a[16:19], v[60:63], v178, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[32:35], v136 offset:30720
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[230:233], a[4:7], v[64:67], v179, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[230:233], a[8:11], v[68:71], v179, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[230:233], a[12:15], v[72:75], v179, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[234:237], a[4:7], v[80:83], v179, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[234:237], a[8:11], v[84:87], v179, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[234:237], a[12:15], v[88:91], v179, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[234:237], a[16:19], v[92:95], v179, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[234:237], v137 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[230:233], a[16:19], v[76:79], v179, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v137 offset:18432
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[36:39], a[4:7], v[96:99], v180, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[36:39], a[8:11], v[100:103], v180, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[206:209], a[4:7], v[154:157], v180, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[4:7], v137 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[206:209], a[8:11], v[158:161], v180, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 0
	v_or_b32_e32 v156, 0x3000, v144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[206:209], a[12:15], v[162:165], v180, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[158:161], v137 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[206:209], a[16:19], v[2:5], v180, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[206:209], v182, s[4:7], s21 offen offset:2048
	ds_read_b128 v[162:165], v137 offset:30720
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[226:229], a[24:27], v[170:173], v181, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[226:229], v[186:189], v[174:177], v181, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 0
	buffer_load_dwordx4 v[170:173], v182, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[214:217], a[20:23], v[58:61], v179, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[174:177], v182, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[214:217], a[24:27], v[62:65], v179, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[214:217], v[186:189], v[66:69], v179, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[214:217], v[194:197], v[70:73], v179, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[214:217], v182, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[36:39], a[12:15], v[146:149], v180, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], a[36:39], a[16:19], v[150:153], v180, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[226:229], a[20:23], v[166:169], v181, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 1
	ds_read_b128 v[152:155], v136 offset:16384
	ds_read2st64_b32 v[150:151], v138 offset0:32 offset1:36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[226:229], v[194:197], v[122:125], v181, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[226:229], v182, s[4:7], s27 offen offset:3072
	ds_read_b128 v[166:169], v137 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[238:241], a[20:23], v[126:129], v181, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[238:241], a[24:27], v[114:117], v181, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[238:241], v[186:189], v[118:121], v181, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[238:241], v[194:197], v[106:109], v181, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], a[56:59], a[20:23], v[110:113], v178, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[56:59], a[24:27], v[14:17], v178, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[56:59], v[186:189], v[18:21], v178, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[56:59], v[194:197], v[22:25], v178, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[242:245], a[20:23], v[26:29], v178, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[242:245], a[24:27], v[30:33], v178, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[242:245], v[186:189], v[34:37], v178, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[242:245], v[194:197], v[38:41], v178, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[60:63], a[20:23], v[42:45], v179, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[60:63], a[24:27], v[46:49], v179, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[60:63], v[186:189], v[50:53], v179, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[60:63], v[194:197], v[54:57], v179, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[218:221], a[20:23], v[74:77], v180, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[218:221], a[24:27], v[78:81], v180, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[218:221], v[186:189], v[82:85], v180, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[218:221], v[194:197], v[86:89], v180, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[218:221], v182, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[222:225], a[20:23], v[90:93], v180, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[222:225], a[24:27], v[94:97], v180, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[222:225], v[186:189], v[98:101], v180, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[186:189], v182, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[222:225], v[194:197], v[102:105], v180, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[178:181], v182, s[4:7], s20 offen offset:3072
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	s_waitcnt vmcnt(18) lgkmcnt(1)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[152:155], v[246:249], v[2:5], v130, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[36:39], v156, s[4:7], s27 offen offset:1024
	ds_read_b128 v[194:197], v136 offset:34816
	ds_read_b128 v[222:225], v136 offset:36864
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], v[152:155], v[250:253], v[6:9], v130, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v136 offset:38912
	ds_read_b128 v[242:245], v136 offset:40960
	ds_read_b128 a[8:11], v136 offset:43008
	ds_read_b128 a[12:15], v136 offset:45056
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[152:155], a[0:3], v[10:13], v130, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[2:3], v139 offset0:197 offset1:225
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	s_mov_b32 m0, s40
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], a[64:67], v[250:253], v[14:17], v131, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	s_mov_b32 m0, s38
	ds_read_b128 a[16:19], v137 offset:36864
	ds_read_b128 a[20:23], v137 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], a[64:67], a[0:3], v[18:21], v131, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	s_mov_b32 m0, s37
	ds_read_b128 a[24:27], v137 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], a[64:67], a[44:47], v[22:25], v131, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_add_i32 s49, s43, 0x800
	s_mov_b32 m0, s44
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[210:213], v[246:249], v[26:29], v131, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[210:213], v[250:253], v[30:33], v131, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[210:213], a[0:3], v[34:37], v131, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[210:213], a[44:47], v[38:41], v131, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v136 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[202:205], v[246:249], v[42:45], v183, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v44, 0x11900, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[152:155], a[44:47], v[122:125], v130, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b32 v154, v139 offset:64768
	ds_read_b32 v155, v44
	ds_read2st64_b32 v[152:153], v138 offset0:33 offset1:37
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[202:205], v[250:253], v[46:49], v183, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s49 offen lds
	s_add_i32 s49, s43, 0x70800
	s_mov_b32 m0, s42
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[202:205], a[0:3], v[50:53], v183, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s49 offen lds
	s_mov_b32 m0, s35
	s_movk_i32 s49, 0x500
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[202:205], a[44:47], v[54:57], v183, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v137 offset:34816
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], a[28:31], v[246:249], v[58:61], v183, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], a[28:31], v[250:253], v[62:65], v183, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[28:31], a[0:3], v[66:69], v183, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[28:31], a[44:47], v[70:73], v183, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[28:31], v156, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], a[52:55], v[250:253], v[114:117], v130, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[68:71], v[246:249], v[74:77], v184, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], a[68:71], v[250:253], v[78:81], v184, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], a[68:71], a[0:3], v[82:85], v184, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], a[68:71], a[44:47], v[86:89], v184, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], a[32:35], v[246:249], v[90:93], v184, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], a[32:35], v[250:253], v[94:97], v184, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[250:253], v137 offset:45056
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], a[32:35], a[0:3], v[98:101], v184, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], a[32:35], a[44:47], v[102:105], v184, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v156, s[4:7], s21 offen
	s_waitcnt vmcnt(24)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[234:237], a[48:51], v[24:27], v131, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(23)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[234:237], v[190:193], v[28:31], v131, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[234:237], a[40:43], v[32:35], v131, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[234:237], v[198:201], v[36:39], v131, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[234:237], v156, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], a[4:7], a[48:51], v[56:59], v183, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], a[4:7], v[190:193], v[60:63], v183, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[4:7], a[40:43], v[64:67], v183, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[4:7], v[198:201], v[68:71], v183, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v156, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[52:55], a[44:47], v[106:109], v130, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[44:47], v156, s[4:7], s26 offen offset:1024
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], v[166:169], v[190:193], v[4:7], v130, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[230:233], v[190:193], v[114:117], v130, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], a[72:75], v[190:193], v[12:15], v131, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], a[76:79], v[190:193], v[44:47], v183, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], v[158:161], a[48:51], v[72:75], v184, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], v[158:161], v[190:193], v[76:79], v184, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[158:161], a[40:43], v[80:83], v184, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[158:161], v[198:201], v[84:87], v184, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[162:165], a[48:51], v[88:91], v184, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[162:165], v[190:193], v[92:95], v184, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[190:193], v156, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[162:165], a[40:43], v[96:99], v184, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], v[162:165], v[198:201], v[100:103], v184, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[160:163], v156, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[166:169], a[48:51], v[146:149], v130, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[166:169], a[40:43], v[8:11], v130, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[166:169], v[198:201], v[122:125], v130, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[166:169], v136 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[52:55], v[246:249], v[126:129], v130, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], a[52:55], a[0:3], v[118:121], v130, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[0:3], v137 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], a[64:67], v[246:249], v[110:113], v131, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[246:249], v137 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[230:233], a[48:51], v[126:129], v130, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[230:233], a[40:43], v[118:121], v130, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], v[230:233], v[198:201], v[106:109], v130, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v137 offset:32768
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], a[72:75], a[40:43], v[16:19], v131, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v157, v139 offset:65024
	s_waitcnt vmcnt(22)
	ds_read_b128 a[52:55], v137 offset:8192
	buffer_load_dwordx4 v140, s[12:15], s11 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], a[72:75], v[198:201], v[20:23], v131, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_mov_b32 m0, s36
	s_nop 0
	buffer_load_dwordx4 v141, s[12:15], s11 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], a[76:79], a[48:51], v[40:43], v183, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_mov_b32 m0, s34
	s_nop 0
	buffer_load_dwordx4 v142, s[12:15], s11 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], a[76:79], a[40:43], v[48:51], v183, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[40:43], v136 offset:12288
	s_mov_b32 m0, s33
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], a[76:79], v[198:201], v[52:55], v183, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[182:185], v136 offset:2048
	ds_read_b128 v[198:201], v136 offset:4096
	buffer_load_dwordx4 v143, s[12:15], s11 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], a[72:75], a[48:51], v[110:113], v131, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[48:51], v137 offset:4096
	s_movk_i32 s11, 0x480
	s_mov_b32 m0, s28
	s_waitcnt vmcnt(24) lgkmcnt(9)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[166:169], v[170:173], v[146:149], v2, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(23)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[166:169], v[174:177], v[4:7], v2, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[166:169], v[206:209], v[8:11], v2, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 1
	ds_read2st64_b32 v[4:5], v139 offset0:198 offset1:226
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[222:225], v[174:177], v[12:15], v3, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[222:225], v[206:209], v[16:19], v3, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[222:225], v[214:217], v[20:23], v3, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[238:241], v[170:173], v[24:27], v3, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[238:241], v[174:177], v[28:31], v3, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[238:241], v[206:209], v[32:35], v3, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[238:241], v[214:217], v[36:39], v3, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v136 offset:14336
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[242:245], v[170:173], v[40:43], v154, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v42, 0x11a00, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[166:169], v[214:217], v[122:125], v2, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b32 v158, v42
	ds_read_b128 v[164:167], v136 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[242:245], v[174:177], v[44:47], v154, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[242:245], v[206:209], v[48:51], v154, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[242:245], v[214:217], v[52:55], v154, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[242:245], v137 offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[8:11], v[170:173], v[56:59], v154, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[8:11], v[174:177], v[60:63], v154, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[8:11], v[206:209], v[64:67], v154, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[8:11], v[214:217], v[68:71], v154, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[8:11], v137 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[194:197], v[170:173], v[126:129], v2, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[194:197], v[174:177], v[114:117], v2, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[194:197], v[206:209], v[118:121], v2, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], v[194:197], v[214:217], v[104:107], v2, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[194:197], v136 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[222:225], v[170:173], v[108:111], v3, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[222:225], v136 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[12:15], v[170:173], v[72:75], v155, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[12:15], v[174:177], v[76:79], v155, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[12:15], v[206:209], v[80:83], v155, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[12:15], v[214:217], v[84:87], v155, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v156, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[210:213], v[170:173], v[88:91], v155, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[168:171], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[210:213], v[174:177], v[92:95], v155, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[172:175], v137 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[210:213], v[206:209], v[96:99], v155, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v137 offset:14336
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[210:213], v[214:217], v[100:103], v155, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[214:217], v156, s[4:7], s27 offen offset:2048
	ds_read_b128 v[210:213], v137
	s_waitcnt vmcnt(23) lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[230:233], v[226:229], v[130:133], v2, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[230:233], v[218:221], v[146:149], v2, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[230:233], v[186:189], v[6:9], v2, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[230:233], v[178:181], v[122:125], v2, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[230:233], v156, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[246:249], v[226:229], v[54:57], v154, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[246:249], v[218:221], v[58:61], v154, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[246:249], v[186:189], v[62:65], v154, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[246:249], v[178:181], v[66:69], v154, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[246:249], v156, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[202:205], v[226:229], v[126:129], v2, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[202:205], v[186:189], v[116:119], v2, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[202:205], v[178:181], v[104:107], v2, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[16:19], v[226:229], v[108:111], v3, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[16:19], v[218:221], v[10:13], v3, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 1
	v_or_b32_e32 v110, 0xe300, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[16:19], v[186:189], v[14:17], v3, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[16:19], v[178:181], v[18:21], v3, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v156, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[20:23], v[226:229], v[22:25], v3, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[20:23], v[186:189], v[30:33], v3, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[20:23], v[178:181], v[34:37], v3, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[24:27], v[226:229], v[38:41], v154, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[24:27], v[186:189], v[46:49], v154, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[24:27], v[178:181], v[50:53], v154, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[250:253], v[226:229], v[70:73], v155, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[250:253], v[186:189], v[78:81], v155, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[250:253], v[178:181], v[82:85], v155, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], a[0:3], v[226:229], v[86:89], v155, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[226:229], v156, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[0:3], v[186:189], v[94:97], v155, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[186:189], v156, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], a[0:3], v[178:181], v[98:101], v155, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[176:179], v156, s[4:7], s20 offen offset:3072
	v_or_b32_e32 v156, 0x4000, v144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[202:205], v[218:221], v[112:115], v2, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v136
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[20:23], v[218:221], v[26:29], v3, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	ds_read2st64_b32 v[2:3], v138 offset0:34 offset1:38
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[250:253], v[218:221], v[74:77], v155, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v152, v110
	ds_read_b128 v[250:253], v136 offset:20480
	ds_read2st64_b32 v[150:151], v138 offset0:35 offset1:39
	s_waitcnt vmcnt(16) lgkmcnt(3)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[164:167], v[234:237], v[22:25], v5, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[20:23], v137 offset:20480
	buffer_load_dwordx4 v140, s[12:15], s11 offen lds
	s_mov_b32 m0, s29
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[164:167], a[28:31], v[26:29], v5, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s11 offen lds
	s_mov_b32 m0, s30
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[164:167], a[32:35], v[30:33], v5, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s11 offen lds
	s_mov_b32 m0, s31
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[164:167], a[4:7], v[34:37], v5, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[164:167], v136 offset:30720
	buffer_load_dwordx4 v143, s[12:15], s11 offen lds
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[222:225], v[234:237], v[54:57], v157, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 s11, 0x10000
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[222:225], a[28:31], v[58:61], v157, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[222:225], a[32:35], v[62:65], v157, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[222:225], a[4:7], v[66:69], v157, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[222:225], v137 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[202:205], a[32:35], v[6:9], v4, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[202:205], a[4:7], v[120:123], v4, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[182:185], a[28:31], v[112:115], v4, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[182:185], a[32:35], v[116:119], v4, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[182:185], a[4:7], v[102:105], v4, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 1
	v_or_b32_e32 v118, 0xff00, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[198:201], a[32:35], v[14:17], v5, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[198:201], a[4:7], v[18:21], v5, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[194:197], a[32:35], v[46:49], v157, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[194:197], a[4:7], v[50:53], v157, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[40:43], v[234:237], v[70:73], v158, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[40:43], a[28:31], v[74:77], v158, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[40:43], a[32:35], v[78:81], v158, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[40:43], a[4:7], v[82:85], v158, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[40:43], v156, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[238:241], a[32:35], v[94:97], v158, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v156, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[238:241], a[4:7], v[98:101], v158, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v156, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[8:11], a[36:39], v[22:25], v5, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[8:11], a[44:47], v[26:29], v5, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[8:11], v[190:193], v[30:33], v5, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[8:11], v[160:163], v[34:37], v5, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[8:11], v156, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[168:171], a[36:39], v[54:57], v157, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[168:171], a[44:47], v[58:61], v157, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[168:171], v[190:193], v[62:65], v157, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[168:171], v[160:163], v[66:69], v157, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[168:171], v156, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[24:27], v[218:221], v[42:45], v154, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[24:27], v137 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], a[0:3], v[218:221], v[90:93], v155, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v153, v118
	v_or_b32_e32 v118, 0x5b00, v135
	ds_read_b32 v154, v118 offset:49152
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[210:213], v[190:193], v[6:9], v4, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[218:221], v136 offset:18432
	ds_read_b128 a[0:3], v136 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[210:213], v[160:163], v[120:123], v4, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[242:245], v[190:193], v[114:117], v4, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[242:245], v[160:163], v[102:105], v4, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[48:51], v[190:193], v[14:17], v5, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[48:51], v[160:163], v[18:21], v5, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[52:55], v[190:193], v[46:49], v157, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[52:55], v[160:163], v[50:53], v157, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[172:175], a[36:39], v[70:73], v158, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[172:175], a[44:47], v[74:77], v158, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[172:175], v[190:193], v[78:81], v158, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[172:175], v[160:163], v[82:85], v158, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[172:175], v156, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[206:209], v[190:193], v[94:97], v158, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[190:193], v156, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[206:209], v[160:163], v[98:101], v158, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[160:163], v156, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[202:205], v[234:237], v[130:133], v4, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[202:205], a[28:31], v[146:149], v4, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v136 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[198:201], v[234:237], v[106:109], v5, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[198:201], a[28:31], v[10:13], v5, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[198:201], v136 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[182:185], v[234:237], v[124:127], v4, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[180:183], v136 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[194:197], v[234:237], v[38:41], v157, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[238:241], v[234:237], v[86:89], v158, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[234:237], v137 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[210:213], a[36:39], v[128:131], v4, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[210:213], a[44:47], v[146:149], v4, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v136 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[242:245], a[36:39], v[124:127], v4, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[242:245], a[44:47], v[110:113], v4, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v4, 0xc700, v135
	ds_read_b32 v155, v4
	ds_read_b128 v[242:245], v137 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[194:197], a[28:31], v[42:45], v157, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[194:197], v137 offset:18432
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[238:241], a[28:31], v[90:93], v158, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[28:31], v137 offset:28672
	ds_read_b128 v[238:241], v137 offset:30720
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[48:51], a[36:39], v[106:109], v5, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	s_mov_b32 m0, s40
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[52:55], a[36:39], v[38:41], v157, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	s_mov_b32 m0, s38
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[206:209], a[36:39], v[86:89], v158, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v2, 0x10000, v139
	s_waitcnt vmcnt(22)
	ds_read_b128 a[36:39], v136 offset:36864
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	s_waitcnt vmcnt(21) lgkmcnt(10)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[202:205], v[214:217], v[22:25], v152, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s37
	s_nop 0
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[202:205], v[230:233], v[26:29], v152, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_movk_i32 s49, 0x580
	s_mov_b32 m0, s35
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[202:205], a[12:15], v[30:33], v152, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[202:205], v[246:249], v[34:37], v152, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v136 offset:47104
	s_waitcnt lgkmcnt(10)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[198:201], v[214:217], v[54:57], v153, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[198:201], v[230:233], v[58:61], v153, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[198:201], a[12:15], v[62:65], v153, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[198:201], v[246:249], v[66:69], v153, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[198:201], v137 offset:38912
	s_waitcnt lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[210:213], v[214:217], v[128:131], v155, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[210:213], a[12:15], v[6:9], v155, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[210:213], v[246:249], v[118:121], v155, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[218:221], v[214:217], v[122:125], v155, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[218:221], a[12:15], v[114:117], v155, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[218:221], v[246:249], v[102:105], v155, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[250:253], v[214:217], v[106:109], v152, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[250:253], a[12:15], v[14:17], v152, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[250:253], v[246:249], v[18:21], v152, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[180:183], v[214:217], v[38:41], v153, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[180:183], a[12:15], v[46:49], v153, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[180:183], v[246:249], v[50:53], v153, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[0:3], v[214:217], v[70:73], v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[0:3], v[230:233], v[74:77], v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[0:3], a[12:15], v[78:81], v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[0:3], v[246:249], v[82:85], v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[0:3], v156, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[164:167], v[214:217], v[86:89], v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[214:217], v137 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[164:167], a[12:15], v[94:97], v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v156, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[164:167], v[246:249], v[98:101], v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[246:249], v156, s[4:7], s26 offen offset:2048
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[222:225], a[16:19], v[22:25], v152, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[222:225], v[226:229], v[26:29], v152, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[222:225], v[186:189], v[30:33], v152, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[222:225], v[176:179], v[34:37], v152, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[222:225], v156, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[234:237], a[16:19], v[54:57], v153, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[234:237], v[226:229], v[58:61], v153, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[234:237], v[186:189], v[62:65], v153, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[234:237], v[176:179], v[66:69], v153, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[234:237], v156, s[4:7], s20 offen offset:2048
	s_waitcnt lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[242:245], a[16:19], v[126:129], v155, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[242:245], v[186:189], v[6:9], v155, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[242:245], v[176:179], v[118:121], v155, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[194:197], a[16:19], v[122:125], v155, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[194:197], v[186:189], v[114:117], v155, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[194:197], v[176:179], v[102:105], v155, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[20:23], a[16:19], v[106:109], v152, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[20:23], v[186:189], v[14:17], v152, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[20:23], v[176:179], v[18:21], v152, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[24:27], a[16:19], v[38:41], v153, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[24:27], v[186:189], v[46:49], v153, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[24:27], v[176:179], v[50:53], v153, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(5)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[28:31], a[16:19], v[70:73], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[28:31], v[186:189], v[78:81], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[28:31], v[176:179], v[82:85], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(4)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[238:241], a[16:19], v[86:89], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v156, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[238:241], v[186:189], v[94:97], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[184:187], v156, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[238:241], v[176:179], v[98:101], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[176:179], v156, s[4:7], s20 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[48:51], a[44:47], v[10:13], v5, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[4:5], v139 offset0:200 offset1:228
	ds_read_b128 a[48:51], v137 offset:36864
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[218:221], v[230:233], v[110:113], v155, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[218:221], v136 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[210:213], v[230:233], v[146:149], v155, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v136 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[250:253], v[230:233], v[10:13], v152, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[250:253], v136 offset:43008
	ds_read2st64_b32 v[146:147], v138 offset1:4
	v_or_b32_e32 v148, 0x10100, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[194:197], v[226:229], v[110:113], v155, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[194:197], v136 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[52:55], a[44:47], v[42:45], v157, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v157, v2
	v_or_b32_e32 v2, 0x11c00, v139
	ds_read_b128 a[52:55], v137 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[206:209], a[44:47], v[90:93], v158, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:34816
	ds_read_b32 v158, v2
	ds_read_b128 a[44:47], v136 offset:45056
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[242:245], v[226:229], v[130:133], v155, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[242:245], v137 offset:32768
	v_or_b32_e32 v155, 0x6000, v144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[180:183], v[230:233], v[42:45], v153, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[180:183], v137 offset:34816
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[164:167], v[230:233], v[90:93], v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v137 offset:45056
	ds_read_b128 v[164:167], v137 offset:47104
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[20:23], v[226:229], v[10:13], v152, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v152, 0x5000, v144
	s_barrier
	s_waitcnt vmcnt(20)
	ds_read_b128 a[20:23], v136 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[24:27], v[226:229], v[42:45], v153, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v150, v148
	ds_read2st64_b32 v[2:3], v139 offset0:201 offset1:229
	ds_read_b128 a[24:27], v136 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[28:31], v[226:229], v[74:77], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[28:31], v137 offset:4096
	v_or_b32_e32 v148, 0x11d00, v139
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[238:241], v[226:229], v[90:93], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[226:229], v136 offset:2048
	ds_read_b128 v[238:241], v136 offset:4096
	ds_read_b32 v151, v148
	s_waitcnt vmcnt(18) lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[194:197], a[4:7], v[126:129], v4, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[148:149], v138 offset0:1 offset1:5
	s_mov_b32 m0, s36
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[194:197], a[8:11], v[130:133], v4, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	s_mov_b32 m0, s34
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[194:197], a[32:35], v[6:9], v4, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	s_mov_b32 m0, s33
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[194:197], v[168:171], v[118:121], v4, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[194:197], v136 offset:6144
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_add_i32 s49, s43, 0xc00
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[210:213], a[4:7], v[22:25], v5, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s46
	s_nop 0
	buffer_load_dwordx4 v145, s[16:19], s49 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[210:213], a[8:11], v[26:29], v5, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_add_i32 s49, s43, 0x70c00
	s_mov_b32 m0, s45
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[210:213], a[32:35], v[30:33], v5, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s49 offen lds
	s_movk_i32 s49, 0x600
	s_mov_b32 m0, s28
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[210:213], v[168:171], v[34:37], v5, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v136 offset:14336
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[250:253], a[4:7], v[54:57], v157, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[250:253], a[8:11], v[58:61], v157, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[250:253], a[32:35], v[62:65], v157, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[250:253], v[168:171], v[66:69], v157, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[250:253], v137 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[206:209], a[8:11], v[110:113], v4, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[206:209], a[32:35], v[114:117], v4, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[36:39], a[8:11], v[10:13], v5, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[36:39], a[32:35], v[14:17], v5, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[218:221], a[4:7], v[38:41], v157, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[218:221], a[8:11], v[42:45], v157, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[218:221], a[32:35], v[46:49], v157, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[218:221], v[168:171], v[50:53], v157, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[218:221], v137 offset:2048
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[44:47], a[4:7], v[70:73], v158, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[44:47], a[8:11], v[74:77], v158, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[44:47], a[32:35], v[78:81], v158, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[44:47], v[168:171], v[82:85], v158, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[44:47], v152, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[202:205], a[4:7], v[86:89], v158, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[202:205], a[8:11], v[90:93], v158, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[8:11], v137 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[202:205], a[32:35], v[94:97], v158, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v152, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[202:205], v[168:171], v[98:101], v158, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v137
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[242:245], a[40:43], v[126:129], v4, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[242:245], v[172:175], v[130:133], v4, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[242:245], v[190:193], v[6:9], v4, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[242:245], v[160:163], v[118:121], v4, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[242:245], v152, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[198:201], a[40:43], v[22:25], v5, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[198:201], v[172:175], v[26:29], v5, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[198:201], v[190:193], v[30:33], v5, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[198:201], v[160:163], v[34:37], v5, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[198:201], v152, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[214:217], a[40:43], v[54:57], v157, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[214:217], v[172:175], v[58:61], v157, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[214:217], v[190:193], v[62:65], v157, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[214:217], v[160:163], v[66:69], v157, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[214:217], v152, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[180:183], v[172:175], v[110:113], v4, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[48:51], v[172:175], v[10:13], v5, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[52:55], a[40:43], v[38:41], v157, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[52:55], v[172:175], v[42:45], v157, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[52:55], v[190:193], v[46:49], v157, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[52:55], v[160:163], v[50:53], v157, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[230:233], a[40:43], v[70:73], v158, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[230:233], v[172:175], v[74:77], v158, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[230:233], v[190:193], v[78:81], v158, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[230:233], v[160:163], v[82:85], v158, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[230:233], v152, s[4:7], s26 offen offset:1024
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[164:167], a[40:43], v[86:89], v158, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[164:167], v[172:175], v[90:93], v158, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[172:175], v152, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[164:167], v[190:193], v[94:97], v158, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[164:167], v[160:163], v[98:101], v158, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[156:159], v152, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[206:209], a[4:7], v[122:125], v4, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[206:209], v[168:171], v[102:105], v4, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[180:183], a[40:43], v[122:125], v4, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[180:183], v[190:193], v[114:117], v4, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[180:183], v[160:163], v[102:105], v4, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[180:183], v136
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[36:39], a[4:7], v[106:109], v5, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[4:7], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[36:39], v[168:171], v[18:21], v5, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[36:39], v137 offset:8192
	ds_read_b128 v[168:171], v137 offset:14336
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[48:51], v[190:193], v[14:17], v5, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	s_waitcnt vmcnt(22)
	ds_read_b128 v[164:167], v136 offset:20480
	ds_read_b128 v[188:191], v136 offset:24576
	s_waitcnt vmcnt(18) lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[194:197], v[222:225], v[22:25], v3, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	s_mov_b32 m0, s29
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[194:197], v[246:249], v[26:29], v3, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	s_mov_b32 m0, s30
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[194:197], a[0:3], v[30:33], v3, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	s_mov_b32 m0, s31
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[194:197], v[234:237], v[34:37], v3, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:30720
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_movk_i32 s49, 0x680
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[48:51], v[160:163], v[18:21], v5, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[160:163], v136 offset:18432
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[20:23], v[222:225], v[54:57], v150, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[20:23], v[246:249], v[58:61], v150, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[20:23], a[0:3], v[62:65], v150, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[20:23], v[234:237], v[66:69], v150, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[20:23], v137 offset:22528
	s_waitcnt lgkmcnt(8)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[180:183], a[0:3], v[6:9], v2, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[226:229], a[0:3], v[114:117], v2, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[238:241], a[0:3], v[14:17], v3, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[206:209], a[0:3], v[46:49], v150, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[24:27], a[0:3], v[78:81], v151, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[210:213], a[0:3], v[94:97], v151, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[0:3], v152, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[250:253], a[12:15], v[22:25], v3, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[250:253], a[16:19], v[26:29], v3, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[250:253], v[184:187], v[30:33], v3, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[250:253], v[176:179], v[34:37], v3, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[250:253], v152, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[180:183], v[234:237], v[118:121], v2, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[226:229], v[234:237], v[102:105], v2, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[238:241], v[234:237], v[18:21], v3, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[206:209], v[234:237], v[50:53], v150, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[24:27], v[234:237], v[82:85], v151, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[210:213], v[234:237], v[98:101], v151, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[234:237], v152, s[4:7], s27 offen offset:2048
	s_waitcnt lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[4:7], a[12:15], v[54:57], v150, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[4:7], a[16:19], v[58:61], v150, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[4:7], v[184:187], v[62:65], v150, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[4:7], v[176:179], v[66:69], v150, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v152, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[24:27], v[222:225], v[70:73], v151, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[24:27], v[246:249], v[74:77], v151, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[24:27], v152, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[210:213], v[222:225], v[86:89], v151, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[210:213], v[246:249], v[90:93], v151, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v137 offset:30720
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[202:205], v[184:187], v[6:9], v2, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[218:221], v[184:187], v[114:117], v2, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[28:31], v[184:187], v[14:17], v3, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[36:39], v[184:187], v[46:49], v150, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[8:11], a[12:15], v[70:73], v151, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[8:11], a[16:19], v[74:77], v151, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[8:11], v[184:187], v[78:81], v151, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[8:11], v[176:179], v[82:85], v151, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[8:11], v152, s[4:7], s26 offen offset:3072
	s_waitcnt lgkmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[168:171], a[12:15], v[86:89], v151, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[168:171], a[16:19], v[90:93], v151, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[168:171], v[184:187], v[94:97], v151, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[184:187], v152, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[168:171], v[176:179], v[98:101], v151, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[168:171], v152, s[4:7], s20 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[48:51], a[40:43], v[106:109], v5, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v146, 0x10200, v139
	ds_read2st64_b32 v[4:5], v139 offset0:202 offset1:230
	ds_read_b32 v153, v146
	ds_read_b128 a[48:51], v137 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[180:183], v[222:225], v[126:129], v2, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_or_b32_e32 v146, 0x11e00, v139
	ds_read_b32 v154, v146
	ds_read_b128 a[40:43], v137 offset:20480
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[180:183], v[246:249], v[130:133], v2, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[180:183], v136 offset:22528
	v_or_b32_e32 v146, 0xe700, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[226:229], v[222:225], v[122:125], v2, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[226:229], v[246:249], v[110:113], v2, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[226:229], v136 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[238:241], v[222:225], v[106:109], v3, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[238:241], v[246:249], v[10:13], v3, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v136 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[202:205], a[12:15], v[126:129], v2, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[202:205], a[16:19], v[130:133], v2, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[202:205], v[176:179], v[118:121], v2, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v136 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[206:209], v[222:225], v[38:41], v150, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[222:225], v137 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[218:221], a[12:15], v[122:125], v2, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[218:221], a[16:19], v[110:113], v2, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[218:221], v[176:179], v[102:105], v2, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[218:221], v137 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[28:31], a[12:15], v[106:109], v3, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[28:31], a[16:19], v[10:13], v3, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[28:31], v[176:179], v[18:21], v3, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	ds_read2st64_b32 v[2:3], v138 offset0:2 offset1:6
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[206:209], v[246:249], v[42:45], v150, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v137 offset:18432
	ds_read_b128 v[246:249], v137 offset:28672
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[36:39], a[16:19], v[42:45], v150, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	ds_read_b128 a[16:19], v136 offset:45056
	buffer_load_dwordx4 v140, s[12:15], s49 offen lds
	s_waitcnt vmcnt(17) lgkmcnt(3)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[202:205], v[198:201], v[126:129], v4, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s40
	ds_read_b128 a[28:31], v137 offset:36864
	buffer_load_dwordx4 v141, s[12:15], s49 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[202:205], v[242:245], v[130:133], v4, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s38
	s_nop 0
	buffer_load_dwordx4 v142, s[12:15], s49 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[202:205], a[32:35], v[6:9], v4, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s37
	s_nop 0
	buffer_load_dwordx4 v143, s[12:15], s49 offen lds
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[202:205], v[214:217], v[118:121], v4, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[202:205], v136 offset:38912
	s_mov_b32 m0, s35
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[180:183], v[198:201], v[22:25], v5, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[180:183], v[242:245], v[26:29], v5, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[180:183], a[32:35], v[30:33], v5, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[180:183], v[214:217], v[34:37], v5, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[180:183], v136 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[226:229], v[198:201], v[54:57], v153, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[226:229], v[242:245], v[58:61], v153, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[226:229], a[32:35], v[62:65], v153, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[226:229], v[214:217], v[66:69], v153, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[226:229], v137 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[160:163], v[242:245], v[110:113], v4, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[160:163], a[32:35], v[114:117], v4, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[164:167], v[242:245], v[10:13], v5, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[164:167], a[32:35], v[14:17], v5, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[188:191], v[242:245], v[42:45], v153, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[188:191], a[32:35], v[46:49], v153, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[238:241], v[198:201], v[70:73], v154, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[238:241], v[242:245], v[74:77], v154, v3 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[238:241], a[32:35], v[78:81], v154, v2 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[238:241], v[214:217], v[82:85], v154, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v137 offset:45056
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[192:195], v[198:201], v[86:89], v154, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[192:195], v[242:245], v[90:93], v154, v3 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[242:245], v155, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[192:195], a[32:35], v[94:97], v154, v2 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v155, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[192:195], v[214:217], v[98:101], v154, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v137 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[218:221], a[44:47], v[126:129], v4, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[218:221], v[230:233], v[130:133], v4, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[218:221], v[172:175], v[6:9], v4, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[218:221], v[156:159], v[118:121], v4, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[218:221], v155, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[20:23], a[44:47], v[22:25], v5, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[20:23], v[230:233], v[26:29], v5, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[20:23], v[172:175], v[30:33], v5, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[20:23], v[156:159], v[34:37], v5, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[20:23], v155, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[222:225], a[44:47], v[54:57], v153, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[222:225], v[230:233], v[58:61], v153, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[222:225], v[172:175], v[62:65], v153, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[222:225], v[156:159], v[66:69], v153, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[222:225], v155, s[4:7], s20 offen
	s_waitcnt lgkmcnt(8)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[206:209], v[172:175], v[114:117], v4, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[40:43], v[172:175], v[14:17], v5, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[48:51], v[172:175], v[46:49], v153, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[246:249], a[44:47], v[70:73], v154, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[246:249], v[230:233], v[74:77], v154, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[246:249], v[172:175], v[78:81], v154, v2 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[246:249], v[156:159], v[82:85], v154, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[246:249], v155, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[210:213], a[44:47], v[86:89], v154, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[210:213], v[230:233], v[90:93], v154, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[210:213], v[172:175], v[94:97], v154, v2 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[172:175], v155, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[210:213], v[156:159], v[98:101], v154, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[210:213], v155, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[160:163], v[198:201], v[122:125], v4, v2 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[160:163], v[214:217], v[102:105], v4, v3 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[160:163], v136 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[36:39], a[12:15], v[38:41], v150, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[12:15], v136 offset:36864
	ds_read_b32 v148, v146
	v_or_b32_e32 v146, 0x4300, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[36:39], v[176:179], v[50:53], v150, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v149, v146 offset:49152
	v_or_b32_e32 v146, 0x5f00, v135
	ds_read_b128 v[176:179], v136 offset:34816
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[206:209], a[44:47], v[122:125], v4, v2 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v152, v146 offset:49152
	ds_read2st64_b32 v[146:147], v138 offset0:3 offset1:7
	ds_read_b128 a[36:39], v137 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[206:209], v[230:233], v[110:113], v4, v3 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[206:209], v[156:159], v[102:105], v4, v3 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:32768
	v_or_b32_e32 v4, 0xcb00, v135
	ds_read_b32 v150, v4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[164:167], v[198:201], v[106:109], v5, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[164:167], v[214:217], v[18:21], v5, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[164:167], v136 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[188:191], v[198:201], v[38:41], v153, v2 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[196:199], v137 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[188:191], v[214:217], v[50:53], v153, v3 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v137 offset:34816
	ds_read_b128 v[214:217], v137 offset:32768
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[40:43], v[230:233], v[10:13], v5, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	buffer_load_dwordx4 v140, s[12:15], s48 offen lds
	s_mov_b32 m0, s36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[40:43], v[156:159], v[18:21], v5, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s48 offen lds
	s_mov_b32 m0, s34
	s_waitcnt vmcnt(22)
	ds_read_b128 a[52:55], v137 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[48:51], a[44:47], v[38:41], v153, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s48 offen lds
	s_mov_b32 m0, s33
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[48:51], v[230:233], v[42:45], v153, v3 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v136 offset:2048
	buffer_load_dwordx4 v143, s[12:15], s48 offen lds
	s_movk_i32 s48, 0x780
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[48:51], v[156:159], v[50:53], v153, v3 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[48:51], v137 offset:4096
	s_mov_b32 m0, s28
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[40:43], a[44:47], v[106:109], v5, v2 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[40:43], v136 offset:4096
	ds_read_b128 a[44:47], v136 offset:12288
	ds_read2st64_b32 v[2:3], v139 offset0:204 offset1:232
	s_waitcnt vmcnt(23) lgkmcnt(10)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], v[206:209], a[0:3], v[6:9], v150, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], a[12:15], v[250:253], v[10:13], v148, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], a[12:15], a[0:3], v[14:17], v148, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v16, 0x10400, v139
	ds_read_b32 v154, v16
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], a[12:15], a[4:7], v[18:21], v148, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[202:205], v[234:237], v[22:25], v148, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[202:205], v[250:253], v[26:29], v148, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[202:205], a[0:3], v[30:33], v148, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[202:205], a[4:7], v[34:37], v148, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[200:203], v136 offset:14336
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[160:163], v[234:237], v[38:41], v149, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v40, 0x12000, v139
	ds_read_b32 v156, v40
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[160:163], v[250:253], v[42:45], v149, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[160:163], a[0:3], v[46:49], v149, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[160:163], a[4:7], v[50:53], v149, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[158:161], v137 offset:2048
	s_waitcnt lgkmcnt(13)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[164:167], v[234:237], v[54:57], v149, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[164:167], v[250:253], v[58:61], v149, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], v[164:167], a[0:3], v[62:65], v149, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], v[164:167], a[4:7], v[66:69], v149, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[162:165], v137 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[206:209], a[4:7], v[118:121], v150, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[176:179], a[0:3], v[114:117], v150, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[176:179], a[4:7], v[102:105], v150, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[16:19], v[234:237], v[70:73], v152, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[16:19], v[250:253], v[74:77], v152, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], a[16:19], a[0:3], v[78:81], v152, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], a[16:19], a[4:7], v[82:85], v152, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v155, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[180:183], v[234:237], v[86:89], v152, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[180:183], v[250:253], v[90:93], v152, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[180:183], a[0:3], v[94:97], v152, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[0:3], v155, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[180:183], a[4:7], v[98:101], v152, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v155, s[4:7], s21 offen offset:2048
	ds_read_b128 v[180:183], v137 offset:14336
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[226:229], a[24:27], v[20:23], v148, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[226:229], a[8:11], v[24:27], v148, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[226:229], v[184:187], v[28:31], v148, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[226:229], v[168:171], v[32:35], v148, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[226:229], v155, s[4:7], s27 offen offset:2048
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[196:199], a[24:27], v[52:55], v149, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[196:199], a[8:11], v[56:59], v149, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], v[196:199], v[184:187], v[60:63], v149, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], v[196:199], v[168:171], v[64:67], v149, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[196:199], v155, s[4:7], s20 offen offset:2048
	s_waitcnt lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], v[214:217], v[184:187], v[4:7], v150, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[214:217], v[168:171], v[118:121], v150, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[188:191], v[184:187], v[114:117], v150, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], v[188:191], v[168:171], v[102:105], v150, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], a[28:31], v[184:187], v[12:15], v148, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], a[28:31], v[168:171], v[16:19], v148, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], a[36:39], v[184:187], v[44:47], v149, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], a[36:39], v[168:171], v[48:51], v149, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], v[238:241], a[24:27], v[68:71], v152, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], v[238:241], a[8:11], v[72:75], v152, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], v[238:241], v[184:187], v[76:79], v152, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[238:241], v[168:171], v[80:83], v152, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[238:241], v155, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[192:195], v[184:187], v[92:95], v152, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[184:187], v155, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[192:195], v[168:171], v[96:99], v152, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[166:169], v155, s[4:7], s20 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[176:179], v[234:237], v[122:125], v150, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[176:179], v[250:253], v[110:113], v150, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[176:179], v136 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[206:209], v[234:237], v[126:129], v150, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[206:209], v[250:253], v[130:133], v150, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:6144
	ds_read_b128 v[250:253], v137 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[188:191], a[24:27], v[122:125], v150, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[188:191], a[8:11], v[110:113], v150, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v136
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], a[12:15], v[234:237], v[106:109], v148, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[12:15], v136 offset:10240
	ds_read_b128 v[234:237], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[214:217], a[24:27], v[126:129], v150, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[214:217], a[8:11], v[130:133], v150, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[214:217], v137
	ds_read2st64_b32 v[150:151], v138 offset0:32 offset1:36
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], a[28:31], a[8:11], v[8:11], v148, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	buffer_load_dwordx4 v140, s[12:15], s48 offen lds
	s_mov_b32 m0, s29
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], a[36:39], a[24:27], v[36:39], v149, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s48 offen lds
	s_mov_b32 m0, s30
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], a[36:39], a[8:11], v[40:43], v149, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	ds_read_b128 a[36:39], v137 offset:20480
	buffer_load_dwordx4 v142, s[12:15], s48 offen lds
	s_mov_b32 m0, s31
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], a[28:31], a[24:27], v[106:109], v148, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[28:31], v136 offset:28672
	buffer_load_dwordx4 v143, s[12:15], s48 offen lds
	s_add_i32 s48, s43, 0x1000
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[192:195], a[24:27], v[84:87], v152, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[24:27], v136 offset:26624
	s_mov_b32 m0, s44
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[192:195], a[8:11], v[88:91], v152, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:18432
	ds_read_b128 a[8:11], v136 offset:20480
	ds_read2st64_b32 v[152:153], v138 offset0:33 offset1:37
	s_waitcnt vmcnt(20) lgkmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[188:191], a[20:23], v[4:7], v2, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s48 offen lds
	s_add_i32 s48, s43, 0x71000
	s_mov_b32 m0, s42
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[188:191], v[222:225], v[118:121], v2, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[4:5], v139 offset0:205 offset1:233
	buffer_load_dwordx4 v145, s[16:19], s48 offen lds
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[230:233], v[218:221], v[122:125], v2, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[230:233], v[242:245], v[110:113], v2, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[230:233], a[20:23], v[114:117], v2, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], v[230:233], v[222:225], v[100:103], v2, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v136 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[40:43], v[242:245], v[8:11], v3, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[40:43], a[20:23], v[12:15], v3, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v14, 0x10500, v139
	ds_read_b32 v155, v14
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[40:43], v[222:225], v[16:19], v3, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[206:209], v[218:221], v[20:23], v3, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[206:209], v[242:245], v[24:27], v3, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[206:209], a[20:23], v[28:31], v3, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[206:209], v[222:225], v[32:35], v3, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[204:207], v136 offset:30720
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[176:179], v[218:221], v[36:39], v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v38, 0x12100, v139
	ds_read_b32 v157, v38
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[176:179], v[242:245], v[40:43], v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[176:179], a[20:23], v[44:47], v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[176:179], v[222:225], v[48:51], v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[176:179], v137 offset:18432
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[12:15], v[218:221], v[52:55], v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[12:15], v[242:245], v[56:59], v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[12:15], a[20:23], v[60:63], v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[12:15], v[222:225], v[64:67], v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[12:15], v137 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[44:47], v[218:221], v[68:71], v156, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[44:47], v[242:245], v[72:75], v156, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[44:47], a[20:23], v[76:79], v156, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[44:47], v[222:225], v[80:83], v156, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[200:203], v[218:221], v[84:87], v156, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[200:203], v[242:245], v[88:91], v156, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[200:203], a[20:23], v[92:95], v156, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[200:203], v[222:225], v[96:99], v156, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[200:203], v137 offset:30720
	ds_read_b128 v[222:225], v137 offset:16384
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[214:217], v[210:213], v[118:121], v2, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[158:161], a[32:35], v[122:125], v2, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[158:161], v[246:249], v[108:111], v2, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[158:161], v[172:175], v[112:115], v2, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[158:161], v[210:213], v[100:103], v2, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v158, 0x7000, v144
	buffer_load_dwordx4 a[20:23], v158, s[4:7], s26 offen
	buffer_load_dwordx4 a[44:47], v158, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[162:165], a[32:35], v[18:21], v3, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v159, 0x8000, v144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[162:165], v[246:249], v[22:25], v3, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[162:165], v[172:175], v[26:29], v3, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[162:165], v[210:213], v[30:33], v3, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[160:163], v158, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[234:237], a[32:35], v[50:53], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[234:237], v[246:249], v[54:57], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[234:237], v[172:175], v[58:61], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[234:237], v[210:213], v[62:65], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[234:237], v158, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], a[40:43], v[218:221], v[104:107], v3, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[40:43], v137 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[214:217], v[172:175], v[146:149], v2, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], a[48:51], a[32:35], v[104:107], v3, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[48:51], v[246:249], v[6:9], v3, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[48:51], v[172:175], v[10:13], v3, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[48:51], v[210:213], v[14:17], v3, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[48:51], v158, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[52:55], v[172:175], v[42:45], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[250:253], a[32:35], v[66:69], v156, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[250:253], v[246:249], v[70:73], v156, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[250:253], v[172:175], v[74:77], v156, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[250:253], v[210:213], v[78:81], v156, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[250:253], v158, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[180:183], a[32:35], v[82:85], v156, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[180:183], v[246:249], v[86:89], v156, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[180:183], v[172:175], v[90:93], v156, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[170:173], v158, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[180:183], v[210:213], v[94:97], v156, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[180:183], v158, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[188:191], v[218:221], v[126:129], v2, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[218:221], v137 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[188:191], v[242:245], v[130:133], v2, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v136 offset:22528
	ds_read_b128 v[242:245], v137 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[214:217], a[32:35], v[126:129], v2, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[214:217], v[246:249], v[130:133], v2, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[214:217], v136 offset:16384
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[52:55], v[210:213], v[46:49], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	ds_read_b128 v[208:211], v136 offset:34816
	ds_read2st64_b32 v[2:3], v139 offset0:206 offset1:234
	buffer_load_dwordx4 v140, s[12:15], s47 offen lds
	s_waitcnt vmcnt(19) lgkmcnt(2)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[214:217], v[226:229], v[126:129], v4, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s40
	ds_read_b128 a[56:59], v137 offset:40960
	buffer_load_dwordx4 v141, s[12:15], s47 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[214:217], a[0:3], v[130:133], v4, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s38
	s_nop 0
	buffer_load_dwordx4 v142, s[12:15], s47 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[214:217], a[4:7], v[146:149], v4, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s37
	s_nop 0
	buffer_load_dwordx4 v143, s[12:15], s47 offen lds
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[214:217], v[196:199], v[116:119], v4, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[212:215], v136 offset:38912
	s_movk_i32 s47, 0x880
	s_mov_b32 m0, s35
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[188:191], v[226:229], v[18:21], v5, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[188:191], a[0:3], v[22:25], v5, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[188:191], a[4:7], v[26:29], v5, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[188:191], v[196:199], v[30:33], v5, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v136 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[24:27], v[226:229], v[50:53], v155, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[24:27], a[0:3], v[54:57], v155, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[24:27], a[4:7], v[58:61], v155, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[24:27], v[196:199], v[62:65], v155, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[24:27], v137 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[192:195], a[0:3], v[108:111], v4, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[192:195], a[4:7], v[112:115], v4, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v114, 0x10600, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[52:55], a[32:35], v[34:37], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[32:35], v136 offset:45056
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[52:55], v[246:249], v[38:41], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v154, v114
	v_or_b32_e32 v114, 0x12200, v139
	ds_read_b32 v156, v114
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[192:195], v[196:199], v[98:101], v4, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[246:249], v136 offset:36864
	s_waitcnt vmcnt(12)
	ds_read2st64_b32 v[150:151], v138 offset0:34 offset1:38
	ds_read_b128 a[52:55], v137 offset:36864
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[8:11], a[4:7], v[10:13], v5, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[8:11], v[196:199], v[14:17], v5, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[230:233], a[4:7], v[42:45], v155, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[230:233], v[196:199], v[46:49], v155, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[28:31], v[226:229], v[66:69], v157, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[28:31], a[0:3], v[70:73], v157, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[28:31], a[4:7], v[74:77], v157, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[28:31], v[196:199], v[78:81], v157, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[28:31], v158, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[204:207], a[4:7], v[90:93], v157, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v158, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[204:207], v[196:199], v[94:97], v157, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[196:199], v137 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[222:225], a[16:19], v[124:127], v4, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[222:225], v[238:241], v[128:131], v4, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[222:225], v[184:187], v[146:149], v4, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[222:225], v[166:169], v[116:119], v4, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[222:225], v158, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[12:15], a[16:19], v[18:21], v5, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[12:15], v[238:241], v[22:25], v5, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[12:15], v[184:187], v[26:29], v5, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[12:15], v[166:169], v[30:33], v5, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v158, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[218:221], a[16:19], v[50:53], v155, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[218:221], v[238:241], v[54:57], v155, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[218:221], v[184:187], v[58:61], v155, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[218:221], v[166:169], v[62:65], v155, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[216:219], v158, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[176:179], v[184:187], v[110:113], v4, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[176:179], v[166:169], v[98:101], v4, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[36:39], v[184:187], v[10:13], v5, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[36:39], v[166:169], v[14:17], v5, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[40:43], v[184:187], v[42:45], v155, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[40:43], v[166:169], v[46:49], v155, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[242:245], a[16:19], v[66:69], v157, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[242:245], v[238:241], v[70:73], v157, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[242:245], v[184:187], v[74:77], v157, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[242:245], v[166:169], v[78:81], v157, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[242:245], v158, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[200:203], v[184:187], v[90:93], v157, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[184:187], v158, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[200:203], v[166:169], v[94:97], v157, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[164:167], v158, s[4:7], s20 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[192:195], v[226:229], v[120:123], v4, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[8:11], a[0:3], v[6:9], v5, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], a[8:11], v[226:229], v[102:105], v5, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[8:11], v136 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[230:233], v[226:229], v[34:37], v155, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[230:233], a[0:3], v[38:41], v155, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[230:233], v137 offset:34816
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[36:39], v[238:241], v[6:9], v5, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[204:207], v[226:229], v[82:85], v157, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[226:229], v137 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[204:207], a[0:3], v[86:89], v157, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[0:3], v137 offset:45056
	ds_read_b128 v[204:207], v137 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[176:179], a[16:19], v[120:123], v4, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[176:179], v[238:241], v[106:109], v4, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[174:177], v136 offset:32768
	v_or_b32_e32 v4, 0xeb00, v135
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[40:43], a[16:19], v[34:37], v155, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	buffer_load_dwordx4 v140, s[12:15], s47 offen lds
	s_mov_b32 m0, s36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[40:43], v[238:241], v[38:41], v155, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v155, v4
	ds_read_b128 a[40:43], v137 offset:8192
	buffer_load_dwordx4 v141, s[12:15], s47 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], a[36:39], a[16:19], v[102:105], v5, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[36:39], v137 offset:4096
	s_mov_b32 m0, s34
	s_waitcnt vmcnt(21) lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], v[246:249], a[20:23], v[6:9], v3, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s47 offen lds
	s_mov_b32 m0, s33
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[246:249], a[44:47], v[10:13], v3, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s47 offen lds
	s_movk_i32 s47, 0x900
	s_mov_b32 m0, s28
	v_or_b32_e32 v12, 0x4700, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[200:203], a[16:19], v[82:85], v157, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[16:19], v136 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[200:203], v[238:241], v[86:89], v157, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v157, v12 offset:49152
	ds_read_b128 v[200:203], v136 offset:2048
	ds_read_b128 v[238:241], v136 offset:4096
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[246:249], v[234:237], v[14:17], v3, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[152:153], v138 offset0:35 offset1:39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], v[212:215], v[160:163], v[18:21], v3, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[212:215], a[20:23], v[22:25], v3, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[212:215], a[44:47], v[26:29], v3, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[212:215], v[234:237], v[30:33], v3, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[212:215], v136 offset:14336
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[192:195], v[160:163], v[34:37], v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v36, 0x6300, v135
	ds_read_b32 v158, v36 offset:49152
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[192:195], a[20:23], v[38:41], v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[192:195], a[44:47], v[42:45], v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[192:195], v[234:237], v[46:49], v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v137 offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], a[8:11], v[160:163], v[50:53], v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], a[8:11], a[20:23], v[54:57], v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], a[8:11], a[44:47], v[58:61], v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], a[8:11], v[234:237], v[62:65], v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[8:11], v137 offset:6144
	s_waitcnt lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[174:177], v[160:163], v[124:127], v2, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[174:177], a[20:23], v[128:131], v2, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[174:177], a[44:47], v[146:149], v2, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[174:177], v[234:237], v[114:117], v2, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[174:177], v136 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[208:211], a[44:47], v[110:113], v2, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[208:211], v[234:237], v[98:101], v2, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[32:35], v[160:163], v[66:69], v156, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[32:35], a[20:23], v[70:73], v156, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[32:35], a[44:47], v[74:77], v156, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], a[32:35], v[234:237], v[78:81], v156, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v159, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[188:191], v[160:163], v[82:85], v156, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[188:191], a[20:23], v[86:89], v156, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[188:191], a[44:47], v[90:93], v156, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[44:47], v159, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[188:191], v[234:237], v[94:97], v156, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[234:237], v159, s[4:7], s27 offen
	ds_read_b128 v[188:191], v137 offset:14336
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], a[24:27], a[48:51], v[16:19], v3, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], a[24:27], v[250:253], v[20:23], v3, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], a[24:27], v[170:173], v[24:27], v3, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], a[24:27], v[180:183], v[28:31], v3, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[24:27], v159, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[226:229], a[48:51], v[48:51], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[226:229], v[250:253], v[52:55], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[226:229], v[170:173], v[56:59], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], v[226:229], v[180:183], v[60:63], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[226:229], v159, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[204:207], v[170:173], v[130:133], v2, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[204:207], v[180:183], v[114:117], v2, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[230:233], v[170:173], v[110:113], v2, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[230:233], v[180:183], v[98:101], v2, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], a[52:55], v[170:173], v[8:11], v3, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], a[52:55], v[180:183], v[12:15], v3, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], a[56:59], v[170:173], v[40:43], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], a[56:59], v[180:183], v[44:47], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[0:3], a[48:51], v[64:67], v156, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[0:3], v[250:253], v[68:71], v156, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[0:3], v[170:173], v[72:75], v156, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], a[0:3], v[180:183], v[76:79], v156, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[0:3], v159, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[196:199], v[170:173], v[88:91], v156, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[168:171], v159, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[196:199], v[180:183], v[92:95], v156, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[178:181], v159, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[208:211], v[160:163], v[118:121], v2, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[208:211], a[20:23], v[106:109], v2, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[208:211], v136 offset:8192
	ds_read_b128 a[20:23], v137 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[246:249], v[160:163], v[102:105], v3, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[246:249], v136 offset:10240
	ds_read_b128 v[160:163], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[204:207], a[48:51], v[122:125], v2, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[204:207], v[250:253], v[126:129], v2, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[204:207], v136
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[230:233], a[48:51], v[118:121], v2, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[230:233], v[250:253], v[106:109], v2, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v2, 0xcf00, v135
	ds_read_b32 v146, v2
	ds_read_b128 v[230:233], v137
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], a[52:55], v[250:253], v[4:7], v3, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	buffer_load_dwordx4 v140, s[12:15], s47 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], a[56:59], a[48:51], v[32:35], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_mov_b32 m0, s29
	s_nop 0
	buffer_load_dwordx4 v141, s[12:15], s47 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], a[56:59], v[250:253], v[36:39], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	ds_read_b128 a[56:59], v137 offset:24576
	s_mov_b32 m0, s30
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], a[52:55], a[48:51], v[102:105], v3, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[2:3], v139 offset0:208 offset1:236
	ds_read_b128 a[52:55], v137 offset:20480
	buffer_load_dwordx4 v142, s[12:15], s47 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[196:199], a[48:51], v[80:83], v156, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[48:51], v136 offset:28672
	s_mov_b32 m0, s31
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[196:199], v[250:253], v[84:87], v156, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[196:199], v136 offset:18432
	ds_read_b128 v[250:253], v136 offset:20480
	ds_read2st64_b32 v[150:151], v138 offset1:4
	s_waitcnt vmcnt(20) lgkmcnt(8)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[204:207], v[222:225], v[122:125], v146, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s47 offen lds
	s_movk_i32 s47, 0x980
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[204:207], a[4:7], v[126:129], v146, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[204:207], a[12:15], v[130:133], v146, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[204:207], v[216:219], v[114:117], v146, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[204:207], v136 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[200:203], v[222:225], v[118:121], v146, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], v[200:203], a[4:7], v[106:109], v146, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[200:203], a[12:15], v[110:113], v146, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[200:203], v[216:219], v[96:99], v146, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 1
	v_or_b32_e32 v112, 0x10800, v139
	ds_read_b32 v154, v112
	v_or_b32_e32 v112, 0x12400, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], v[238:241], a[4:7], v[4:7], v155, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b32 v156, v112
	ds_read_b128 v[200:203], v136 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], v[238:241], a[12:15], v[8:11], v155, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[238:241], v[216:219], v[12:15], v155, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], v[174:177], v[222:225], v[16:19], v155, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[174:177], a[4:7], v[20:23], v155, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[174:177], a[12:15], v[24:27], v155, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[174:177], v[216:219], v[28:31], v155, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[172:175], v136 offset:30720
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[208:211], v[222:225], v[32:35], v157, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[208:211], a[4:7], v[36:39], v157, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[208:211], a[12:15], v[40:43], v157, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[208:211], v[216:219], v[44:47], v157, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[208:211], v137 offset:18432
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[246:249], v[222:225], v[48:51], v157, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[246:249], a[4:7], v[52:55], v157, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[246:249], a[12:15], v[56:59], v157, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], v[246:249], v[216:219], v[60:63], v157, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[246:249], v137 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[16:19], v[222:225], v[64:67], v158, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[16:19], a[4:7], v[68:71], v158, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[16:19], a[12:15], v[72:75], v158, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], a[16:19], v[216:219], v[76:79], v158, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v159, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[212:215], v[222:225], v[80:83], v158, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[212:215], a[4:7], v[84:87], v158, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[4:7], v137 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[212:215], a[12:15], v[88:91], v158, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v159, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[212:215], v[216:219], v[92:95], v158, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[212:215], v137 offset:30720
	ds_read_b128 v[216:219], v137 offset:16384
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[230:233], a[28:31], v[122:125], v146, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[230:233], v[242:245], v[126:129], v146, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], v[230:233], v[184:187], v[130:133], v146, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[230:233], v[164:167], v[114:117], v146, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[230:233], v159, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[192:195], a[28:31], v[118:121], v146, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], v[192:195], v[242:245], v[104:107], v146, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[192:195], v[184:187], v[108:111], v146, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], v[192:195], v[164:167], v[96:99], v146, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], a[36:39], v[242:245], v[4:7], v155, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[36:39], v[184:187], v[8:11], v155, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[36:39], v[164:167], v[12:15], v155, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[8:11], a[28:31], v[16:19], v155, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[8:11], v[242:245], v[20:23], v155, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[8:11], v[184:187], v[24:27], v155, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[8:11], v[164:167], v[28:31], v155, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[8:11], v159, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[40:43], a[28:31], v[32:35], v157, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[40:43], v[242:245], v[36:39], v157, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[40:43], v[184:187], v[40:43], v157, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[40:43], v[164:167], v[44:47], v157, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[160:163], a[28:31], v[48:51], v157, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[160:163], v[242:245], v[52:55], v157, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[160:163], v[184:187], v[56:59], v157, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[160:163], v[164:167], v[60:63], v157, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[160:163], v159, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[20:23], a[28:31], v[64:67], v158, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[20:23], v[242:245], v[68:71], v158, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[20:23], v[184:187], v[72:75], v158, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[20:23], v[164:167], v[76:79], v158, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[20:23], v159, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[188:191], a[28:31], v[80:83], v158, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[188:191], v[242:245], v[84:87], v158, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[188:191], v[184:187], v[88:91], v158, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[182:185], v159, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[188:191], v[164:167], v[92:95], v158, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[164:167], v159, s[4:7], s20 offen offset:3072
	v_or_b32_e32 v158, 0x9000, v144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], v[238:241], v[222:225], v[100:103], v155, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v136 offset:26624
	ds_read_b128 v[220:223], v137 offset:26624
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_waitcnt vmcnt(17) lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[204:207], v[234:237], v[14:17], v3, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_barrier
	ds_read_b128 v[186:189], v136 offset:34816
	ds_read_b128 v[242:245], v136 offset:36864
	s_waitcnt vmcnt(16)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[204:207], a[24:27], v[18:21], v3, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[4:5], v139 offset0:209 offset1:237
	buffer_load_dwordx4 v140, s[12:15], s47 offen lds
	s_mov_b32 m0, s40
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[204:207], a[32:35], v[22:25], v3, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[40:43], v137 offset:40960
	buffer_load_dwordx4 v141, s[12:15], s47 offen lds
	s_mov_b32 m0, s38
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[204:207], v[226:229], v[26:29], v3, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[204:207], v136 offset:47104
	buffer_load_dwordx4 v142, s[12:15], s47 offen lds
	s_mov_b32 m0, s37
	s_waitcnt lgkmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[238:241], v[234:237], v[46:49], v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s47 offen lds
	s_add_i32 s47, s43, 0x1400
	s_mov_b32 m0, s46
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[238:241], a[24:27], v[50:53], v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_add_i32 s46, s43, 0x71400
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[238:241], a[32:35], v[54:57], v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[238:241], v[226:229], v[58:61], v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v137 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], a[36:39], a[28:31], v[100:103], v155, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[28:31], v136 offset:45056
	ds_read2st64_b32 v[152:153], v138 offset0:1 offset1:5
	ds_read_b128 a[36:39], v137 offset:36864
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[192:195], v[234:237], v[122:125], v2, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s47 offen lds
	s_mov_b32 m0, s45
	s_movk_i32 s45, 0xa00
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[192:195], a[24:27], v[126:129], v2, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s46 offen lds
	s_mov_b32 m0, s35
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[192:195], a[32:35], v[130:133], v2, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[196:199], a[32:35], v[108:111], v2, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[250:253], a[32:35], v[6:9], v3, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[200:203], a[32:35], v[38:41], v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[48:51], a[32:35], v[70:73], v156, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[172:175], a[32:35], v[86:89], v156, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v158, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[192:195], v[226:229], v[112:115], v2, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[190:193], v136 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[196:199], v[226:229], v[96:99], v2, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[250:253], v[226:229], v[10:13], v3, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[200:203], v[226:229], v[42:45], v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[48:51], v[226:229], v[74:77], v156, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[172:175], v[226:229], v[90:93], v156, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[224:227], v158, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[246:249], a[44:47], v[14:17], v3, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[246:249], a[0:3], v[18:21], v3, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[246:249], v[168:171], v[22:25], v3, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[246:249], v[178:181], v[26:29], v3, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[246:249], v158, s[4:7], s26 offen
	s_waitcnt lgkmcnt(10)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[220:223], a[44:47], v[46:49], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[220:223], a[0:3], v[50:53], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[220:223], v[168:171], v[54:57], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[220:223], v[178:181], v[58:61], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[220:223], v158, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], v[196:199], a[24:27], v[104:107], v2, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[48:51], v[234:237], v[62:65], v156, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[48:51], a[24:27], v[66:69], v156, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[48:51], v158, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[250:253], v[234:237], v[100:103], v3, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v102, 0x10900, v139
	ds_read_b32 v155, v102
	v_or_b32_e32 v102, 0x12500, v139
	ds_read_b32 v157, v102
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[216:219], v[168:171], v[128:131], v2, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[216:219], v[178:181], v[112:115], v2, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[208:211], a[0:3], v[104:107], v2, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[208:211], v[168:171], v[108:111], v2, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[208:211], v[178:181], v[94:97], v2, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[52:55], v[168:171], v[6:9], v3, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[52:55], v[178:181], v[10:13], v3, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[56:59], v[168:171], v[38:41], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[56:59], v[178:181], v[42:45], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[4:7], a[44:47], v[62:65], v156, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[4:7], a[0:3], v[66:69], v156, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[4:7], v[168:171], v[70:73], v156, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[4:7], v[178:181], v[74:77], v156, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v158, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[212:215], v[168:171], v[86:89], v156, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[168:171], v158, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[212:215], v[178:181], v[90:93], v156, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[176:179], v158, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[196:199], v[234:237], v[116:119], v2, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[194:197], v136 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[250:253], a[24:27], v[146:149], v3, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[250:253], v136 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[208:211], a[44:47], v[116:119], v2, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[208:211], v136 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[200:203], v[234:237], v[30:33], v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[172:175], v[234:237], v[78:81], v156, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[234:237], v137 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[216:219], a[44:47], v[120:123], v2, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[216:219], a[0:3], v[124:127], v2, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[216:219], v137 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[172:175], a[24:27], v[82:85], v156, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[172:175], v137 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[200:203], a[24:27], v[34:37], v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[198:201], v137 offset:34816
	ds_read_b128 a[24:27], v137 offset:45056
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], a[52:55], a[44:47], v[98:101], v3, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	buffer_load_dwordx4 v140, s[12:15], s45 offen lds
	s_mov_b32 m0, s36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[56:59], a[44:47], v[30:33], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s45 offen lds
	s_mov_b32 m0, s34
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[212:215], a[44:47], v[78:81], v156, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(24)
	ds_read_b128 a[44:47], v136 offset:12288
	buffer_load_dwordx4 v142, s[12:15], s45 offen lds
	s_mov_b32 m0, s33
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[212:215], a[0:3], v[82:85], v156, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[212:215], v136 offset:2048
	buffer_load_dwordx4 v143, s[12:15], s45 offen lds
	s_movk_i32 s45, 0xa80
	s_waitcnt vmcnt(23) lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[208:211], v[230:233], v[120:123], v4, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s28
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[208:211], a[8:11], v[124:127], v4, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], v[208:211], a[12:15], v[128:131], v4, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[208:211], v[160:163], v[112:115], v4, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[208:211], v136 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[190:193], v[230:233], v[14:17], v5, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[190:193], a[8:11], v[18:21], v5, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[190:193], a[12:15], v[22:25], v5, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[190:193], v[160:163], v[26:29], v5, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[190:193], v136 offset:14336
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[250:253], v[230:233], v[46:49], v155, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[250:253], a[8:11], v[50:53], v155, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[250:253], a[12:15], v[54:57], v155, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[250:253], v[160:163], v[58:61], v155, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[250:253], v137 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[186:189], v[230:233], v[116:119], v4, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v118, 0x10a00, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[56:59], a[0:3], v[34:37], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v154, v118
	v_or_b32_e32 v118, 0x12600, v139
	ds_read_b32 v156, v118
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[186:189], a[12:15], v[106:109], v4, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[56:59], v137 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[186:189], v[160:163], v[94:97], v4, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[242:245], v[230:233], v[98:101], v5, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[242:245], a[12:15], v[6:9], v5, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[242:245], v[160:163], v[10:13], v5, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[194:197], v[230:233], v[30:33], v155, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[194:197], a[12:15], v[38:41], v155, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[194:197], v[160:163], v[42:45], v155, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[28:31], v[230:233], v[62:65], v157, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[28:31], a[12:15], v[70:73], v157, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[28:31], v[160:163], v[74:77], v157, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[204:207], v[230:233], v[78:81], v157, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[228:231], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[204:207], a[8:11], v[82:85], v157, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[204:207], a[12:15], v[86:89], v157, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v158, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[204:207], v[160:163], v[90:93], v157, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[202:205], v158, s[4:7], s27 offen offset:2048
	ds_read_b128 v[160:163], v137 offset:14336
	s_waitcnt lgkmcnt(13)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[216:219], a[16:19], v[120:123], v4, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(22)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[216:219], a[20:23], v[124:127], v4, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[216:219], v[182:185], v[128:131], v4, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[216:219], v[164:167], v[110:113], v4, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[216:219], v158, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[238:241], a[16:19], v[14:17], v5, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[238:241], a[20:23], v[18:21], v5, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[238:241], v[182:185], v[22:25], v5, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[238:241], v[164:167], v[26:29], v5, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[238:241], v158, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[234:237], a[16:19], v[46:49], v155, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[234:237], a[20:23], v[50:53], v155, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[234:237], v[182:185], v[54:57], v155, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[234:237], v[164:167], v[58:61], v155, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[232:235], v158, s[4:7], s20 offen offset:2048
	s_waitcnt lgkmcnt(11)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[198:201], a[16:19], v[114:117], v4, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[198:201], v[182:185], v[106:109], v4, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[198:201], v[164:167], v[94:97], v4, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], a[36:39], a[16:19], v[98:101], v5, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[36:39], v[182:185], v[6:9], v5, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[36:39], v[164:167], v[10:13], v5, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[40:43], a[16:19], v[30:33], v155, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[40:43], v[182:185], v[38:41], v155, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[40:43], v[164:167], v[42:45], v155, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(10)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[24:27], a[16:19], v[62:65], v157, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[24:27], v[182:185], v[70:73], v157, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[24:27], v[164:167], v[74:77], v157, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[172:175], a[16:19], v[78:81], v157, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v158, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[172:175], v[182:185], v[86:89], v157, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[180:183], v158, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[172:175], v[164:167], v[90:93], v157, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[164:167], v158, s[4:7], s20 offen offset:3072
	v_or_b32_e32 v158, 0xa000, v144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], a[52:55], a[0:3], v[146:149], v3, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[0:3], v136 offset:4096
	ds_read2st64_b32 v[2:3], v139 offset0:210 offset1:238
	s_waitcnt vmcnt(20)
	ds_read2st64_b32 v[150:151], v138 offset0:2 offset1:6
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[186:189], a[8:11], v[102:105], v4, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[186:189], v136 offset:8192
	ds_read_b128 a[52:55], v137 offset:4096
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], v[242:245], a[8:11], v[146:149], v5, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[242:245], v136 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[194:197], a[8:11], v[34:37], v155, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[194:197], v137 offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[28:31], a[8:11], v[66:69], v157, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[8:11], v137 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[36:39], a[20:23], v[146:149], v5, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 2
	ds_read_b128 v[146:149], v136
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[40:43], a[20:23], v[34:37], v155, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[198:201], a[20:23], v[102:105], v4, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v4, 0xef00, v135
	ds_read_b128 v[198:201], v137
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	ds_read_b32 v152, v4
	s_waitcnt vmcnt(19) lgkmcnt(8)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[4:7], a[0:3], a[32:35], v[6:9], v3, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[28:31], v136 offset:28672
	ds_read_b128 a[36:39], v137 offset:20480
	ds_read_b128 a[40:43], v137 offset:24576
	v_or_b32_e32 v8, 0x4b00, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[24:27], a[20:23], v[66:69], v157, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[24:27], v136 offset:22528
	buffer_load_dwordx4 v140, s[12:15], s45 offen lds
	s_mov_b32 m0, s29
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[172:175], a[20:23], v[82:85], v157, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v153, v8 offset:49152
	ds_read_b128 v[172:175], v136 offset:18432
	ds_read_b128 a[20:23], v136 offset:20480
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[8:11], a[0:3], v[220:223], v[10:13], v3, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s45 offen lds
	s_mov_b32 m0, s30
	v_mfma_scale_f32_16x16x128_f8f6f4 v[12:15], v[208:211], v[224:227], v[14:17], v3, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s45 offen lds
	s_mov_b32 m0, s31
	v_mfma_scale_f32_16x16x128_f8f6f4 v[16:19], v[208:211], v[246:249], v[18:21], v3, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s45 offen lds
	s_movk_i32 s45, 0xb00
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[20:23], v[208:211], a[32:35], v[22:25], v3, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[24:27], v[208:211], v[220:223], v[26:29], v3, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[206:209], v136 offset:30720
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[28:31], v[186:189], v[224:227], v[30:33], v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v32, 0x6700, v135
	ds_read_b32 v155, v32 offset:49152
	v_mfma_scale_f32_16x16x128_f8f6f4 v[32:35], v[186:189], v[246:249], v[34:37], v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[36:39], v[186:189], a[32:35], v[38:41], v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[40:43], v[186:189], v[220:223], v[42:45], v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[184:187], v137 offset:18432
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[44:47], v[242:245], v[224:227], v[46:49], v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[48:51], v[242:245], v[246:249], v[50:53], v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[52:55], v[242:245], a[32:35], v[54:57], v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[56:59], v[242:245], v[220:223], v[58:61], v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[242:245], v137 offset:22528
	s_waitcnt lgkmcnt(13)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[146:149], v[224:227], v[118:121], v2, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[146:149], v[246:249], v[122:125], v2, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[146:149], a[32:35], v[126:129], v2, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[146:149], v[220:223], v[110:113], v2, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[212:215], a[32:35], v[106:109], v2, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[212:215], v[220:223], v[94:97], v2, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[60:63], a[44:47], v[224:227], v[62:65], v156, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[64:67], a[44:47], v[246:249], v[66:69], v156, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[68:71], a[44:47], a[32:35], v[70:73], v156, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[72:75], a[44:47], v[220:223], v[74:77], v156, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[44:47], v158, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[76:79], v[190:193], v[224:227], v[78:81], v156, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[80:83], v[190:193], v[246:249], v[82:85], v156, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[84:87], v[190:193], a[32:35], v[86:89], v156, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v158, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[88:91], v[190:193], v[220:223], v[90:93], v156, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[220:223], v158, s[4:7], s27 offen
	ds_read_b128 v[188:191], v137 offset:30720
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], a[52:55], v[168:171], v[4:7], v3, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[52:55], v[176:179], v[8:11], v3, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 0
	ds_read2st64_b32 v[4:5], v138 offset0:3 offset1:7
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[250:253], a[48:51], v[12:15], v3, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[250:253], a[4:7], v[16:19], v3, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[250:253], v[168:171], v[20:23], v3, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[250:253], v[176:179], v[24:27], v3, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[250:253], v158, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[56:59], a[48:51], v[28:31], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[56:59], a[4:7], v[32:35], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[56:59], v[168:171], v[36:39], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[56:59], v[176:179], v[40:43], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[228:231], a[48:51], v[44:47], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[228:231], a[4:7], v[48:51], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[228:231], v[168:171], v[52:55], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[228:231], v[176:179], v[56:59], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[228:231], v158, s[4:7], s20 offen
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[198:201], v[168:171], v[126:129], v2, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[194:197], v[168:171], v[106:109], v2, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[8:11], a[48:51], v[60:63], v156, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[8:11], a[4:7], v[64:67], v156, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[8:11], v[168:171], v[68:71], v156, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[8:11], v[176:179], v[72:75], v156, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[8:11], v158, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[160:163], a[48:51], v[76:79], v156, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[160:163], a[4:7], v[80:83], v156, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[160:163], v[168:171], v[84:87], v156, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[168:171], v158, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[160:163], v[176:179], v[88:91], v156, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[160:163], v158, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[212:215], v[224:227], v[114:117], v2, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[212:215], v[246:249], v[102:105], v2, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[212:215], v136 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], a[0:3], v[224:227], v[98:101], v3, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[224:227], v137 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[0:3], v[246:249], v[130:133], v3, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[0:3], v136 offset:26624
	ds_read_b128 v[246:249], v137 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[194:197], a[48:51], v[114:117], v2, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[194:197], a[4:7], v[102:105], v2, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[92:95], v[194:197], v[176:179], v[94:97], v2, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[198:201], a[48:51], v[118:121], v2, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[198:201], a[4:7], v[122:125], v2, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[198:201], v[176:179], v[110:113], v2, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v2, 0xd300, v135
	ds_read_b32 v157, v2
	ds_read_b128 v[196:199], v137 offset:16384
	s_waitcnt vmcnt(18) lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[24:27], v[202:205], v[10:13], v152, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	ds_read_b128 v[176:179], v136 offset:34816
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[24:27], v[216:219], v[14:17], v152, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[56:59], v137 offset:40960
	buffer_load_dwordx4 v140, s[12:15], s45 offen lds
	s_mov_b32 m0, s40
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[24:27], v[238:241], v[18:21], v152, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s45 offen lds
	s_mov_b32 m0, s38
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[24:27], v[232:235], v[22:25], v152, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[24:27], v136 offset:47104
	buffer_load_dwordx4 v142, s[12:15], s45 offen lds
	s_mov_b32 m0, s37
	s_waitcnt lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[0:3], v[202:205], v[42:45], v153, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s45 offen lds
	s_movk_i32 s45, 0xb80
	s_mov_b32 m0, s35
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[0:3], v[216:219], v[46:49], v153, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[0:3], v[238:241], v[50:53], v153, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[0:3], v[232:235], v[54:57], v153, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[0:3], v137 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[96:99], a[52:55], a[48:51], v[98:101], v3, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[48:51], v136 offset:45056
	s_waitcnt lgkmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[192:195], v[238:241], v[126:129], v157, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[192:195], v[232:235], v[110:113], v157, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[100:103], v[172:175], v[216:219], v[102:105], v157, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[104:107], v[172:175], v[238:241], v[106:109], v157, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[172:175], v[232:235], v[92:95], v157, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], a[20:23], v[238:241], v[146:149], v152, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[20:23], v[232:235], v[6:9], v152, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[212:215], v[238:241], v[34:37], v153, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[212:215], v[232:235], v[38:41], v153, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[28:31], v[202:205], v[58:61], v155, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[28:31], v[216:219], v[62:65], v155, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[28:31], v[238:241], v[66:69], v155, v4 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[28:31], v[232:235], v[70:73], v155, v5 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[28:31], v158, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[206:209], v[238:241], v[82:85], v155, v4 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[236:239], v158, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[206:209], v[232:235], v[86:89], v155, v5 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[232:235], v158, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[242:245], a[12:15], v[10:13], v152, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[242:245], a[16:19], v[14:17], v152, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[242:245], v[180:183], v[18:21], v152, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[242:245], v[164:167], v[22:25], v152, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[240:243], v158, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[224:227], a[12:15], v[42:45], v153, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[224:227], a[16:19], v[46:49], v153, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[224:227], v[180:183], v[50:53], v153, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[224:227], v[164:167], v[54:57], v153, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[224:227], v158, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[20:23], v[202:205], v[96:99], v152, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v98, 0x10c00, v139
	ds_read_b32 v154, v98
	v_or_b32_e32 v98, 0x12800, v139
	ds_read_b32 v156, v98
	s_waitcnt lgkmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[196:199], v[180:183], v[126:129], v157, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[108:111], v[196:199], v[164:167], v[110:113], v157, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[184:187], a[16:19], v[100:103], v157, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[184:187], v[180:183], v[104:107], v157, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[184:187], v[164:167], v[90:93], v157, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], a[36:39], v[180:183], v[146:149], v152, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[36:39], v[164:167], v[6:9], v152, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[40:43], v[180:183], v[34:37], v153, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[40:43], v[164:167], v[38:41], v153, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[246:249], a[12:15], v[58:61], v155, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[246:249], a[16:19], v[62:65], v155, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[246:249], v[180:183], v[66:69], v155, v4 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[246:249], v[164:167], v[70:73], v155, v5 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[244:247], v158, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[188:191], v[180:183], v[82:85], v155, v4 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[180:183], v158, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[188:191], v[164:167], v[86:89], v155, v5 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[164:167], v158, s[4:7], s20 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[52:55], a[4:7], v[130:133], v3, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[4:7], v136 offset:36864
	ds_read2st64_b32 v[2:3], v139 offset0:212 offset1:240
	ds_read2st64_b32 v[150:151], v138 offset0:32 offset1:36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[192:195], v[202:205], v[118:121], v157, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[52:55], v137 offset:36864
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[192:195], v[216:219], v[122:125], v157, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[172:175], v[202:205], v[114:117], v157, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[172:175], v136 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[20:23], v[216:219], v[130:133], v152, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[20:23], v136 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[212:215], v[202:205], v[26:29], v153, v4 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[206:209], v[202:205], v[74:77], v155, v4 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[200:203], v137 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[112:115], v[184:187], a[12:15], v[114:117], v157, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[184:187], v136 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[212:215], v[216:219], v[30:33], v153, v5 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[210:213], v137 offset:34816
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[206:209], v[216:219], v[78:81], v155, v5 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[214:217], v137 offset:45056
	ds_read_b128 v[204:207], v137 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[196:199], a[12:15], v[118:121], v157, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[196:199], a[16:19], v[122:125], v157, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[196:199], v137 offset:32768
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[36:39], a[16:19], v[130:133], v152, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v140, s[12:15], s45 offen lds
	s_mov_b32 m0, s36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[40:43], a[16:19], v[30:33], v153, v5 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s45 offen lds
	s_mov_b32 m0, s34
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[188:191], a[12:15], v[74:77], v155, v4 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s45 offen lds
	s_mov_b32 m0, s33
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[188:191], a[16:19], v[78:81], v155, v5 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v155, 0xb000, v144
	s_waitcnt vmcnt(23)
	ds_read_b128 v[188:191], v136 offset:2048
	ds_read_b128 a[16:19], v136 offset:12288
	s_waitcnt vmcnt(20) lgkmcnt(10)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[192:195], v[220:223], v[10:13], v3, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s45 offen lds
	s_add_i32 s45, s43, 0x1800
	s_mov_b32 m0, s44
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[192:195], v[250:253], v[14:17], v3, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_add_i32 s43, s43, 0x71800
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[192:195], a[32:35], v[18:21], v3, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[192:195], v[228:231], v[22:25], v3, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:14336
	s_waitcnt lgkmcnt(9)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[20:23], v[220:223], v[42:45], v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[20:23], v[250:253], v[46:49], v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[20:23], a[32:35], v[50:53], v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[20:23], v[228:231], v[54:57], v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[20:23], v137 offset:6144
	s_waitcnt lgkmcnt(8)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[116:119], v[184:187], v[220:223], v[118:121], v2, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[120:123], v[184:187], v[250:253], v[122:125], v2, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[124:127], v[184:187], a[32:35], v[126:129], v2, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[184:187], v[228:231], v[108:111], v2, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[184:187], v136 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[176:179], v[220:223], v[112:115], v2, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[176:179], v[250:253], v[98:101], v2, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 1
	v_or_b32_e32 v114, 0x10d00, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[176:179], a[32:35], v[102:105], v2, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[176:179], v[228:231], v[90:93], v2, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[176:179], v136 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[128:131], a[4:7], v[250:253], v[130:133], v3, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[146:149], a[4:7], a[32:35], v[146:149], v3, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[172:175], v[250:253], v[30:33], v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[172:175], a[32:35], v[34:37], v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[48:51], v[220:223], v[58:61], v156, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[48:51], v[250:253], v[62:65], v156, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[48:51], a[32:35], v[66:69], v156, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[48:51], v[228:231], v[70:73], v156, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[24:27], v[220:223], v[74:77], v156, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[24:27], v[250:253], v[78:81], v156, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[252:255], v155, s[4:7], s27 offen
	ds_read_b128 v[248:251], v137 offset:12288
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[24:27], a[32:35], v[82:85], v156, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v155, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], a[24:27], v[228:231], v[86:89], v156, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[24:27], v155, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[0:3], a[44:47], v[10:13], v3, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[0:3], a[8:11], v[14:17], v3, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[0:3], v[168:171], v[18:21], v3, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[0:3], v[160:163], v[22:25], v3, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[0:3], v155, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[200:203], a[44:47], v[42:45], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[200:203], a[8:11], v[46:49], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[200:203], v[168:171], v[50:53], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[200:203], v[160:163], v[54:57], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[200:203], v155, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[36:39], a[12:15], v[94:97], v152, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v152, v114
	v_or_b32_e32 v114, 0x12900, v139
	ds_read_b128 a[36:39], v137 offset:4096
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[40:43], a[12:15], v[26:29], v153, v4 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v153, v114
	ds_read_b128 a[12:15], v136 offset:4096
	ds_read2st64_b32 v[4:5], v139 offset0:213 offset1:241
	s_waitcnt lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[196:199], a[44:47], v[116:119], v2, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[40:43], v137 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[196:199], a[8:11], v[120:123], v2, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[196:199], v[168:171], v[124:127], v2, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[210:213], a[44:47], v[110:113], v2, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[210:213], a[8:11], v[98:101], v2, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[210:213], v[168:171], v[102:105], v2, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[210:213], v[160:163], v[90:93], v2, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[208:211], v137
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[52:55], a[8:11], v[128:131], v3, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[52:55], v[168:171], v[146:149], v3, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[56:59], v[168:171], v[34:37], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 1
	ds_read2st64_b32 v[146:147], v138 offset0:33 offset1:37
	buffer_load_dwordx4 v145, s[16:19], s45 offen lds
	s_mov_b32 m0, s42
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[214:217], a[44:47], v[58:61], v156, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v145, s[16:19], s43 offen lds
	s_mov_b32 m0, s28
	s_movk_i32 s16, 0xc80
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[214:217], a[8:11], v[62:65], v156, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[214:217], v[168:171], v[66:69], v156, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[214:217], v[160:163], v[70:73], v156, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[212:215], v155, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[204:207], a[44:47], v[74:77], v156, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[204:207], a[8:11], v[78:81], v156, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[204:207], v[168:171], v[82:85], v156, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[168:171], v155, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[204:207], v[160:163], v[86:89], v156, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[156:159], v155, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[4:7], v[220:223], v[94:97], v3, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[4:7], v[228:231], v[6:9], v3, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[4:7], v136 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[196:199], v[160:163], v[106:109], v2, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[196:199], v136
	v_or_b32_e32 v2, 0x10e00, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[172:175], v[220:223], v[26:29], v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[218:221], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[172:175], v[228:231], v[38:41], v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[172:175], v137 offset:2048
	ds_read_b128 v[228:231], v137 offset:14336
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[52:55], a[44:47], v[94:97], v3, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	ds_read_b32 v145, v2
	v_or_b32_e32 v2, 0x12a00, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[52:55], v[160:163], v[6:9], v3, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[148:149], v139 offset0:214 offset1:242
	s_waitcnt vmcnt(22)
	ds_read_b128 v[204:207], v136 offset:20480
	ds_read_b128 a[48:51], v137 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[56:59], a[44:47], v[26:29], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[44:47], v137 offset:20480
	buffer_load_dwordx4 v140, s[12:15], s41 offen lds
	s_mov_b32 m0, s29
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[56:59], a[8:11], v[30:33], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[8:11], v136 offset:26624
	buffer_load_dwordx4 v141, s[12:15], s41 offen lds
	s_mov_b32 m0, s30
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[56:59], v[160:163], v[38:41], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[160:163], v136 offset:18432
	ds_read_b32 v154, v2
	s_waitcnt vmcnt(5)
	ds_read2st64_b32 v[150:151], v138 offset0:34 offset1:38
	s_waitcnt lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[196:199], v[232:235], v[114:117], v4, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s41 offen lds
	s_mov_b32 m0, s31
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[196:199], v[236:239], v[118:121], v4, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s41 offen lds
	s_mov_b32 m0, s39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[196:199], v[240:243], v[122:125], v4, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[196:199], v[224:227], v[106:109], v4, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[196:199], v136 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[188:191], v[232:235], v[110:113], v4, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[188:191], v[236:239], v[98:101], v4, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[188:191], v[240:243], v[102:105], v4, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[188:191], v[224:227], v[90:93], v4, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v136 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[12:15], v[232:235], v[94:97], v5, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[12:15], v[236:239], v[126:129], v5, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[12:15], v[240:243], v[130:133], v5, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[12:15], v[224:227], v[6:9], v5, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[12:15], v136 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[184:187], v[232:235], v[10:13], v5, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[184:187], v[236:239], v[14:17], v5, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[184:187], v[240:243], v[18:21], v5, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[184:187], v[224:227], v[22:25], v5, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[184:187], v136 offset:30720
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[176:179], v[232:235], v[26:29], v152, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[176:179], v[236:239], v[30:33], v152, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[176:179], v[240:243], v[34:37], v152, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[176:179], v[224:227], v[38:41], v152, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[176:179], v137 offset:18432
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[4:7], v[232:235], v[42:45], v152, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[4:7], v[236:239], v[46:49], v152, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[4:7], v[240:243], v[50:53], v152, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[4:7], v[224:227], v[54:57], v152, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[4:7], v137 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[16:19], v[232:235], v[58:61], v153, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[16:19], v[236:239], v[62:65], v153, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[16:19], v[240:243], v[66:69], v153, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[16:19], v[224:227], v[70:73], v153, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v155, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[192:195], v[232:235], v[74:77], v153, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[232:235], v137 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[192:195], v[236:239], v[78:81], v153, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[236:239], v137 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[192:195], v[240:243], v[82:85], v153, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[240:243], v155, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[192:195], v[224:227], v[86:89], v153, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[222:225], v155, s[4:7], s27 offen offset:2048
	ds_read_b128 v[192:195], v137 offset:30720
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[208:211], a[28:31], v[114:117], v4, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[208:211], v[244:247], v[118:121], v4, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[208:211], v[180:183], v[122:125], v4, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[208:211], v[164:167], v[106:109], v4, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[208:211], v137 offset:16384
	s_waitcnt lgkmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[172:175], a[28:31], v[110:113], v4, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[172:175], v[244:247], v[98:101], v4, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[172:175], v[180:183], v[102:105], v4, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[172:175], v[164:167], v[90:93], v4, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[172:175], v136 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[36:39], a[28:31], v[94:97], v5, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[36:39], v[244:247], v[126:129], v5, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[36:39], v[180:183], v[130:133], v5, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[36:39], v[164:167], v[6:9], v5, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[20:23], a[28:31], v[10:13], v5, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[20:23], v[244:247], v[14:17], v5, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[20:23], v[180:183], v[18:21], v5, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], a[20:23], v[164:167], v[22:25], v5, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[20:23], v155, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[40:43], a[28:31], v[26:29], v152, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[40:43], v[244:247], v[30:33], v152, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[40:43], v[180:183], v[34:37], v152, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[40:43], v[164:167], v[38:41], v152, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[218:221], a[28:31], v[42:45], v152, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[218:221], v[244:247], v[46:49], v152, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[218:221], v[180:183], v[50:53], v152, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[218:221], v[164:167], v[54:57], v152, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[216:219], v155, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[248:251], a[28:31], v[58:61], v153, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[248:251], v[244:247], v[62:65], v153, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[248:251], v[180:183], v[66:69], v153, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[248:251], v[164:167], v[70:73], v153, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[248:251], v155, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[228:231], a[28:31], v[74:77], v153, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[228:231], v[244:247], v[78:81], v153, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[228:231], v[180:183], v[82:85], v153, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[180:183], v155, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[228:231], v[164:167], v[86:89], v153, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[164:167], v155, s[4:7], s20 offen offset:3072
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	s_waitcnt lgkmcnt(0)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[172:175], v[252:255], v[114:117], v148, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[226:229], v136 offset:34816
	ds_read_b128 v[244:247], v136 offset:36864
	ds_read_b128 a[28:31], v136 offset:45056
	ds_read_b128 a[36:39], v137 offset:36864
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[172:175], a[0:3], v[118:121], v148, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v140, s[12:15], s16 offen lds
	s_mov_b32 m0, s40
	ds_read_b128 a[40:43], v137 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[172:175], a[24:27], v[122:125], v148, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s16 offen lds
	s_mov_b32 m0, s38
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[172:175], v[200:203], v[106:109], v148, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_or_b32_e32 v122, 0xf300, v135
	ds_read_b32 v146, v122
	ds_read_b128 v[172:175], v136 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[160:163], v[252:255], v[110:113], v148, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s16 offen lds
	s_mov_b32 m0, s37
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[160:163], a[0:3], v[98:101], v148, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s16 offen lds
	s_movk_i32 s16, 0xd00
	s_mov_b32 m0, s35
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[160:163], a[24:27], v[102:105], v148, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[160:163], v[200:203], v[90:93], v148, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[160:163], v136 offset:40960
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[208:211], a[32:35], v[86:89], v148, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[208:211], v[212:215], v[114:117], v148, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[208:211], v[168:171], v[118:121], v148, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(16)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[208:211], v[156:159], v[106:109], v148, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[176:179], a[32:35], v[110:113], v148, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[176:179], v[212:215], v[98:101], v148, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[176:179], v[168:171], v[102:105], v148, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[176:179], v[156:159], v[90:93], v148, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v148, 0xc000, v144
	buffer_load_dwordx4 v[208:211], v148, s[4:7], s27 offen
	ds_read_b128 v[176:179], v136 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[204:207], a[0:3], v[126:129], v149, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[204:207], a[24:27], v[130:133], v149, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[196:199], a[24:27], v[18:21], v149, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_nop 1
	v_or_b32_e32 v130, 0x4f00, v135
	ds_read_b32 v152, v130 offset:49152
	v_or_b32_e32 v130, 0x6b00, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[188:191], a[24:27], v[30:33], v145, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b32 v153, v130 offset:49152
	v_or_b32_e32 v130, 0xd700, v135
	ds_read_b32 v147, v130
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[8:11], a[24:27], v[46:49], v145, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[130:131], v138 offset0:35 offset1:39
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[12:15], v[252:255], v[54:57], v154, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[12:15], a[0:3], v[58:61], v154, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[12:15], a[24:27], v[62:65], v154, v150 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[12:15], v[200:203], v[66:69], v154, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v148, s[4:7], s21 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[184:187], a[24:27], v[78:81], v154, v150 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[24:27], v148, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[196:199], v[252:255], v[10:13], v149, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[196:199], a[0:3], v[14:17], v149, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[196:199], v[200:203], v[2:5], v149, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[196:199], v136 offset:47104
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[8:11], v[252:255], v[38:41], v145, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[8:11], a[0:3], v[42:45], v145, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[8:11], v[200:203], v[50:53], v145, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[8:11], v137 offset:38912
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[44:47], v[168:171], v[126:129], v149, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[4:7], v[168:171], v[18:21], v149, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[48:51], v[168:171], v[30:33], v145, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[232:235], v[168:171], v[46:49], v145, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[236:239], v[168:171], v[62:65], v154, v150 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[192:195], v[168:171], v[78:81], v154, v150 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[168:171], v148, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[204:207], v[200:203], v[6:9], v149, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[188:191], v[200:203], v[34:37], v145, v151 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[184:187], v[252:255], v[70:73], v154, v150 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[184:187], a[0:3], v[74:77], v154, v151 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[184:187], v[200:203], v[82:85], v154, v151 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[184:187], v137 offset:47104
	ds_read_b128 v[200:203], v137 offset:32768
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[4:7], a[32:35], v[10:13], v149, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[4:7], v[212:215], v[14:17], v149, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], a[4:7], v[156:159], v[2:5], v149, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[4:7], v148, s[4:7], s26 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[232:235], a[32:35], v[38:41], v145, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[232:235], v[212:215], v[42:45], v145, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[232:235], v[156:159], v[50:53], v145, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[230:233], v148, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[44:47], v[156:159], v[6:9], v149, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[48:51], v[156:159], v[34:37], v145, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[236:239], a[32:35], v[54:57], v154, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[236:239], v[212:215], v[58:61], v154, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[236:239], v[156:159], v[66:69], v154, v151 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[234:237], v148, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[192:195], a[32:35], v[70:73], v154, v150 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[192:195], v[212:215], v[74:77], v154, v151 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[192:195], v[156:159], v[82:85], v154, v151 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[154:157], v148, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[204:207], v[252:255], v[94:97], v149, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[204:207], v136 offset:43008
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[188:191], v[252:255], v[22:25], v145, v150 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[252:255], v137 offset:43008
	s_waitcnt vmcnt(17) lgkmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[172:175], v[222:225], v[10:13], v146, v130 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[172:175], v[240:243], v[14:17], v146, v131 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[172:175], a[16:19], v[18:21], v146, v130 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(15)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[172:175], v[216:219], v[2:5], v146, v131 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(1)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[204:207], v[222:225], v[38:41], v152, v130 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[204:207], v[240:243], v[42:45], v152, v131 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[204:207], a[16:19], v[46:49], v152, v130 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[204:207], v[216:219], v[50:53], v152, v131 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[188:191], a[0:3], v[26:29], v145, v151 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v137 offset:34816
	ds_read_b128 a[0:3], v137 offset:45056
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[176:179], a[16:19], v[118:121], v147, v130 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:2048
	ds_read_b128 v[172:175], v136 offset:14336
	ds_read2st64_b32 v[132:133], v139 offset0:216 offset1:244
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[176:179], v[216:219], v[106:109], v147, v131 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[204:207], v137 offset:6144
	buffer_load_dwordx4 v140, s[12:15], s16 offen lds
	s_mov_b32 m0, s36
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[226:229], a[16:19], v[102:105], v147, v130 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v141, s[12:15], s16 offen lds
	s_mov_b32 m0, s34
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[226:229], v[216:219], v[90:93], v147, v131 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v142, s[12:15], s16 offen lds
	s_mov_b32 m0, s33
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[244:247], a[16:19], v[126:129], v146, v130 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v143, s[12:15], s16 offen lds
	s_movk_i32 s16, 0xd80
	s_mov_b32 m0, s28
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[244:247], v[216:219], v[6:9], v146, v131 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[160:163], a[16:19], v[30:33], v152, v130 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[160:163], v[216:219], v[34:37], v152, v131 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[28:31], a[16:19], v[62:65], v153, v130 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[28:31], v[216:219], v[66:69], v153, v131 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[196:199], a[16:19], v[78:81], v153, v130 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[16:19], v148, s[4:7], s21 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[196:199], v[216:219], v[82:85], v153, v131 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[216:219], v148, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[8:11], a[20:23], v[10:13], v146, v130 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[8:11], v[248:251], v[14:17], v146, v131 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], a[8:11], v[180:183], v[18:21], v146, v130 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], a[8:11], v[164:167], v[2:5], v146, v131 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[8:11], v148, s[4:7], s26 offen offset:2048
	s_waitcnt lgkmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[252:255], a[20:23], v[38:41], v152, v130 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[252:255], v[248:251], v[42:45], v152, v131 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[252:255], v[180:183], v[46:49], v152, v130 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[252:255], v[164:167], v[50:53], v152, v131 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[252:255], v148, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[48:51], a[32:35], v[22:25], v145, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[48:51], v[212:215], v[26:29], v145, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v145, 0x11000, v139
	ds_read_b32 v145, v145
	ds_read_b128 a[48:51], v137 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[28:31], v[222:225], v[54:57], v153, v130 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[28:31], v[240:243], v[58:61], v153, v131 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[28:31], v148, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[44:47], a[32:35], v[94:97], v149, v150 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[32:35], v136 offset:12288
	v_or_b32_e32 v150, 0x12d00, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], a[44:47], v[212:215], v[122:125], v149, v151 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[212:215], v136 offset:4096
	v_or_b32_e32 v149, 0x12c00, v139
	ds_read_b32 v149, v149
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[226:229], v[222:225], v[110:113], v147, v130 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[44:47], v137 offset:4096
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[226:229], v[240:243], v[98:101], v147, v131 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[226:229], v136 offset:8192
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[160:163], v[222:225], v[22:25], v152, v130 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[160:163], v[240:243], v[26:29], v152, v131 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[158:161], v137 offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[200:203], v[180:183], v[118:121], v147, v130 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[200:203], v[164:167], v[106:109], v147, v131 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(13)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[188:191], v[180:183], v[102:105], v147, v130 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[188:191], v[164:167], v[90:93], v147, v131 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[36:39], v[180:183], v[126:129], v146, v130 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[36:39], v[164:167], v[6:9], v146, v131 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[40:43], v[180:183], v[30:33], v152, v130 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[40:43], v[164:167], v[34:37], v152, v131 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(12)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[0:3], a[20:23], v[54:57], v153, v130 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[0:3], v[248:251], v[58:61], v153, v131 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[0:3], v[180:183], v[62:65], v153, v130 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[0:3], v[164:167], v[66:69], v153, v131 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[0:3], v148, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[184:187], v[180:183], v[78:81], v153, v130 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[180:183], v148, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[184:187], v[164:167], v[82:85], v153, v131 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[162:165], v148, s[4:7], s20 offen offset:3072
	v_or_b32_e32 v148, 0x11100, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[176:179], v[222:225], v[86:89], v147, v130 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[176:179], v[240:243], v[114:117], v147, v131 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[176:179], v136 offset:6144
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[244:247], v[222:225], v[94:97], v146, v130 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[244:247], v[240:243], v[122:125], v146, v131 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[244:247], v136 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[188:191], a[20:23], v[110:113], v147, v130 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[188:191], v[248:251], v[98:101], v147, v131 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v136
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[196:199], v[222:225], v[70:73], v153, v130 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[220:223], v137 offset:10240
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[196:199], v[240:243], v[74:77], v153, v131 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[238:241], v137 offset:12288
	ds_read_b128 v[196:199], v137 offset:14336
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[200:203], a[20:23], v[86:89], v147, v130 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[200:203], v[248:251], v[114:117], v147, v131 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[200:203], v137
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[36:39], a[20:23], v[94:97], v146, v130 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], a[36:39], v[248:251], v[122:125], v146, v131 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[146:147], v138 offset1:4
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	s_barrier
	buffer_load_dwordx4 v140, s[12:15], s16 offen lds
	v_or_b32_e32 v140, 0xd000, v144
	s_waitcnt vmcnt(19) lgkmcnt(0)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[188:191], a[12:15], v[118:121], v132, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s29
	ds_read_b32 v148, v148
	buffer_load_dwordx4 v141, s[12:15], s16 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[192:195], a[12:15], v[102:105], v132, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s30
	ds_read_b32 v150, v150
	buffer_load_dwordx4 v142, s[12:15], s16 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[212:215], a[12:15], v[126:129], v133, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_mov_b32 m0, s31
	ds_read_b128 a[36:39], v137 offset:20480
	buffer_load_dwordx4 v143, s[12:15], s16 offen lds
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[176:179], a[12:15], v[18:21], v133, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[226:229], a[12:15], v[30:33], v145, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[244:247], a[12:15], v[46:49], v145, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[32:35], a[12:15], v[62:65], v149, v146 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[172:175], a[12:15], v[78:81], v149, v146 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[12:15], v140, s[4:7], s21 offen
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[200:203], v[168:171], v[118:121], v132, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[158:161], v[168:171], v[102:105], v132, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[44:47], v[168:171], v[126:129], v133, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[204:207], v[168:171], v[18:21], v133, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[48:51], v[168:171], v[30:33], v145, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[220:223], v[168:171], v[46:49], v145, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[238:241], v[168:171], v[62:65], v149, v146 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[196:199], v[168:171], v[78:81], v149, v146 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[166:169], v140, s[4:7], s21 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[244:247], v[208:211], v[38:41], v145, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(21)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[244:247], a[4:7], v[42:45], v145, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[244:247], v[230:233], v[50:53], v145, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[242:245], v137 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[40:43], a[20:23], v[22:25], v152, v130 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[40:43], v[248:251], v[26:29], v152, v131 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[40:43], v137 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[188:191], v[230:233], v[106:109], v132, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[192:195], v[230:233], v[90:93], v132, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[212:215], v[230:233], v[6:9], v133, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[176:179], v[208:211], v[10:13], v133, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[176:179], a[4:7], v[14:17], v133, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[176:179], v[230:233], v[2:5], v133, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[176:179], v136 offset:30720
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[226:229], v[230:233], v[34:37], v145, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[32:35], v[230:233], v[66:69], v149, v147 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[172:175], v[230:233], v[82:85], v149, v147 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[220:223], a[24:27], v[38:41], v145, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[220:223], v[234:237], v[42:45], v145, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[220:223], v[154:157], v[50:53], v145, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[220:223], v140, s[4:7], s20 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[184:187], a[20:23], v[70:73], v153, v130 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 a[20:23], v136 offset:28672
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[184:187], v[248:251], v[74:77], v153, v131 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[130:131], v139 offset0:217 offset1:245
	ds_read_b128 v[184:187], v136 offset:18432
	ds_read_b128 v[248:251], v136 offset:20480
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[226:229], v[208:211], v[22:25], v145, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[226:229], a[4:7], v[26:29], v145, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[228:231], v140, s[4:7], s26 offen
	ds_read_b128 v[224:227], v137 offset:18432
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[200:203], v[154:157], v[106:109], v132, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[158:161], v[154:157], v[90:93], v132, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[44:47], v[154:157], v[6:9], v133, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[204:207], a[24:27], v[10:13], v133, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[204:207], v[234:237], v[14:17], v133, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[204:207], v[154:157], v[2:5], v133, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[204:207], v140, s[4:7], s27 offen
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[48:51], v[154:157], v[34:37], v145, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[238:241], v[154:157], v[66:69], v149, v147 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[196:199], v[154:157], v[82:85], v149, v147 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[152:155], v140, s[4:7], s20 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[32:35], v[208:211], v[54:57], v149, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[32:35], a[4:7], v[58:61], v149, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 a[32:35], v140, s[4:7], s27 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[192:195], v[208:211], v[110:113], v132, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[192:195], a[4:7], v[98:101], v132, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[192:195], v136 offset:24576
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[238:241], a[24:27], v[54:57], v149, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[238:241], v[234:237], v[58:61], v149, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[238:241], v140, s[4:7], s26 offen offset:1024
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[188:191], v[208:211], v[86:89], v132, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[188:191], a[4:7], v[114:117], v132, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[188:191], v136 offset:22528
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[212:215], v[208:211], v[94:97], v133, v146 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[212:215], a[4:7], v[122:125], v133, v147 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[212:215], v136 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[158:161], a[24:27], v[110:113], v132, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[158:161], v[234:237], v[98:101], v132, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[158:161], v136 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[200:203], a[24:27], v[86:89], v132, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[200:203], v[234:237], v[114:117], v132, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b128 v[200:203], v137 offset:16384
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[44:47], a[24:27], v[94:97], v133, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], a[44:47], v[234:237], v[122:125], v133, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[132:133], v138 offset0:1 offset1:5
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[172:175], v[208:211], v[70:73], v149, v146 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 v[208:211], v137 offset:26624
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[172:175], a[4:7], v[74:77], v149, v147 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read_b128 a[4:7], v137 offset:28672
	ds_read_b128 v[172:175], v137 offset:30720
	;;#ASMSTART
	s_waitcnt vmcnt(20)
	;;#ASMEND
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[48:51], a[24:27], v[22:25], v145, v146 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_barrier
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[48:51], v[234:237], v[26:29], v145, v147 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18) lgkmcnt(3)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[158:161], v[216:219], v[86:89], v130, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[158:161], a[8:11], v[114:117], v130, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[158:161], a[16:19], v[118:121], v130, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(16)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[158:161], v[252:255], v[106:109], v130, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[158:161], v140, s[4:7], s27 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[192:195], v[216:219], v[22:25], v148, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[192:195], a[8:11], v[26:29], v148, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[192:195], a[16:19], v[30:33], v148, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[192:195], v[252:255], v[34:37], v148, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[192:195], v140, s[4:7], s27 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[196:199], a[24:27], v[70:73], v149, v146 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[196:199], v[234:237], v[74:77], v149, v147 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[196:199], v140, s[4:7], s26 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[176:179], v[216:219], v[70:73], v150, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[176:179], a[8:11], v[74:77], v150, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[176:179], a[16:19], v[78:81], v150, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[176:179], v[252:255], v[82:85], v150, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[176:179], v140, s[4:7], s26 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[184:187], v[216:219], v[110:113], v130, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[184:187], a[8:11], v[98:101], v130, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[184:187], a[16:19], v[102:105], v130, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[184:187], v[252:255], v[90:93], v130, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[184:187], v140, s[4:7], s21 offen offset:2048
	s_waitcnt vmcnt(20)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[200:203], a[28:31], v[86:89], v130, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(19)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[200:203], a[0:3], v[114:117], v130, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(18)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[200:203], v[180:183], v[118:121], v130, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(17)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[200:203], v[162:165], v[106:109], v130, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[200:203], v140, s[4:7], s21 offen offset:3072
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[212:215], v[216:219], v[38:41], v148, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[212:215], a[8:11], v[42:45], v148, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[212:215], a[16:19], v[46:49], v148, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[212:215], v[252:255], v[50:53], v148, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[248:251], a[8:11], v[122:125], v131, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[248:251], a[16:19], v[126:129], v131, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[248:251], v[252:255], v[6:9], v131, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[188:191], v[216:219], v[10:13], v131, v132 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[188:191], a[8:11], v[14:17], v131, v133 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[188:191], a[16:19], v[18:21], v131, v132 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[188:191], v[252:255], v[2:5], v131, v133 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[188:191], v140, s[4:7], s20 offen offset:2048
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[20:23], v[216:219], v[54:57], v150, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[20:23], a[8:11], v[58:61], v150, v133 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[20:23], a[16:19], v[62:65], v150, v132 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[20:23], v[252:255], v[66:69], v150, v133 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[224:227], a[28:31], v[110:113], v130, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[224:227], a[0:3], v[98:101], v130, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[224:227], v[180:183], v[102:105], v130, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[224:227], v[162:165], v[90:93], v130, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_or_b32_e32 v130, 0x11200, v139
	s_waitcnt lgkmcnt(2)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[208:211], a[28:31], v[38:41], v148, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[208:211], a[0:3], v[42:45], v148, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[208:211], v[180:183], v[46:49], v148, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[208:211], v[162:165], v[50:53], v148, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	buffer_load_dwordx4 v[208:211], v140, s[4:7], s20 offen offset:3072
	;;#ASMSTART
	s_waitcnt vmcnt(8) lgkmcnt(0)
	;;#ASMEND
	s_barrier
	ds_read_b32 v146, v130
	v_or_b32_e32 v130, 0x12e00, v139
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[248:251], v[216:219], v[94:97], v131, v132 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	ds_read2st64_b32 v[144:145], v139 offset0:218 offset1:246
	s_lshl_b32 s6, s22, 6
	s_mov_b32 s4, 0x14000
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], a[36:39], a[0:3], v[122:125], v131, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_mov_b32 s5, 0x18000
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], a[36:39], v[180:183], v[126:129], v131, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], a[36:39], v[162:165], v[6:9], v131, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[242:245], a[28:31], v[10:13], v131, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[242:245], a[0:3], v[14:17], v131, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[242:245], v[180:183], v[18:21], v131, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[242:245], v[162:165], v[2:5], v131, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[40:43], a[28:31], v[22:25], v148, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[40:43], a[0:3], v[26:29], v148, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[40:43], v[180:183], v[30:33], v148, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], a[40:43], v[162:165], v[34:37], v148, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(3)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[4:7], a[28:31], v[54:57], v150, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[4:7], a[0:3], v[58:61], v150, v133 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[4:7], v[180:183], v[62:65], v150, v132 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[4:7], v[162:165], v[66:69], v150, v133 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt lgkmcnt(2)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[172:175], a[28:31], v[70:73], v150, v132 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[172:175], a[0:3], v[74:77], v150, v133 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[172:175], v[180:183], v[78:81], v150, v132 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], v[172:175], v[162:165], v[82:85], v150, v133 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v139, v130
	ds_read_b128 v[140:143], v136 offset:32768
	ds_read_b128 v[162:165], v136 offset:34816
	ds_read_b128 v[170:173], v136 offset:36864
	ds_read_b128 v[180:183], v136 offset:38912
	ds_read_b128 v[212:215], v136 offset:40960
	ds_read_b128 v[216:219], v136 offset:43008
	ds_read_b128 v[224:227], v136 offset:45056
	ds_read_b128 v[232:235], v136 offset:47104
	ds_read_b128 v[242:245], v137 offset:32768
	ds_read_b128 v[246:249], v137 offset:34816
	ds_read_b128 v[250:253], v137 offset:36864
	ds_read_b128 a[0:3], v137 offset:38912
	ds_read_b128 a[4:7], v137 offset:40960
	ds_read_b128 a[8:11], v137 offset:43008
	ds_read_b128 a[16:19], v137 offset:45056
	ds_read_b128 a[20:23], v137 offset:47104
	ds_read2st64_b32 v[148:149], v138 offset0:2 offset1:6
	;;#ASMSTART
	s_waitcnt vmcnt(8) lgkmcnt(0)
	;;#ASMEND
	s_barrier
	s_waitcnt vmcnt(15) lgkmcnt(0)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[180:183], a[12:15], v[18:21], v145, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], a[36:39], a[28:31], v[94:97], v131, v132 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(14)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[130:133], a[0:3], v[166:169], v[18:21], v145, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[212:215], a[12:15], v[30:33], v146, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[216:219], a[12:15], v[46:49], v146, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], a[4:7], v[166:169], v[18:21], v146, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[224:227], a[12:15], v[62:65], v139, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(13)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[170:173], v[220:223], v[6:9], v145, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[232:235], a[12:15], v[78:81], v139, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], a[16:19], v[166:169], v[18:21], v139, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[140:143], v[220:223], v[106:109], v144, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(11)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[140:143], v[204:207], v[86:89], v144, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[140:143], v[228:231], v[114:117], v144, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[140:143], a[12:15], v[118:121], v144, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(10)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[140:143], v[250:253], v[152:155], v[6:9], v145, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[212:215], v[220:223], v[34:37], v146, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[162:165], v[204:207], v[110:113], v144, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[170:173], v[204:207], v[94:97], v145, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[180:183], v[204:207], v[10:13], v145, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[212:215], v[204:207], v[22:25], v146, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[216:219], v[204:207], v[38:41], v146, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[162:165], v[228:231], v[98:101], v144, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[170:173], v[228:231], v[122:125], v145, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[180:183], v[228:231], v[14:17], v145, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[212:215], v[228:231], v[26:29], v146, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[216:219], v[228:231], v[42:45], v146, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[162:165], a[12:15], v[102:105], v144, v148 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[170:173], a[12:15], v[126:129], v145, v148 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[162:165], v[220:223], v[90:93], v144, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[242:245], v[152:155], v[18:21], v144, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[180:183], v[220:223], v[2:5], v145, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[216:219], v[220:223], v[50:53], v146, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], a[4:7], v[152:155], v[6:9], v146, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[224:227], v[220:223], v[66:69], v139, v149 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(9)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[242:245], a[32:35], v[86:89], v144, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[246:249], a[32:35], v[110:113], v144, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[250:253], a[32:35], v[94:97], v145, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], a[0:3], a[32:35], v[10:13], v145, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], a[4:7], a[32:35], v[22:25], v146, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], a[8:11], a[32:35], v[38:41], v146, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(8)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[242:245], v[238:241], v[114:117], v144, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[246:249], v[238:241], v[98:101], v144, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[250:253], v[238:241], v[122:125], v145, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], a[0:3], v[238:241], v[14:17], v145, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], a[4:7], v[238:241], v[26:29], v146, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], a[8:11], v[238:241], v[42:45], v146, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[242:245], v[166:169], v[118:121], v144, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[246:249], v[166:169], v[102:105], v144, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[250:253], v[166:169], v[126:129], v145, v148 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], a[8:11], v[166:169], v[30:33], v146, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[246:249], v[152:155], v[90:93], v144, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], a[0:3], v[152:155], v[2:5], v145, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[144:147], a[8:11], v[152:155], v[18:21], v146, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[232:235], v[220:223], v[82:85], v139, v149 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[224:227], v[228:231], v[58:61], v139, v149 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[232:235], v[228:231], v[74:77], v139, v149 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], a[16:19], v[152:155], v[6:9], v139, v149 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 2
	v_or_b32_e32 v6, 0xdb00, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[82:85], a[20:23], v[152:155], v[18:21], v139, v149 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v154, v6
	v_or_b32_e32 v6, 0xf700, v135
	ds_read_b32 v155, v6
	v_or_b32_e32 v6, 0x5300, v135
	ds_read_b32 v156, v6 offset:49152
	v_or_b32_e32 v6, 0x6f00, v135
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[224:227], v[204:207], v[54:57], v139, v148 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[232:235], v[204:207], v[70:73], v139, v148 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], a[16:19], v[238:241], v[58:61], v139, v149 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], a[20:23], v[238:241], v[74:77], v139, v149 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], a[20:23], v[166:169], v[62:65], v139, v148 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	ds_read_b32 v135, v6 offset:49152
	ds_read_b128 v[162:165], v136
	ds_read_b128 v[166:169], v136 offset:2048
	ds_read_b128 v[170:173], v136 offset:4096
	ds_read_b128 v[180:183], v136 offset:6144
	ds_read_b128 v[204:207], v136 offset:8192
	ds_read_b128 v[212:215], v136 offset:10240
	ds_read_b128 v[216:219], v136 offset:12288
	ds_read_b128 v[220:223], v136 offset:14336
	ds_read_b128 v[224:227], v137
	ds_read_b128 v[228:231], v137 offset:2048
	ds_read_b128 v[232:235], v137 offset:4096
	ds_read_b128 v[236:239], v137 offset:6144
	ds_read_b128 v[240:243], v137 offset:8192
	ds_read_b128 v[244:247], v137 offset:10240
	ds_read_b128 v[248:251], v137 offset:12288
	ds_read_b128 v[252:255], v137 offset:14336
	ds_read2st64_b32 v[152:153], v138 offset0:3 offset1:7
	s_waitcnt lgkmcnt(0)
	s_barrier
	s_waitcnt vmcnt(7)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[162:165], v[158:161], v[86:89], v154, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(6)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[86:89], v[224:227], v[192:195], v[6:9], v154, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[170:173], v[158:161], v[94:97], v155, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[180:183], v[158:161], v[10:13], v155, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], a[16:19], a[32:35], v[54:57], v139, v148 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], a[20:23], a[32:35], v[70:73], v139, v148 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[94:97], v[232:235], v[192:195], v[6:9], v155, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[136:139], v[236:239], v[192:195], v[10:13], v155, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[204:207], v[158:161], v[22:25], v156, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[212:215], v[158:161], v[38:41], v156, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[166:169], v[158:161], v[110:113], v154, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[148:151], v[240:243], v[192:195], v[6:9], v156, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[38:41], v[244:247], v[192:195], v[10:13], v156, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[216:219], v[158:161], v[54:57], v135, v152 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[220:223], v[158:161], v[70:73], v135, v152 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[110:113], v[228:231], v[192:195], v[18:21], v154, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[18:21], v[248:251], v[192:195], v[6:9], v135, v152 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[6:9], v[252:255], v[192:195], v[10:13], v135, v152 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(4)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[162:165], v[176:179], v[114:117], v154, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[54:57], v[224:227], v[196:199], v[10:13], v154, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[170:173], v[176:179], v[122:125], v155, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[180:183], v[176:179], v[14:17], v155, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[166:169], v[176:179], v[98:101], v154, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[98:101], v[232:235], v[196:199], v[10:13], v155, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[114:117], v[236:239], v[196:199], v[14:17], v155, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[204:207], v[176:179], v[26:29], v156, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[212:215], v[176:179], v[42:45], v156, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[122:125], v[240:243], v[196:199], v[10:13], v156, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[34:37], v[244:247], v[196:199], v[14:17], v156, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[216:219], v[176:179], v[58:61], v135, v153 op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[220:223], v[176:179], v[74:77], v135, v153 op_sel:[1,0,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[70:73], v[228:231], v[196:199], v[22:25], v154, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[22:25], v[248:251], v[196:199], v[10:13], v135, v153 op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[10:13], v[252:255], v[196:199], v[14:17], v135, v153 op_sel:[1,0,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(3)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[162:165], v[184:187], v[118:121], v154, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[166:169], v[184:187], v[102:105], v154, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(2)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[58:61], v[224:227], v[200:203], v[14:17], v154, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[170:173], v[184:187], v[126:129], v155, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[74:77], v[228:231], v[200:203], v[26:29], v154, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[180:183], v[184:187], v[130:133], v155, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[102:105], v[232:235], v[200:203], v[14:17], v155, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[204:207], v[184:187], v[46:49], v156, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[118:121], v[236:239], v[200:203], v[26:29], v155, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[212:215], v[184:187], v[30:33], v156, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[126:129], v[240:243], v[200:203], v[14:17], v156, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[216:219], v[184:187], v[78:81], v135, v152 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[220:223], v[184:187], v[62:65], v135, v152 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[42:45], v[244:247], v[200:203], v[26:29], v156, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[26:29], v[248:251], v[200:203], v[14:17], v135, v152 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[14:17], v[252:255], v[200:203], v[30:33], v135, v152 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(1)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[162:165], v[188:191], v[106:109], v154, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[180:183], v[188:191], v[2:5], v155, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	s_waitcnt vmcnt(0)
	v_mfma_scale_f32_16x16x128_f8f6f4 v[62:65], v[224:227], v[208:211], v[30:33], v154, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[170:173], v[188:191], v[140:143], v155, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[106:109], v[236:239], v[208:211], v[2:5], v155, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[204:207], v[188:191], v[50:53], v156, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[166:169], v[188:191], v[90:93], v154, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[90:93], v[232:235], v[208:211], v[30:33], v155, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[212:215], v[188:191], v[144:147], v156, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[50:53], v[240:243], v[208:211], v[2:5], v156, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[216:219], v[188:191], v[66:69], v135, v153 op_sel:[0,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[66:69], v[220:223], v[188:191], v[82:85], v135, v153 op_sel:[1,1,0] op_sel_hi:[0,0,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[78:81], v[228:231], v[208:211], v[46:49], v154, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[46:49], v[244:247], v[208:211], v[30:33], v156, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[30:33], v[248:251], v[208:211], v[2:5], v135, v153 op_sel:[0,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	v_mfma_scale_f32_16x16x128_f8f6f4 v[2:5], v[252:255], v[208:211], v[66:69], v135, v153 op_sel:[1,1,0] op_sel_hi:[1,1,0] cbsz:4 blgp:4
	s_nop 3
	v_or_b32_e32 v66, s25, v134
	v_add_lshl_u32 v1, v66, v1, 2
	ds_write2_b32 v1, v86, v58 offset1:16
	v_add_u32_e32 v58, 0x400, v1
	ds_write2_b32 v58, v87, v59 offset1:16
	v_add_u32_e32 v59, 0x800, v1
	ds_write2_b32 v59, v88, v60 offset1:16
	v_add_u32_e32 v60, 0xc00, v1
	ds_write2_b32 v60, v89, v61 offset1:16
	ds_write2_b32 v1, v54, v62 offset0:128 offset1:144
	ds_write2_b32 v58, v55, v63 offset0:128 offset1:144
	ds_write2_b32 v59, v56, v64 offset0:128 offset1:144
	ds_write2_b32 v60, v57, v65 offset0:128 offset1:144
	v_add_u32_e32 v54, 0x4000, v1
	v_add_u32_e32 v55, 0x4400, v1
	v_add_u32_e32 v56, 0x4800, v1
	v_add_u32_e32 v57, 0x4c00, v1
	ds_write2_b32 v54, v110, v74 offset1:16
	ds_write2_b32 v55, v111, v75 offset1:16
	ds_write2_b32 v56, v112, v76 offset1:16
	ds_write2_b32 v57, v113, v77 offset1:16
	ds_write2_b32 v54, v70, v78 offset0:128 offset1:144
	ds_write2_b32 v55, v71, v79 offset0:128 offset1:144
	ds_write2_b32 v56, v72, v80 offset0:128 offset1:144
	ds_write2_b32 v57, v73, v81 offset0:128 offset1:144
	v_add_u32_e32 v54, 0x8000, v1
	v_add_u32_e32 v55, 0x8400, v1
	v_add_u32_e32 v56, 0x8800, v1
	v_add_u32_e32 v57, 0x8c00, v1
	ds_write2_b32 v54, v94, v102 offset1:16
	ds_write2_b32 v55, v95, v103 offset1:16
	ds_write2_b32 v56, v96, v104 offset1:16
	ds_write2_b32 v57, v97, v105 offset1:16
	ds_write2_b32 v54, v98, v90 offset0:128 offset1:144
	ds_write2_b32 v55, v99, v91 offset0:128 offset1:144
	ds_write2_b32 v56, v100, v92 offset0:128 offset1:144
	ds_write2_b32 v57, v101, v93 offset0:128 offset1:144
	v_add_u32_e32 v54, 0xc000, v1
	v_add_u32_e32 v55, 0xc400, v1
	v_add_u32_e32 v56, 0xc800, v1
	v_add_u32_e32 v57, 0xcc00, v1
	ds_write2_b32 v54, v136, v118 offset1:16
	ds_write2_b32 v55, v137, v119 offset1:16
	ds_write2_b32 v56, v138, v120 offset1:16
	ds_write2_b32 v57, v139, v121 offset1:16
	ds_write2_b32 v54, v114, v106 offset0:128 offset1:144
	ds_write2_b32 v55, v115, v107 offset0:128 offset1:144
	ds_write2_b32 v56, v116, v108 offset0:128 offset1:144
	ds_write2_b32 v57, v117, v109 offset0:128 offset1:144
	v_add_u32_e32 v54, 0x10000, v1
	ds_write_b32 v54, v148
	v_add_u32_e32 v54, 0x10400, v1
	ds_write_b32 v54, v149
	v_add_u32_e32 v54, 0x10800, v1
	ds_write_b32 v54, v150
	v_add_u32_e32 v54, 0x10c00, v1
	ds_write_b32 v54, v151
	v_add_u32_e32 v54, 0x10200, v1
	ds_write_b32 v54, v122
	v_add_u32_e32 v54, 0x10600, v1
	ds_write_b32 v54, v123
	v_add_u32_e32 v54, 0x10a00, v1
	ds_write_b32 v54, v124
	v_add_u32_e32 v54, 0x10e00, v1
	ds_write_b32 v54, v125
	v_add_u32_e32 v54, 0x10040, v1
	ds_write_b32 v54, v126
	v_add_u32_e32 v54, 0x10440, v1
	ds_write_b32 v54, v127
	v_add_u32_e32 v54, 0x10840, v1
	ds_write_b32 v54, v128
	v_add_u32_e32 v54, 0x10c40, v1
	ds_write_b32 v54, v129
	v_add_u32_e32 v54, 0x10240, v1
	ds_write_b32 v54, v50
	v_add_u32_e32 v50, 0x10640, v1
	ds_write_b32 v50, v51
	v_add_u32_e32 v50, 0x10a40, v1
	ds_write_b32 v50, v52
	v_add_u32_e32 v50, 0x10e40, v1
	ds_write_b32 v50, v53
	v_add_u32_e32 v50, 0x14000, v1
	ds_write_b32 v50, v38
	v_add_u32_e32 v38, 0x14400, v1
	ds_write_b32 v38, v39
	v_add_u32_e32 v38, 0x14800, v1
	ds_write_b32 v38, v40
	v_add_u32_e32 v38, 0x14c00, v1
	ds_write_b32 v38, v41
	v_add_u32_e32 v38, 0x14200, v1
	ds_write_b32 v38, v34
	v_add_u32_e32 v34, 0x14600, v1
	ds_write_b32 v34, v35
	v_add_u32_e32 v34, 0x14a00, v1
	ds_write_b32 v34, v36
	v_add_u32_e32 v34, 0x14e00, v1
	ds_write_b32 v34, v37
	v_add_u32_e32 v34, 0x14040, v1
	ds_write_b32 v34, v42
	v_add_u32_e32 v34, 0x14440, v1
	ds_write_b32 v34, v43
	v_add_u32_e32 v34, 0x14840, v1
	ds_write_b32 v34, v44
	v_add_u32_e32 v34, 0x14c40, v1
	ds_write_b32 v34, v45
	v_add_u32_e32 v34, 0x14240, v1
	ds_write_b32 v34, v46
	v_add_u32_e32 v34, 0x14640, v1
	ds_write_b32 v34, v47
	v_add_u32_e32 v34, 0x14a40, v1
	ds_write_b32 v34, v48
	v_add_u32_e32 v34, 0x14e40, v1
	ds_write_b32 v34, v49
	v_add_u32_e32 v34, 0x18000, v1
	ds_write_b32 v34, v18
	v_add_u32_e32 v18, 0x18400, v1
	ds_write_b32 v18, v19
	v_add_u32_e32 v18, 0x18800, v1
	ds_write_b32 v18, v20
	v_add_u32_e32 v18, 0x18c00, v1
	ds_write_b32 v18, v21
	v_add_u32_e32 v18, 0x18200, v1
	ds_write_b32 v18, v22
	v_add_u32_e32 v18, 0x18600, v1
	ds_write_b32 v18, v23
	v_add_u32_e32 v18, 0x18a00, v1
	ds_write_b32 v18, v24
	v_add_u32_e32 v18, 0x18e00, v1
	ds_write_b32 v18, v25
	v_add_u32_e32 v18, 0x18040, v1
	ds_write_b32 v18, v26
	v_add_u32_e32 v18, 0x18440, v1
	ds_write_b32 v18, v27
	v_add_u32_e32 v18, 0x18840, v1
	ds_write_b32 v18, v28
	v_add_u32_e32 v18, 0x18c40, v1
	ds_write_b32 v18, v29
	v_add_u32_e32 v18, 0x18240, v1
	ds_write_b32 v18, v30
	v_add_u32_e32 v18, 0x18640, v1
	ds_write_b32 v18, v31
	v_add_u32_e32 v18, 0x18a40, v1
	ds_write_b32 v18, v32
	v_add_u32_e32 v18, 0x18e40, v1
	ds_write_b32 v18, v33
	v_add_u32_e32 v18, 0x1c000, v1
	ds_write_b32 v18, v6
	v_add_u32_e32 v6, 0x1c400, v1
	ds_write_b32 v6, v7
	v_add_u32_e32 v6, 0x1c800, v1
	ds_write_b32 v6, v8
	v_add_u32_e32 v6, 0x1cc00, v1
	ds_write_b32 v6, v9
	v_add_u32_e32 v6, 0x1c200, v1
	ds_write_b32 v6, v10
	v_add_u32_e32 v6, 0x1c600, v1
	ds_write_b32 v6, v11
	v_add_u32_e32 v6, 0x1ca00, v1
	ds_write_b32 v6, v12
	v_add_u32_e32 v6, 0x1ce00, v1
	ds_write_b32 v6, v13
	v_add_u32_e32 v6, 0x1c040, v1
	ds_write_b32 v6, v14
	v_add_u32_e32 v6, 0x1c440, v1
	ds_write_b32 v6, v15
	v_add_u32_e32 v6, 0x1c840, v1
	ds_write_b32 v6, v16
	v_add_u32_e32 v6, 0x1cc40, v1
	ds_write_b32 v6, v17
	v_add_u32_e32 v6, 0x1c240, v1
	ds_write_b32 v6, v2
	v_add_u32_e32 v2, 0x1c640, v1
	ds_write_b32 v2, v3
	v_add_u32_e32 v2, 0x1ca40, v1
	v_add_u32_e32 v1, 0x1ce40, v1
	v_and_b32_e32 v3, 3, v0
	ds_write_b32 v2, v4
	ds_write_b32 v1, v5
	v_lshrrev_b32_e32 v2, 4, v0
	v_bfe_u32 v1, v0, 2, 2
	v_lshlrev_b32_e32 v0, 5, v3
	v_lshl_or_b32 v0, v1, 7, v0
	v_lshl_or_b32 v7, v2, 10, v0
	s_waitcnt lgkmcnt(0)
	s_barrier
	ds_read_b128 v[8:11], v7
	ds_read_b128 v[12:15], v7 offset:16
	ds_read_b128 v[16:19], v7 offset:512
	ds_read_b128 v[20:23], v7 offset:528
	s_waitcnt lgkmcnt(3)
	v_mul_f32_e32 v4, 0xbfb8aa3b, v9
	v_mul_f32_e32 v0, 0xbfb8aa3b, v8
	v_exp_f32_e32 v4, v4
	v_mul_f32_e32 v5, 0xbfb8aa3b, v10
	v_exp_f32_e32 v0, v0
	v_exp_f32_e32 v5, v5
	v_mul_f32_e32 v6, 0xbfb8aa3b, v11
	v_exp_f32_e32 v6, v6
	s_waitcnt lgkmcnt(2)
	v_mul_f32_e32 v24, 0xbfb8aa3b, v12
	v_exp_f32_e32 v24, v24
	v_mul_f32_e32 v25, 0xbfb8aa3b, v13
	v_exp_f32_e32 v25, v25
	v_mul_f32_e32 v26, 0xbfb8aa3b, v14
	v_add_f32_e32 v4, 1.0, v4
	v_exp_f32_e32 v26, v26
	v_mul_f32_e32 v27, 0xbfb8aa3b, v15
	v_add_f32_e32 v0, 1.0, v0
	v_rcp_f32_e32 v4, v4
	v_add_f32_e32 v5, 1.0, v5
	v_exp_f32_e32 v27, v27
	v_rcp_f32_e32 v0, v0
	v_rcp_f32_e32 v5, v5
	v_add_f32_e32 v6, 1.0, v6
	v_rcp_f32_e32 v6, v6
	v_add_f32_e32 v24, 1.0, v24
	v_rcp_f32_e32 v24, v24
	v_add_f32_e32 v25, 1.0, v25
	v_rcp_f32_e32 v25, v25
	v_add_f32_e32 v26, 1.0, v26
	v_mul_f32_e32 v4, v9, v4
	v_rcp_f32_e32 v26, v26
	v_add_f32_e32 v27, 1.0, v27
	v_mul_f32_e32 v0, v8, v0
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v8, v17, v4
	v_mul_f32_e32 v4, v10, v5
	v_rcp_f32_e32 v27, v27
	v_mul_f32_e32 v5, v18, v4
	v_mul_f32_e32 v4, v11, v6
	v_mul_f32_e32 v9, v19, v4
	v_mul_f32_e32 v4, v12, v24
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v10, v20, v4
	v_mul_f32_e32 v4, v13, v25
	v_mul_f32_e32 v11, v21, v4
	v_mul_f32_e32 v4, v14, v26
	v_mul_f32_e32 v0, v16, v0
	v_mul_f32_e32 v12, v22, v4
	v_mul_f32_e32 v4, v15, v27
	v_mul_f32_e32 v13, v23, v4
	v_maximum3_f32 v4, |v0|, |v8|, |v8|
	v_maximum3_f32 v4, v4, |v5|, |v9|
	v_maximum3_f32 v4, v4, |v10|, |v11|
	v_maximum3_f32 v4, v4, |v12|, |v13|
	v_mov_b32_e32 v15, 0
	v_mov_b32_e32 v6, 0
	v_max_u32_dpp v4, v4, v4 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v4, v4, v4 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v4, 0x3e2aaaab, v4
	v_add_u32_e32 v4, 0x7fffff, v4
	v_bfe_u32 v4, v4, 23, 8
	v_min_u32_e32 v4, 0xfe, v4
	v_lshlrev_b32_e32 v14, 23, v4
	v_cvt_scalef32_pk_fp4_f32 v15, v0, v8, v14
	v_cvt_scalef32_pk_fp4_f32 v15, v5, v9, v14 op_sel:[0,0,1,0]
	v_lshlrev_b32_e32 v5, 4, v1
	v_lshlrev_b32_e32 v0, 2, v3
	v_or3_b32 v0, s6, v0, v5
	v_or_b32_e32 v1, s24, v2
	v_lshl_add_u32 v0, v1, 10, v0
	v_cvt_scalef32_pk_fp4_f32 v15, v10, v11, v14 op_sel:[0,0,0,1]
	v_ashrrev_i32_e32 v1, 31, v0
	v_cvt_scalef32_pk_fp4_f32 v15, v12, v13, v14 op_sel:[0,0,1,1]
	v_lshl_add_u64 v[0:1], s[0:1], 0, v[0:1]
	global_store_dword v[0:1], v15, off nt
	ds_read_b128 v[8:11], v7 offset:16384
	ds_read_b128 v[12:15], v7 offset:16896
	ds_read_b128 v[16:19], v7 offset:16400
	ds_read_b128 v[20:23], v7 offset:16912
	s_waitcnt lgkmcnt(3)
	v_mul_f32_e32 v24, 0xbfb8aa3b, v8
	v_exp_f32_e32 v24, v24
	v_mul_f32_e32 v25, 0xbfb8aa3b, v9
	v_exp_f32_e32 v25, v25
	v_mul_f32_e32 v26, 0xbfb8aa3b, v10
	v_exp_f32_e32 v26, v26
	v_mul_f32_e32 v27, 0xbfb8aa3b, v11
	v_exp_f32_e32 v27, v27
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v28, 0xbfb8aa3b, v16
	v_exp_f32_e32 v28, v28
	v_mul_f32_e32 v29, 0xbfb8aa3b, v17
	v_add_f32_e32 v24, 1.0, v24
	v_exp_f32_e32 v29, v29
	v_mul_f32_e32 v30, 0xbfb8aa3b, v18
	v_rcp_f32_e32 v24, v24
	v_add_f32_e32 v25, 1.0, v25
	v_exp_f32_e32 v30, v30
	v_mul_f32_e32 v31, 0xbfb8aa3b, v19
	v_rcp_f32_e32 v25, v25
	v_add_f32_e32 v26, 1.0, v26
	v_exp_f32_e32 v31, v31
	v_rcp_f32_e32 v26, v26
	v_add_f32_e32 v27, 1.0, v27
	v_rcp_f32_e32 v27, v27
	v_add_f32_e32 v28, 1.0, v28
	v_rcp_f32_e32 v28, v28
	v_add_f32_e32 v29, 1.0, v29
	v_mul_f32_e32 v8, v8, v24
	v_rcp_f32_e32 v29, v29
	v_add_f32_e32 v30, 1.0, v30
	v_mul_f32_e32 v12, v12, v8
	v_mul_f32_e32 v8, v9, v25
	v_rcp_f32_e32 v30, v30
	v_add_f32_e32 v31, 1.0, v31
	v_mul_f32_e32 v9, v13, v8
	v_mul_f32_e32 v8, v10, v26
	v_rcp_f32_e32 v31, v31
	v_mul_f32_e32 v10, v14, v8
	v_mul_f32_e32 v8, v11, v27
	v_mul_f32_e32 v11, v15, v8
	v_mul_f32_e32 v8, v16, v28
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v13, v20, v8
	v_mul_f32_e32 v8, v17, v29
	v_mul_f32_e32 v14, v21, v8
	v_mul_f32_e32 v8, v18, v30
	v_mul_f32_e32 v15, v22, v8
	v_mul_f32_e32 v8, v19, v31
	v_mul_f32_e32 v16, v23, v8
	v_maximum3_f32 v8, |v12|, |v9|, |v9|
	v_maximum3_f32 v8, v8, |v10|, |v11|
	v_maximum3_f32 v8, v8, |v13|, |v14|
	v_maximum3_f32 v8, v8, |v15|, |v16|
	v_mov_b32_e32 v18, 0
	s_nop 0
	v_max_u32_dpp v8, v8, v8 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v8, v8, v8 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v8, 0x3e2aaaab, v8
	v_add_u32_e32 v8, 0x7fffff, v8
	v_bfe_u32 v8, v8, 23, 8
	v_min_u32_e32 v8, 0xfe, v8
	v_lshlrev_b32_e32 v17, 23, v8
	v_cvt_scalef32_pk_fp4_f32 v18, v12, v9, v17
	v_cvt_scalef32_pk_fp4_f32 v18, v10, v11, v17 op_sel:[0,0,1,0]
	v_add_co_u32_e32 v10, vcc, s10, v0
	v_cvt_scalef32_pk_fp4_f32 v18, v13, v14, v17 op_sel:[0,0,0,1]
	s_nop 0
	v_addc_co_u32_e32 v11, vcc, 0, v1, vcc
	v_cvt_scalef32_pk_fp4_f32 v18, v15, v16, v17 op_sel:[0,0,1,1]
	global_store_dword v[10:11], v18, off nt
	ds_read_b128 v[10:13], v7 offset:32768
	ds_read_b128 v[14:17], v7 offset:33280
	ds_read_b128 v[18:21], v7 offset:32784
	ds_read_b128 v[22:25], v7 offset:33296
	s_waitcnt lgkmcnt(3)
	v_mul_f32_e32 v9, 0xbfb8aa3b, v10
	v_exp_f32_e32 v9, v9
	v_mul_f32_e32 v26, 0xbfb8aa3b, v11
	v_exp_f32_e32 v26, v26
	v_mul_f32_e32 v27, 0xbfb8aa3b, v12
	v_exp_f32_e32 v27, v27
	v_mul_f32_e32 v28, 0xbfb8aa3b, v13
	v_exp_f32_e32 v28, v28
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v29, 0xbfb8aa3b, v18
	v_exp_f32_e32 v29, v29
	v_mul_f32_e32 v30, 0xbfb8aa3b, v19
	v_add_f32_e32 v9, 1.0, v9
	v_exp_f32_e32 v30, v30
	v_mul_f32_e32 v31, 0xbfb8aa3b, v20
	v_rcp_f32_e32 v9, v9
	v_add_f32_e32 v26, 1.0, v26
	v_exp_f32_e32 v31, v31
	v_mul_f32_e32 v32, 0xbfb8aa3b, v21
	v_rcp_f32_e32 v26, v26
	v_add_f32_e32 v27, 1.0, v27
	v_exp_f32_e32 v32, v32
	v_rcp_f32_e32 v27, v27
	v_add_f32_e32 v28, 1.0, v28
	v_rcp_f32_e32 v28, v28
	v_add_f32_e32 v29, 1.0, v29
	v_rcp_f32_e32 v29, v29
	v_add_f32_e32 v30, 1.0, v30
	v_mul_f32_e32 v9, v10, v9
	v_rcp_f32_e32 v30, v30
	v_add_f32_e32 v31, 1.0, v31
	v_mul_f32_e32 v10, v14, v9
	v_mul_f32_e32 v9, v11, v26
	v_rcp_f32_e32 v31, v31
	v_add_f32_e32 v32, 1.0, v32
	v_mul_f32_e32 v11, v15, v9
	v_mul_f32_e32 v9, v12, v27
	v_rcp_f32_e32 v32, v32
	v_mul_f32_e32 v12, v16, v9
	v_mul_f32_e32 v9, v13, v28
	v_mul_f32_e32 v13, v17, v9
	v_mul_f32_e32 v9, v18, v29
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v14, v22, v9
	v_mul_f32_e32 v9, v19, v30
	v_mul_f32_e32 v15, v23, v9
	v_mul_f32_e32 v9, v20, v31
	v_mul_f32_e32 v16, v24, v9
	v_mul_f32_e32 v9, v21, v32
	v_mul_f32_e32 v17, v25, v9
	v_maximum3_f32 v9, |v10|, |v11|, |v11|
	v_maximum3_f32 v9, v9, |v12|, |v13|
	v_maximum3_f32 v9, v9, |v14|, |v15|
	v_maximum3_f32 v9, v9, |v16|, |v17|
	v_mov_b32_e32 v19, 0
	s_nop 0
	v_max_u32_dpp v9, v9, v9 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v9, v9, v9 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v9, 0x3e2aaaab, v9
	v_add_u32_e32 v9, 0x7fffff, v9
	v_bfe_u32 v9, v9, 23, 8
	v_min_u32_e32 v9, 0xfe, v9
	v_lshlrev_b32_e32 v18, 23, v9
	v_cvt_scalef32_pk_fp4_f32 v19, v10, v11, v18
	v_cvt_scalef32_pk_fp4_f32 v19, v12, v13, v18 op_sel:[0,0,1,0]
	v_add_co_u32_e32 v10, vcc, s9, v0
	v_cvt_scalef32_pk_fp4_f32 v19, v14, v15, v18 op_sel:[0,0,0,1]
	s_nop 0
	v_addc_co_u32_e32 v11, vcc, 0, v1, vcc
	v_cvt_scalef32_pk_fp4_f32 v19, v16, v17, v18 op_sel:[0,0,1,1]
	global_store_dword v[10:11], v19, off nt
	ds_read_b128 v[10:13], v7 offset:49152
	ds_read_b128 v[14:17], v7 offset:49664
	ds_read_b128 v[18:21], v7 offset:49168
	ds_read_b128 v[22:25], v7 offset:49680
	s_waitcnt lgkmcnt(3)
	v_mul_f32_e32 v26, 0xbfb8aa3b, v10
	v_exp_f32_e32 v26, v26
	v_mul_f32_e32 v27, 0xbfb8aa3b, v11
	v_exp_f32_e32 v27, v27
	v_mul_f32_e32 v28, 0xbfb8aa3b, v12
	v_exp_f32_e32 v28, v28
	v_mul_f32_e32 v29, 0xbfb8aa3b, v13
	v_exp_f32_e32 v29, v29
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v30, 0xbfb8aa3b, v18
	v_exp_f32_e32 v30, v30
	v_mul_f32_e32 v31, 0xbfb8aa3b, v19
	v_add_f32_e32 v26, 1.0, v26
	v_exp_f32_e32 v31, v31
	v_mul_f32_e32 v32, 0xbfb8aa3b, v20
	v_rcp_f32_e32 v26, v26
	v_add_f32_e32 v27, 1.0, v27
	v_exp_f32_e32 v32, v32
	v_mul_f32_e32 v33, 0xbfb8aa3b, v21
	v_rcp_f32_e32 v27, v27
	v_add_f32_e32 v28, 1.0, v28
	v_exp_f32_e32 v33, v33
	v_rcp_f32_e32 v28, v28
	v_add_f32_e32 v29, 1.0, v29
	v_rcp_f32_e32 v29, v29
	v_add_f32_e32 v30, 1.0, v30
	v_rcp_f32_e32 v30, v30
	v_add_f32_e32 v31, 1.0, v31
	v_mul_f32_e32 v10, v10, v26
	v_rcp_f32_e32 v31, v31
	v_add_f32_e32 v32, 1.0, v32
	v_mul_f32_e32 v14, v14, v10
	v_mul_f32_e32 v10, v11, v27
	v_rcp_f32_e32 v32, v32
	v_add_f32_e32 v33, 1.0, v33
	v_mul_f32_e32 v11, v15, v10
	v_mul_f32_e32 v10, v12, v28
	v_rcp_f32_e32 v33, v33
	v_mul_f32_e32 v12, v16, v10
	v_mul_f32_e32 v10, v13, v29
	v_mul_f32_e32 v13, v17, v10
	v_mul_f32_e32 v10, v18, v30
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v15, v22, v10
	v_mul_f32_e32 v10, v19, v31
	v_mul_f32_e32 v16, v23, v10
	v_mul_f32_e32 v10, v20, v32
	v_mul_f32_e32 v17, v24, v10
	v_mul_f32_e32 v10, v21, v33
	v_mul_f32_e32 v18, v25, v10
	v_maximum3_f32 v10, |v14|, |v11|, |v11|
	v_maximum3_f32 v10, v10, |v12|, |v13|
	v_maximum3_f32 v10, v10, |v15|, |v16|
	v_maximum3_f32 v10, v10, |v17|, |v18|
	v_mov_b32_e32 v20, 0
	s_nop 0
	v_max_u32_dpp v10, v10, v10 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v10, v10, v10 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v10, 0x3e2aaaab, v10
	v_add_u32_e32 v10, 0x7fffff, v10
	v_bfe_u32 v10, v10, 23, 8
	v_min_u32_e32 v10, 0xfe, v10
	v_lshlrev_b32_e32 v19, 23, v10
	v_cvt_scalef32_pk_fp4_f32 v20, v14, v11, v19
	v_cvt_scalef32_pk_fp4_f32 v20, v12, v13, v19 op_sel:[0,0,1,0]
	v_add_co_u32_e32 v12, vcc, s8, v0
	v_cvt_scalef32_pk_fp4_f32 v20, v15, v16, v19 op_sel:[0,0,0,1]
	s_nop 0
	v_addc_co_u32_e32 v13, vcc, 0, v1, vcc
	v_cvt_scalef32_pk_fp4_f32 v20, v17, v18, v19 op_sel:[0,0,1,1]
	v_or_b32_e32 v11, 0x10000, v7
	global_store_dword v[12:13], v20, off nt
	ds_read_b128 v[12:15], v11
	v_or_b32_e32 v11, 0x10200, v7
	ds_read_b128 v[16:19], v11
	v_or_b32_e32 v11, 0x10010, v7
	ds_read_b128 v[20:23], v11
	v_or_b32_e32 v11, 0x10210, v7
	ds_read_b128 v[24:27], v11
	s_waitcnt lgkmcnt(3)
	v_mul_f32_e32 v11, 0xbfb8aa3b, v12
	v_exp_f32_e32 v11, v11
	v_mul_f32_e32 v28, 0xbfb8aa3b, v13
	v_exp_f32_e32 v28, v28
	v_mul_f32_e32 v29, 0xbfb8aa3b, v14
	v_exp_f32_e32 v29, v29
	v_mul_f32_e32 v30, 0xbfb8aa3b, v15
	v_exp_f32_e32 v30, v30
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v31, 0xbfb8aa3b, v20
	v_exp_f32_e32 v31, v31
	v_mul_f32_e32 v32, 0xbfb8aa3b, v21
	v_add_f32_e32 v11, 1.0, v11
	v_exp_f32_e32 v32, v32
	v_mul_f32_e32 v33, 0xbfb8aa3b, v22
	v_rcp_f32_e32 v11, v11
	v_add_f32_e32 v28, 1.0, v28
	v_exp_f32_e32 v33, v33
	v_mul_f32_e32 v34, 0xbfb8aa3b, v23
	v_rcp_f32_e32 v28, v28
	v_add_f32_e32 v29, 1.0, v29
	v_exp_f32_e32 v34, v34
	v_rcp_f32_e32 v29, v29
	v_add_f32_e32 v30, 1.0, v30
	v_rcp_f32_e32 v30, v30
	v_add_f32_e32 v31, 1.0, v31
	v_rcp_f32_e32 v31, v31
	v_add_f32_e32 v32, 1.0, v32
	v_mul_f32_e32 v11, v12, v11
	v_rcp_f32_e32 v32, v32
	v_add_f32_e32 v33, 1.0, v33
	v_mul_f32_e32 v12, v16, v11
	v_mul_f32_e32 v11, v13, v28
	v_rcp_f32_e32 v33, v33
	v_add_f32_e32 v34, 1.0, v34
	v_mul_f32_e32 v13, v17, v11
	v_mul_f32_e32 v11, v14, v29
	v_rcp_f32_e32 v34, v34
	v_mul_f32_e32 v14, v18, v11
	v_mul_f32_e32 v11, v15, v30
	v_mul_f32_e32 v15, v19, v11
	v_mul_f32_e32 v11, v20, v31
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v16, v24, v11
	v_mul_f32_e32 v11, v21, v32
	v_mul_f32_e32 v17, v25, v11
	v_mul_f32_e32 v11, v22, v33
	v_mul_f32_e32 v18, v26, v11
	v_mul_f32_e32 v11, v23, v34
	v_mul_f32_e32 v19, v27, v11
	v_maximum3_f32 v11, |v12|, |v13|, |v13|
	v_maximum3_f32 v11, v11, |v14|, |v15|
	v_maximum3_f32 v11, v11, |v16|, |v17|
	v_maximum3_f32 v11, v11, |v18|, |v19|
	v_mov_b32_e32 v21, 0
	v_or_b32_e32 v24, 0x14210, v7
	v_max_u32_dpp v11, v11, v11 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	ds_read_b128 v[24:27], v24
	s_nop 0
	v_max_u32_dpp v11, v11, v11 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v11, 0x3e2aaaab, v11
	v_add_u32_e32 v11, 0x7fffff, v11
	v_bfe_u32 v11, v11, 23, 8
	v_min_u32_e32 v11, 0xfe, v11
	v_lshlrev_b32_e32 v20, 23, v11
	v_cvt_scalef32_pk_fp4_f32 v21, v12, v13, v20
	v_cvt_scalef32_pk_fp4_f32 v21, v14, v15, v20 op_sel:[0,0,1,0]
	v_add_co_u32_e32 v12, vcc, s11, v0
	v_cvt_scalef32_pk_fp4_f32 v21, v16, v17, v20 op_sel:[0,0,0,1]
	s_nop 0
	v_addc_co_u32_e32 v13, vcc, 0, v1, vcc
	v_cvt_scalef32_pk_fp4_f32 v21, v18, v19, v20 op_sel:[0,0,1,1]
	global_store_dword v[12:13], v21, off nt
	v_or_b32_e32 v12, 0x14000, v7
	ds_read_b128 v[12:15], v12
	v_or_b32_e32 v20, 0x14010, v7
	ds_read_b128 v[20:23], v20
	v_or_b32_e32 v16, 0x14200, v7
	ds_read_b128 v[16:19], v16
	s_waitcnt lgkmcnt(2)
	v_mul_f32_e32 v28, 0xbfb8aa3b, v12
	v_exp_f32_e32 v28, v28
	v_mul_f32_e32 v29, 0xbfb8aa3b, v13
	v_exp_f32_e32 v29, v29
	v_mul_f32_e32 v30, 0xbfb8aa3b, v14
	v_exp_f32_e32 v30, v30
	v_mul_f32_e32 v31, 0xbfb8aa3b, v15
	v_exp_f32_e32 v31, v31
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v32, 0xbfb8aa3b, v20
	v_exp_f32_e32 v32, v32
	v_mul_f32_e32 v33, 0xbfb8aa3b, v21
	v_add_f32_e32 v28, 1.0, v28
	v_exp_f32_e32 v33, v33
	v_mul_f32_e32 v34, 0xbfb8aa3b, v22
	v_rcp_f32_e32 v28, v28
	v_add_f32_e32 v29, 1.0, v29
	v_exp_f32_e32 v34, v34
	v_mul_f32_e32 v35, 0xbfb8aa3b, v23
	v_rcp_f32_e32 v29, v29
	v_add_f32_e32 v30, 1.0, v30
	v_exp_f32_e32 v35, v35
	v_rcp_f32_e32 v30, v30
	v_add_f32_e32 v31, 1.0, v31
	v_rcp_f32_e32 v31, v31
	v_add_f32_e32 v32, 1.0, v32
	v_rcp_f32_e32 v32, v32
	v_add_f32_e32 v33, 1.0, v33
	v_mul_f32_e32 v12, v12, v28
	v_rcp_f32_e32 v33, v33
	v_add_f32_e32 v34, 1.0, v34
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v16, v16, v12
	v_mul_f32_e32 v12, v13, v29
	v_rcp_f32_e32 v34, v34
	v_add_f32_e32 v35, 1.0, v35
	v_mul_f32_e32 v13, v17, v12
	v_mul_f32_e32 v12, v14, v30
	v_rcp_f32_e32 v35, v35
	v_mul_f32_e32 v14, v18, v12
	v_mul_f32_e32 v12, v15, v31
	v_mul_f32_e32 v15, v19, v12
	v_mul_f32_e32 v12, v20, v32
	v_mul_f32_e32 v17, v24, v12
	v_mul_f32_e32 v12, v21, v33
	v_mul_f32_e32 v18, v25, v12
	v_mul_f32_e32 v12, v22, v34
	v_mul_f32_e32 v19, v26, v12
	v_mul_f32_e32 v12, v23, v35
	v_mul_f32_e32 v20, v27, v12
	v_maximum3_f32 v12, |v16|, |v13|, |v13|
	v_maximum3_f32 v12, v12, |v14|, |v15|
	v_maximum3_f32 v12, v12, |v17|, |v18|
	v_maximum3_f32 v12, v12, |v19|, |v20|
	v_mov_b32_e32 v22, 0
	s_nop 0
	v_max_u32_dpp v12, v12, v12 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v12, v12, v12 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v12, 0x3e2aaaab, v12
	v_add_u32_e32 v12, 0x7fffff, v12
	v_bfe_u32 v12, v12, 23, 8
	v_min_u32_e32 v12, 0xfe, v12
	v_lshlrev_b32_e32 v21, 23, v12
	v_cvt_scalef32_pk_fp4_f32 v22, v16, v13, v21
	v_cvt_scalef32_pk_fp4_f32 v22, v14, v15, v21 op_sel:[0,0,1,0]
	v_add_co_u32_e32 v14, vcc, s4, v0
	v_cvt_scalef32_pk_fp4_f32 v22, v17, v18, v21 op_sel:[0,0,0,1]
	s_nop 0
	v_addc_co_u32_e32 v15, vcc, 0, v1, vcc
	v_cvt_scalef32_pk_fp4_f32 v22, v19, v20, v21 op_sel:[0,0,1,1]
	v_or_b32_e32 v13, 0x18000, v7
	global_store_dword v[14:15], v22, off nt
	ds_read_b128 v[14:17], v13
	v_or_b32_e32 v13, 0x18200, v7
	ds_read_b128 v[18:21], v13
	v_or_b32_e32 v13, 0x18010, v7
	ds_read_b128 v[22:25], v13
	v_or_b32_e32 v13, 0x18210, v7
	ds_read_b128 v[26:29], v13
	s_waitcnt lgkmcnt(3)
	v_mul_f32_e32 v13, 0xbfb8aa3b, v14
	v_exp_f32_e32 v13, v13
	v_mul_f32_e32 v30, 0xbfb8aa3b, v15
	v_exp_f32_e32 v30, v30
	v_mul_f32_e32 v31, 0xbfb8aa3b, v16
	v_exp_f32_e32 v31, v31
	v_mul_f32_e32 v32, 0xbfb8aa3b, v17
	v_exp_f32_e32 v32, v32
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v33, 0xbfb8aa3b, v22
	v_exp_f32_e32 v33, v33
	v_mul_f32_e32 v34, 0xbfb8aa3b, v23
	v_add_f32_e32 v13, 1.0, v13
	v_exp_f32_e32 v34, v34
	v_mul_f32_e32 v35, 0xbfb8aa3b, v24
	v_rcp_f32_e32 v13, v13
	v_add_f32_e32 v30, 1.0, v30
	v_exp_f32_e32 v35, v35
	v_mul_f32_e32 v36, 0xbfb8aa3b, v25
	v_rcp_f32_e32 v30, v30
	v_add_f32_e32 v31, 1.0, v31
	v_exp_f32_e32 v36, v36
	v_rcp_f32_e32 v31, v31
	v_add_f32_e32 v32, 1.0, v32
	v_rcp_f32_e32 v32, v32
	v_add_f32_e32 v33, 1.0, v33
	v_rcp_f32_e32 v33, v33
	v_add_f32_e32 v34, 1.0, v34
	v_mul_f32_e32 v13, v14, v13
	v_rcp_f32_e32 v34, v34
	v_add_f32_e32 v35, 1.0, v35
	v_mul_f32_e32 v14, v18, v13
	v_mul_f32_e32 v13, v15, v30
	v_rcp_f32_e32 v35, v35
	v_add_f32_e32 v36, 1.0, v36
	v_mul_f32_e32 v15, v19, v13
	v_mul_f32_e32 v13, v16, v31
	v_rcp_f32_e32 v36, v36
	v_mul_f32_e32 v16, v20, v13
	v_mul_f32_e32 v13, v17, v32
	v_mul_f32_e32 v17, v21, v13
	v_mul_f32_e32 v13, v22, v33
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v18, v26, v13
	v_mul_f32_e32 v13, v23, v34
	v_mul_f32_e32 v19, v27, v13
	v_mul_f32_e32 v13, v24, v35
	v_mul_f32_e32 v20, v28, v13
	v_mul_f32_e32 v13, v25, v36
	v_mul_f32_e32 v21, v29, v13
	v_maximum3_f32 v13, |v14|, |v15|, |v15|
	v_maximum3_f32 v13, v13, |v16|, |v17|
	v_maximum3_f32 v13, v13, |v18|, |v19|
	v_maximum3_f32 v13, v13, |v20|, |v21|
	v_mov_b32_e32 v23, 0
	s_nop 0
	v_max_u32_dpp v13, v13, v13 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	s_nop 1
	v_max_u32_dpp v13, v13, v13 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v13, 0x3e2aaaab, v13
	v_add_u32_e32 v13, 0x7fffff, v13
	v_bfe_u32 v13, v13, 23, 8
	v_min_u32_e32 v13, 0xfe, v13
	v_lshlrev_b32_e32 v22, 23, v13
	v_cvt_scalef32_pk_fp4_f32 v23, v14, v15, v22
	v_cvt_scalef32_pk_fp4_f32 v23, v16, v17, v22 op_sel:[0,0,1,0]
	v_add_co_u32_e32 v14, vcc, s5, v0
	v_cvt_scalef32_pk_fp4_f32 v23, v18, v19, v22 op_sel:[0,0,0,1]
	s_nop 0
	v_addc_co_u32_e32 v15, vcc, 0, v1, vcc
	v_cvt_scalef32_pk_fp4_f32 v23, v20, v21, v22 op_sel:[0,0,1,1]
	global_store_dword v[14:15], v23, off nt
	v_or_b32_e32 v14, 0x1c000, v7
	ds_read_b128 v[14:17], v14
	v_or_b32_e32 v22, 0x1c010, v7
	v_or_b32_e32 v18, 0x1c200, v7
	ds_read_b128 v[22:25], v22
	v_or_b32_e32 v7, 0x1c210, v7
	ds_read_b128 v[26:29], v7
	s_waitcnt lgkmcnt(2)
	v_mul_f32_e32 v7, 0xbfb8aa3b, v14
	v_exp_f32_e32 v7, v7
	v_mul_f32_e32 v30, 0xbfb8aa3b, v15
	v_exp_f32_e32 v30, v30
	v_mul_f32_e32 v31, 0xbfb8aa3b, v16
	v_exp_f32_e32 v31, v31
	v_mul_f32_e32 v32, 0xbfb8aa3b, v17
	v_exp_f32_e32 v32, v32
	s_waitcnt lgkmcnt(1)
	v_mul_f32_e32 v33, 0xbfb8aa3b, v22
	v_exp_f32_e32 v33, v33
	v_mul_f32_e32 v34, 0xbfb8aa3b, v23
	v_add_f32_e32 v7, 1.0, v7
	ds_read_b128 v[18:21], v18
	v_exp_f32_e32 v34, v34
	v_mul_f32_e32 v35, 0xbfb8aa3b, v24
	v_rcp_f32_e32 v7, v7
	v_add_f32_e32 v30, 1.0, v30
	v_exp_f32_e32 v35, v35
	v_mul_f32_e32 v36, 0xbfb8aa3b, v25
	v_rcp_f32_e32 v30, v30
	v_add_f32_e32 v31, 1.0, v31
	v_exp_f32_e32 v36, v36
	v_rcp_f32_e32 v31, v31
	v_add_f32_e32 v32, 1.0, v32
	v_rcp_f32_e32 v32, v32
	v_add_f32_e32 v33, 1.0, v33
	v_rcp_f32_e32 v33, v33
	v_add_f32_e32 v34, 1.0, v34
	v_mul_f32_e32 v7, v14, v7
	v_rcp_f32_e32 v34, v34
	v_add_f32_e32 v35, 1.0, v35
	s_waitcnt lgkmcnt(0)
	v_mul_f32_e32 v14, v18, v7
	v_mul_f32_e32 v7, v15, v30
	v_rcp_f32_e32 v35, v35
	v_add_f32_e32 v36, 1.0, v36
	v_mul_f32_e32 v15, v19, v7
	v_mul_f32_e32 v7, v16, v31
	v_rcp_f32_e32 v36, v36
	v_mul_f32_e32 v16, v20, v7
	v_mul_f32_e32 v7, v17, v32
	v_mul_f32_e32 v17, v21, v7
	v_mul_f32_e32 v7, v22, v33
	v_mul_f32_e32 v18, v26, v7
	v_mul_f32_e32 v7, v23, v34
	v_mul_f32_e32 v19, v27, v7
	v_mul_f32_e32 v7, v24, v35
	v_mul_f32_e32 v20, v28, v7
	v_mul_f32_e32 v7, v25, v36
	v_mul_f32_e32 v21, v29, v7
	v_maximum3_f32 v7, |v14|, |v15|, |v15|
	v_maximum3_f32 v7, v7, |v16|, |v17|
	v_maximum3_f32 v7, v7, |v18|, |v19|
	v_maximum3_f32 v7, v7, |v20|, |v21|
	v_add_co_u32_e32 v0, vcc, 0x1c000, v0
	s_nop 0
	v_max_u32_dpp v7, v7, v7 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_addc_co_u32_e32 v1, vcc, 0, v1, vcc
	s_nop 0
	v_max_u32_dpp v7, v7, v7 quad_perm:[2,3,0,1] row_mask:0xf bank_mask:0xf bound_ctrl:1
	v_mul_f32_e32 v7, 0x3e2aaaab, v7
	v_add_u32_e32 v7, 0x7fffff, v7
	v_bfe_u32 v7, v7, 23, 8
	v_min_u32_e32 v7, 0xfe, v7
	v_lshlrev_b32_e32 v22, 23, v7
	v_cvt_scalef32_pk_fp4_f32 v6, v14, v15, v22
	v_cvt_scalef32_pk_fp4_f32 v6, v16, v17, v22 op_sel:[0,0,1,0]
	v_cmp_eq_u32_e32 vcc, 0, v3
	v_cvt_scalef32_pk_fp4_f32 v6, v18, v19, v22 op_sel:[0,0,0,1]
	s_nop 0
	v_cvt_scalef32_pk_fp4_f32 v6, v20, v21, v22 op_sel:[0,0,1,1]
	global_store_dword v[0:1], v6, off nt
	s_and_saveexec_b64 s[0:1], vcc
	s_cbranch_execz .LBB0_3
	s_lshl_b32 s1, s22, 5
	s_lshl_b32 s0, s23, 11
	s_and_b32 s1, s1, 0x3fffffc0
	s_add_i32 s0, s0, s1
	v_or3_b32 v0, s0, v5, v2
	s_lshl_b32 s0, s22, 1
	s_and_b32 s0, s0, 2
	v_lshl_or_b32 v0, v0, 2, s0
	v_ashrrev_i32_e32 v1, 31, v0
	v_lshl_or_b32 v2, v8, 8, v4
	v_lshl_add_u64 v[0:1], s[2:3], 0, v[0:1]
	global_store_short v[0:1], v2, off
	v_lshl_or_b32 v2, v10, 8, v9
	global_store_short v[0:1], v2, off offset:2048
	v_add_co_u32_e32 v0, vcc, 0x1000, v0
	v_lshl_or_b32 v2, v12, 8, v11
	s_nop 0
	v_addc_co_u32_e32 v1, vcc, 0, v1, vcc
	global_store_short v[0:1], v2, off
	v_lshl_or_b32 v2, v7, 8, v13
	global_store_short v[0:1], v2, off offset:2048
.LBB0_3:
	s_endpgm
	.section	.rodata,"a",@progbits
	.p2align	6, 0x0
	.amdhsa_kernel gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep
		.amdhsa_group_segment_fixed_size 131072
		.amdhsa_private_segment_fixed_size 0
		.amdhsa_kernarg_size 88
		.amdhsa_user_sgpr_count 2
		.amdhsa_user_sgpr_dispatch_ptr 0
		.amdhsa_user_sgpr_queue_ptr 0
		.amdhsa_user_sgpr_kernarg_segment_ptr 1
		.amdhsa_user_sgpr_dispatch_id 0
		.amdhsa_user_sgpr_kernarg_preload_length 0
		.amdhsa_user_sgpr_kernarg_preload_offset 0
		.amdhsa_user_sgpr_private_segment_size 0
		.amdhsa_uses_dynamic_stack 0
		.amdhsa_enable_private_segment 0
		.amdhsa_system_sgpr_workgroup_id_x 1
		.amdhsa_system_sgpr_workgroup_id_y 0
		.amdhsa_system_sgpr_workgroup_id_z 0
		.amdhsa_system_sgpr_workgroup_info 0
		.amdhsa_system_vgpr_workitem_id 0
		.amdhsa_next_free_vgpr 336
		.amdhsa_next_free_sgpr 96
		.amdhsa_accum_offset 256
		.amdhsa_reserve_vcc 1
		.amdhsa_float_round_mode_32 0
		.amdhsa_float_round_mode_16_64 0
		.amdhsa_float_denorm_mode_32 3
		.amdhsa_float_denorm_mode_16_64 3
		.amdhsa_dx10_clamp 1
		.amdhsa_ieee_mode 1
		.amdhsa_fp16_overflow 0
		.amdhsa_tg_split 0
		.amdhsa_exception_fp_ieee_invalid_op 0
		.amdhsa_exception_fp_denorm_src 0
		.amdhsa_exception_fp_ieee_div_zero 0
		.amdhsa_exception_fp_ieee_overflow 0
		.amdhsa_exception_fp_ieee_underflow 0
		.amdhsa_exception_fp_ieee_inexact 0
		.amdhsa_exception_int_div_zero 0
	.end_amdhsa_kernel
	.text
.Lfunc_end0:
	.size	gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep, .Lfunc_end0-gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep

	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.num_vgpr, 256
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.num_agpr, 80
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.numbered_sgpr, 50
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.num_named_barrier, 0
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.private_seg_size, 0
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.uses_vcc, 1
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.uses_flat_scratch, 0
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.has_dyn_sized_stack, 0
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.has_recursion, 0
	.set gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.has_indirect_call, 0
	.p2alignl 6, 3212836864
	.fill 256, 4, 3212836864
	.section	.AMDGPU.gpr_maximums,"",@progbits
	.set amdgpu.max_num_vgpr, 0
	.set amdgpu.max_num_agpr, 0
	.set amdgpu.max_num_sgpr, 0
	.set amdgpu.max_num_named_barrier, 0
	.text
	.section	".note.GNU-stack","",@progbits
	.amdgpu_metadata
---
amdhsa.kernels:
  - .agpr_count:     80
    .args:
      - .offset:         0
        .size:           8
        .value_kind:     by_value
      - .offset:         8
        .size:           8
        .value_kind:     by_value
      - .offset:         16
        .size:           8
        .value_kind:     by_value
      - .offset:         24
        .size:           8
        .value_kind:     by_value
      - .offset:         32
        .size:           8
        .value_kind:     by_value
      - .offset:         40
        .size:           8
        .value_kind:     by_value
      - .offset:         48
        .size:           8
        .value_kind:     by_value
      - .offset:         56
        .size:           4
        .value_kind:     by_value
      - .offset:         64
        .size:           8
        .value_kind:     by_value
      - .offset:         72
        .size:           8
        .value_kind:     by_value
      - .offset:         80
        .size:           8
        .value_kind:     by_value
    .group_segment_fixed_size: 131072
    .kernarg_segment_align: 8
    .kernarg_segment_size: 88
    .max_flat_workgroup_size: 256
    .name:           gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep
    .private_segment_fixed_size: 0
    .reqd_workgroup_size:
      - 256
      - 1
      - 1
    .sgpr_count:     56
    .sgpr_spill_count: 0
    .symbol:         gemm1_a4w4_port_h7168_i2048_ne96_bm128_cached_sep.kd
    .uniform_work_group_size: 1
    .uses_dynamic_stack: false
    .vgpr_count:     336
    .vgpr_spill_count: 0
    .wavefront_size: 64
amdhsa.target:   amdgcn-amd-amdhsa--gfx950
amdhsa.version:
  - 1
  - 2
...

	.end_amdgpu_metadata
